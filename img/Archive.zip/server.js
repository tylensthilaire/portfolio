#!/usr/bin/env node
/*
 * MPMP prototype — zero-dependency static file server.
 * Node built-ins only. Serves the current directory on http://localhost:8080
 * (or the port passed as the first arg).
 *
 *   node server.js
 *   node server.js 3000
 */
const http = require("http");
const fs = require("fs");
const path = require("path");
const url = require("url");

const ROOT = __dirname;
const PORT = parseInt(process.argv[2], 10) || 8080;

const MIME = {
  ".html": "text/html; charset=utf-8",
  ".js": "text/javascript; charset=utf-8",
  ".css": "text/css; charset=utf-8",
  ".json": "application/json; charset=utf-8",
  ".svg": "image/svg+xml",
  ".png": "image/png",
  ".jpg": "image/jpeg",
  ".ico": "image/x-icon",
  ".woff2": "font/woff2",
  ".map": "application/json"
};

function safeJoin(root, requested) {
  const resolved = path.normalize(path.join(root, requested));
  if (!resolved.startsWith(root)) return null;
  return resolved;
}

const server = http.createServer((req, res) => {
  const parsed = url.parse(req.url);
  let pathname = decodeURIComponent(parsed.pathname || "/");
  if (pathname === "/") pathname = "/index.html";

  const filePath = safeJoin(ROOT, pathname);
  if (!filePath) {
    res.writeHead(400).end("Bad request");
    return;
  }

  fs.stat(filePath, (err, stat) => {
    // Directory request → serve its index.html if present (lets the
    // sibling apps live in their own folders, e.g. /dashboard/).
    let target = filePath;
    if (!err && stat && stat.isDirectory()) {
      const indexPath = path.join(filePath, "index.html");
      try {
        const idxStat = fs.statSync(indexPath);
        if (idxStat.isFile()) { target = indexPath; stat = idxStat; err = null; }
      } catch (e) { /* fall through to SPA fallback */ }
    }
    if (err || !stat.isFile()) {
      // SPA fallback: unknown path → index.html so hash-router loads.
      const fallback = path.join(ROOT, "index.html");
      fs.readFile(fallback, (fErr, data) => {
        if (fErr) {
          res.writeHead(404).end("Not found");
          return;
        }
        res.writeHead(200, { "Content-Type": MIME[".html"] }).end(data);
      });
      return;
    }
    const ext = path.extname(target).toLowerCase();
    res.writeHead(200, {
      "Content-Type": MIME[ext] || "application/octet-stream",
      "Cache-Control": "no-cache"
    });
    fs.createReadStream(target).pipe(res);
  });
});

server.listen(PORT, () => {
  console.log(`MPMP prototype running at http://localhost:${PORT}`);
  console.log(`Serving ${ROOT}`);
});
