/* ============================================================
   Model-level RAG aggregation.

   Ported from the journey prototype's assumed rule
   "Key-KPI dominance with materiality floor" so both apps agree
   on how a model's overall RAG is derived from its KPIs. The
   source docs leave this open (DN-13 / I-02); it is an assumption.

     1. Any KEY KPI = Red          → Red
     2. Any KEY KPI = Amber        → Amber
     3. ≥30% non-key KPIs A+R, or
        ≥15% non-key KPIs R        → Amber
     4. Otherwise                  → Green

   Works on a snapshot: an array of {isKey, rag} for a single run,
   so it can be applied to the current run, the previous run, or
   any month-end run when building the trend series.
   ============================================================ */
(function () {
  "use strict";
  var MRA = window.MRA = window.MRA || {};

  function aggregate(kpiStates) {
    var key = kpiStates.filter(function (k) { return k.isKey; });
    var nonKey = kpiStates.filter(function (k) { return !k.isKey; });

    var keyReds = key.filter(function (k) { return k.rag === "r"; });
    var keyAmbers = key.filter(function (k) { return k.rag === "a"; });
    var nonKeyReds = nonKey.filter(function (k) { return k.rag === "r"; });
    var nonKeyBad = nonKey.filter(function (k) { return k.rag === "r" || k.rag === "a"; });

    var branch, rag;
    if (keyReds.length > 0) {
      rag = "r"; branch = "1 — key-KPI Red";
    } else if (keyAmbers.length > 0) {
      rag = "a"; branch = "2 — key-KPI Amber";
    } else if (
      (nonKey.length > 0 && nonKeyBad.length / nonKey.length >= 0.30) ||
      (nonKey.length > 0 && nonKeyReds.length / nonKey.length >= 0.15)
    ) {
      rag = "a"; branch = "3 — non-key materiality floor";
    } else {
      rag = "g"; branch = "4 — no material breach";
    }

    return {
      rag: rag,
      branch: branch,
      inputs: {
        totalKpis: kpiStates.length,
        keyCount: key.length,
        nonKeyCount: nonKey.length,
        keyReds: keyReds.map(function (k) { return k.code; }),
        keyAmbers: keyAmbers.map(function (k) { return k.code; }),
        nonKeyReds: nonKeyReds.map(function (k) { return k.code; }),
        nonKeyBad: nonKeyBad.map(function (k) { return k.code; })
      }
    };
  }

  // Convenience: aggregate a model's KPIs at a given run index.
  function ragAtRun(model, runIndex) {
    var states = model.kpis.map(function (k) {
      return { code: k.code, isKey: k.isKey, rag: k.history[runIndex] };
    });
    return aggregate(states).rag;
  }

  MRA.rag = { aggregate: aggregate, ragAtRun: ragAtRun };
})();
