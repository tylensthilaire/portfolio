/* ============================================================
   TAB 2 — Model-Level View
   Covers US-6, US-7, US-8 for a single selected model. All
   components reflect the same selected model (FR-4-1) and the
   KPI counts reconcile between the breakdown chart and the
   detail table (FR-4-2).
   ============================================================ */
(function () {
  "use strict";
  var MRA = window.MRA = window.MRA || {};
  var F = MRA.fmt, C = MRA.charts, esc = F.escape;

  // Categorical palette for KPI trend lines (distinct from RAG semantics).
  var KPI_COLORS = ["#3c1053", "#1f7a8c", "#c9a35a", "#7b4fb0", "#2b6cb0", "#a8557a", "#4a7c59", "#8a6c25"];

  function card(opts) {
    return ''
      + '<section class="card">'
      +   '<header class="card__head">'
      +     '<div><h2 class="card__title">' + esc(opts.title) + '</h2>'
      +       (opts.q ? '<p class="card__q">' + esc(opts.q) + '</p>' : '') + '</div>'
      +     '<span class="req-tag" title="' + esc(opts.regTitle || "") + '">' + esc(opts.req) + '</span>'
      +   '</header>'
      +   '<div class="card__body">' + opts.body + '</div>'
      +   (opts.foot ? '<footer class="card__foot muted">' + opts.foot + '</footer>' : '')
      + '</section>';
  }

  // ---- model picker + identity ----
  function selector(model) {
    var byDept = {};
    MRA.data.models.forEach(function (m) {
      (byDept[m.department] = byDept[m.department] || []).push(m);
    });
    var opts = "";
    Object.keys(byDept).sort().forEach(function (dept) {
      opts += '<optgroup label="' + esc(dept) + '">';
      byDept[dept].forEach(function (m) {
        opts += '<option value="' + esc(m.id) + '"' + (m.id === model.id ? " selected" : "") + '>'
          + esc(m.name) + " — " + m.riskTier + " · " + F.RAG_LABEL[m.rag] + '</option>';
      });
      opts += '</optgroup>';
    });

    return ''
      + '<section class="card model-id-card">'
      +   '<div class="model-picker">'
      +     '<label for="model-select">Model</label>'
      +     '<select id="model-select">' + opts + '</select>'
      +   '</div>'
      +   '<dl class="model-meta">'
      +     '<div><dt>Function</dt><dd>' + esc(model.fn) + '</dd></div>'
      +     '<div><dt>Department</dt><dd>' + esc(model.department) + '</dd></div>'
      +     '<div><dt>Model type</dt><dd>' + esc(model.modelType) + ' <span class="muted">· ' + esc(model.mappedType) + '</span></dd></div>'
      +     '<div><dt>Risk tier</dt><dd>' + esc(F.TIER_LABEL[model.riskTier]) + '</dd></div>'
      +     '<div><dt>Owner</dt><dd>' + esc(model.owner) + '</dd></div>'
      +     '<div><dt>Developer</dt><dd>' + esc(model.developer) + '</dd></div>'
      +   '</dl>'
      + '</section>';
  }

  // ---- US-6 : status card + KPI breakdown + KPI detail table ----
  function us6(model) {
    // FR-1 status card
    var d = model.derivation;
    var driver;
    if (d.inputs.keyReds.length) driver = "Key KPI(s) Red: " + d.inputs.keyReds.join(", ");
    else if (d.inputs.keyAmbers.length) driver = "Key KPI(s) Amber: " + d.inputs.keyAmbers.join(", ");
    else if (d.branch.indexOf("3") === 0) driver = "Non-key materiality floor tripped";
    else driver = "No material KPI breach";

    var statusCard = ''
      + '<div class="status-card status-card--' + model.rag + '">'
      +   '<span class="status-card__label">Current model RAG</span>'
      +   '<span class="status-card__rag">' + F.RAG_LABEL[model.rag] + '</span>'
      +   '<span class="status-card__risk">' + F.RAG_RISK[model.rag] + '</span>'
      +   '<span class="status-card__meta">Latest run ' + F.dateLabel(model.latestRunDate) + '</span>'
      +   '<span class="status-card__driver">' + esc(driver) + ' <span class="muted">(rule branch ' + esc(d.branch) + ')</span></span>'
      + '</div>';

    // FR-2 KPI RAG breakdown (Key vs Non-Key stacked column)
    var keyT = { r: 0, a: 0, g: 0 }, nonT = { r: 0, a: 0, g: 0 };
    model.kpis.forEach(function (k) { (k.isKey ? keyT : nonT)[k.cur] += 1; });
    var breakdown = '<div class="chart-block"><h3 class="sub-h">KPI RAG breakdown</h3>'
      + C.vStacked([
        { label: "Key", segs: keyT },
        { label: "Non-Key", segs: nonT }
      ], { aria: "KPI counts by type split by RAG" }) + C.legend(["r", "a", "g"]) + '</div>';

    // FR-3 KPI detail table (sortable by RAG — FR-5-2)
    var sort = MRA.state.kpiSort || "rag";
    var kpis = model.kpis.slice();
    if (sort === "rag") {
      kpis.sort(function (a, b) {
        if (F.RAG_ORDER[b.cur] !== F.RAG_ORDER[a.cur]) return F.RAG_ORDER[b.cur] - F.RAG_ORDER[a.cur];
        return (b.isKey ? 1 : 0) - (a.isKey ? 1 : 0);
      });
    } else {
      kpis.sort(function (a, b) { return (b.isKey ? 1 : 0) - (a.isKey ? 1 : 0); });
    }
    var rows = kpis.map(function (k) {
      return '<tr><td>' + esc(k.name) + ' <span class="muted small">' + esc(k.group) + '</span></td>'
        + '<td>' + (k.isKey ? '<span class="pill pill--key">Key</span>' : '<span class="pill">Non-Key</span>') + '</td>'
        + '<td class="kpi-cell kpi-cell--' + k.cur + '"><span class="rag rag--' + k.cur + '">' + F.RAG_LABEL[k.cur] + '</span></td></tr>';
    }).join("");
    var table = '<div class="chart-block"><div class="sub-h-row"><h3 class="sub-h">KPI detail</h3>'
      + '<label class="sort-ctl">Sort <select id="kpi-sort"><option value="rag"' + (sort === "rag" ? " selected" : "") + '>By RAG severity</option>'
      + '<option value="type"' + (sort === "type" ? " selected" : "") + '>By Key / Non-Key</option></select></label></div>'
      + '<table class="grid-table"><thead><tr><th scope="col">KPI Name</th><th scope="col">Class</th><th scope="col">KPI RAG</th></tr></thead>'
      + '<tbody>' + rows + '</tbody></table></div>';

    return card({
      title: "Current RAG status & drivers",
      q: "What is the current RAG status of this model, and what drives that status?",
      req: "US-6",
      regTitle: "PRA SS1/23 Principle 4 (Independent validation) · Principle 3",
      body: '<div class="grid-2 grid-2--status">' + statusCard + breakdown + '</div>' + table,
      foot: 'FR-1 Status card (latest run) · FR-2 KPI breakdown Key vs Non-Key · FR-3 KPI detail. Chart & table both reconcile to <strong>' + model.kpis.length + '</strong> KPIs (FR-4-2).'
    });
  }

  // ---- US-7 : model & KPI RAG trend over runs (ordinal) ----
  function us7(model) {
    var runs = model.runs;
    var xLabels = runs.map(function (r) { return F.dateLabel(r.date); });
    var yTicks = [{ v: 0, label: "Green" }, { v: 1, label: "Amber" }, { v: 2, label: "Red" }];

    var series = [{
      name: "Model RAG", color: "#1a1520",
      values: runs.map(function (r) { return F.RAG_ORDER[r.rag]; }),
      markerRag: runs.map(function (r) { return r.rag; })
    }];

    var toggles = MRA.state.kpiToggles || {};
    var chips = "";
    model.kpis.forEach(function (k, i) {
      var on = toggles[k.code];
      var color = KPI_COLORS[i % KPI_COLORS.length];
      chips += '<button type="button" class="kpi-toggle' + (on ? " is-on" : "") + '" data-kpi="' + esc(k.code) + '" '
        + 'aria-pressed="' + (on ? "true" : "false") + '">'
        + '<span class="kpi-toggle__swatch" style="background:' + (on ? color : "transparent") + ';border-color:' + color + '"></span>'
        + esc(k.name) + (k.isKey ? ' <em>Key</em>' : '') + '</button>';
      if (on) {
        series.push({
          name: k.name, color: color, dashed: true,
          values: k.history.map(function (h) { return F.RAG_ORDER[h]; })
        });
      }
    });

    var chart = C.line({
      aria: "Model and KPI RAG status over time, ordinal scale green to red",
      xLabels: xLabels, yMin: 0, yMax: 2, yTicks: yTicks, bands: true,
      series: series,
      pointTip: function (s, i, v) { return s.name + " · " + xLabels[i] + " · " + F.RAG_FROM_ORDER[v].toUpperCase().replace("G", "Green").replace("A", "Amber").replace("R", "Red"); }
    });

    return card({
      title: "Performance over time",
      q: "How has this model's performance evolved over time?",
      req: "US-7",
      regTitle: "PRA SS1/23 Principle 3 (ongoing monitoring)",
      body: '<div class="chart-block">'
        + '<p class="muted small">Toggle individual KPI trend lines on or off (FR-5-2). RAG is plotted on an ordinal scale: Green (lowest) → Amber → Red (highest) (FR-1-4).</p>'
        + '<div class="kpi-toggles">' + chips + '</div>'
        + chart + '</div>',
      foot: 'FR-1 Model RAG trend across runs with optional per-KPI lines. Missing runs hold the last observation (FR-6-1).'
    });
  }

  // ---- US-8 : KPI deterioration list (latest vs previous run) ----
  function us8(model) {
    var down = model.kpis.filter(function (k) { return F.isDowngrade(k.prev, k.cur); })
      .sort(function (a, b) { return F.RAG_ORDER[b.cur] - F.RAG_ORDER[a.cur]; });

    var body;
    if (!down.length) {
      body = '<div class="confirm-msg">✓ No KPI deterioration detected between the latest run (' + F.dateLabel(model.latestRunDate) + ') and the previous run (' + F.dateLabel(model.prevRunDate) + ').</div>';
    } else {
      var rows = down.map(function (k) {
        return '<tr>'
          + '<td>' + esc(k.group) + '</td>'
          + '<td>' + esc(k.subGroup) + '</td>'
          + '<td>' + esc(k.name) + (k.isKey ? ' <span class="pill pill--key">Key</span>' : '') + '</td>'
          + '<td class="kpi-cell kpi-cell--' + k.cur + '"><span class="rag rag--' + k.cur + '">' + F.RAG_LABEL[k.cur] + '</span></td>'
          + '<td><span class="rag rag--' + k.prev + '">' + F.RAG_LABEL[k.prev] + '</span></td>'
          + '</tr>';
      }).join("");
      body = '<table class="grid-table"><thead><tr>'
        + '<th scope="col">KPI Group</th><th scope="col">KPI Sub-Group</th><th scope="col">KPI Name</th>'
        + '<th scope="col">Latest RAG</th><th scope="col">Previous RAG</th></tr></thead>'
        + '<tbody>' + rows + '</tbody></table>';
    }

    return card({
      title: "KPI deterioration — latest vs previous run",
      q: "Are any KPIs deteriorating in performance (latest run vs previous run)?",
      req: "US-8",
      regTitle: "PRA SS1/23 Principle 3 · Principle 5 (Model risk mitigants)",
      body: body,
      foot: 'FR-1 Lists only KPIs downgraded between the latest run (' + F.dateLabel(model.latestRunDate) + ') and the immediately-preceding run (' + F.dateLabel(model.prevRunDate) + ').'
    });
  }

  function currentModel() {
    var id = MRA.state.selectedModelId;
    return MRA.data.models.filter(function (m) { return m.id === id; })[0] || MRA.data.models[0];
  }

  function render() {
    var model = currentModel();
    return selector(model) + us6(model) + us7(model) + us8(model);
  }

  MRA.tabs = MRA.tabs || {};
  MRA.tabs.model = { render: render, currentModel: currentModel };
})();
