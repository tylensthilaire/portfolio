/* ============================================================
   Global filters (FR-4). A single shared filter state drives
   every chart and table on the High-Level view, so all
   components reconcile to the same in-scope model set
   (FR-4-1, FR-4-2). Default = all Treasury & Finance models
   (FR-4-4 / US-2 FR-4-2).
   ============================================================ */
(function () {
  "use strict";
  var MRA = window.MRA = window.MRA || {};

  var state = { fn: "", dept: "", tier: "", type: "", rag: "" };

  function match(m) {
    if (state.fn && m.fn !== state.fn) return false;
    if (state.dept && m.department !== state.dept) return false;
    if (state.tier && m.riskTier !== state.tier) return false;
    if (state.type && m.modelType !== state.type) return false;
    if (state.rag && m.rag !== state.rag) return false;
    return true;
  }

  function apply(models) {
    return (models || MRA.data.models).filter(match);
  }

  function set(key, value) { state[key] = value; }
  function reset() { state = { fn: "", dept: "", tier: "", type: "", rag: "" }; }
  function isActive() {
    return !!(state.fn || state.dept || state.tier || state.type || state.rag);
  }

  MRA.filters = {
    state: state,
    match: match,
    apply: apply,
    set: set,
    reset: reset,
    isActive: isActive,
    get: function (k) { return state[k]; }
  };
})();
