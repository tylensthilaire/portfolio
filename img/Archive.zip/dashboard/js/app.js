/* ============================================================
   Bootstrap — state, tab switching, filter wiring, model
   selection, KPI toggles/sort, cross-links and the shared
   hover tooltip. No framework, no build step.
   ============================================================ */
(function () {
  "use strict";
  var MRA = window.MRA;
  var $ = function (sel, root) { return (root || document).querySelector(sel); };

  // ---- state ----
  var firstRed = MRA.data.models.filter(function (m) { return m.rag === "r"; })[0];
  MRA.state = {
    activeTab: "highlevel",
    selectedModelId: (firstRed || MRA.data.models[0]).id,
    kpiToggles: {},
    kpiSort: "rag"
  };

  function initToggles(model) {
    var t = {};
    model.kpis.forEach(function (k) { if (k.isKey) t[k.code] = true; });
    MRA.state.kpiToggles = t;
    MRA.state.kpiSort = "rag";
  }
  initToggles(MRA.tabs.model.currentModel());

  // ---- rendering ----
  function renderHighLevel() {
    $("#hlv").innerHTML = MRA.tabs.highLevel.render();
    var n = MRA.filters.apply().length;
    $("#scope-n").textContent = n;
    $("#scope").classList.toggle("scope--filtered", MRA.filters.isActive());
  }
  function renderModel() {
    $("#mlv").innerHTML = MRA.tabs.model.render();
  }

  // ---- filters ----
  function fillSelect(id, values, labeller) {
    var sel = $("#" + id);
    values.forEach(function (v) {
      var o = document.createElement("option");
      o.value = v;
      o.textContent = labeller ? labeller(v) : v;
      sel.appendChild(o);
    });
  }
  fillSelect("f-function", MRA.data.functions);
  fillSelect("f-dept", MRA.data.departments);
  fillSelect("f-tier", MRA.data.tiers, function (t) { return MRA.fmt.TIER_LABEL[t]; });
  fillSelect("f-type", MRA.data.types);

  Array.prototype.forEach.call(document.querySelectorAll(".filterbar select"), function (sel) {
    sel.addEventListener("change", function () {
      MRA.filters.set(sel.getAttribute("data-filter"), sel.value);
      renderHighLevel();
    });
  });
  $("#f-reset").addEventListener("click", function () {
    MRA.filters.reset();
    Array.prototype.forEach.call(document.querySelectorAll(".filterbar select"), function (s) { s.value = ""; });
    renderHighLevel();
  });

  // ---- tabs ----
  function switchTab(name) {
    MRA.state.activeTab = name;
    var isHL = name === "highlevel";
    $("#tab-highlevel").setAttribute("aria-selected", isHL ? "true" : "false");
    $("#tab-model").setAttribute("aria-selected", isHL ? "false" : "true");
    $("#tab-highlevel").tabIndex = isHL ? 0 : -1;
    $("#tab-model").tabIndex = isHL ? -1 : 0;
    $("#hlv").hidden = !isHL;
    $("#mlv").hidden = isHL;
    // The filter bar is only meaningful on the portfolio view.
    $("#filterbar").classList.toggle("is-dimmed", !isHL);
    if (isHL) renderHighLevel(); else renderModel();
    var panel = isHL ? $("#hlv") : $("#mlv");
    panel.focus();
  }
  $("#tab-highlevel").addEventListener("click", function () { switchTab("highlevel"); });
  $("#tab-model").addEventListener("click", function () { switchTab("model"); });
  var tablist = $("#tabs");
  tablist.addEventListener("keydown", function (e) {
    if (e.key !== "ArrowRight" && e.key !== "ArrowLeft") return;
    switchTab(MRA.state.activeTab === "highlevel" ? "model" : "highlevel");
    (MRA.state.activeTab === "highlevel" ? $("#tab-highlevel") : $("#tab-model")).focus();
  });

  // ---- delegated interactions inside re-rendered views ----
  document.addEventListener("change", function (e) {
    var t = e.target;
    if (t.id === "model-select") {
      MRA.state.selectedModelId = t.value;
      initToggles(MRA.tabs.model.currentModel());
      renderModel();
    } else if (t.id === "kpi-sort") {
      MRA.state.kpiSort = t.value;
      renderModel();
    }
  });
  document.addEventListener("click", function (e) {
    var toggle = e.target.closest ? e.target.closest(".kpi-toggle") : null;
    if (toggle) {
      var code = toggle.getAttribute("data-kpi");
      MRA.state.kpiToggles[code] = !MRA.state.kpiToggles[code];
      renderModel();
      return;
    }
    var open = e.target.closest ? e.target.closest(".open-model") : null;
    if (open) {
      e.preventDefault();
      MRA.state.selectedModelId = open.getAttribute("data-model");
      initToggles(MRA.tabs.model.currentModel());
      switchTab("model");
    }
  });

  // ---- shared hover tooltip (FR-5-1) ----
  var tip = $("#tooltip");
  document.addEventListener("mousemove", function (e) {
    var el = e.target.closest ? e.target.closest("[data-tip]") : null;
    if (!el) { tip.classList.remove("is-on"); tip.setAttribute("aria-hidden", "true"); return; }
    tip.textContent = el.getAttribute("data-tip");
    tip.classList.add("is-on");
    tip.setAttribute("aria-hidden", "false");
    var pad = 14, tw = tip.offsetWidth, th = tip.offsetHeight;
    var x = e.clientX + pad, y = e.clientY + pad;
    if (x + tw > window.innerWidth - 8) x = e.clientX - tw - pad;
    if (y + th > window.innerHeight - 8) y = e.clientY - th - pad;
    tip.style.left = x + "px";
    tip.style.top = y + "px";
  });

  // ---- first paint ----
  renderHighLevel();
  renderModel();
})();
