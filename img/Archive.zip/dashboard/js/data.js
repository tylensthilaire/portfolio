/* ============================================================
   Fixtures — deterministically generated model-risk portfolio.

   All fabricated, prototype-fidelity. A seeded PRNG makes the
   whole dataset stable across reloads (no persistence needed).

   Each MODEL carries the full shape the requirements ask for:
     id, name, fn (Treasury/Finance), department, businessArea,
     modelType (raw) + mappedType (category), riskTier (VH/H/M/L),
     owner, developer,
     kpis[]  : {code,name,group,subGroup,isKey,history[],cur,prev}
     runs[]  : {date, ym, rag}      ← model RAG per run (US-7)
     monthEnd[]: {ym, rag}          ← 12 month-end statuses (US-3)
     rag / ragPrev                  ← current & previous model RAG
     derivation                     ← how the current RAG was derived

   Namespace: window.MRA.data
   ============================================================ */
(function () {
  "use strict";
  var MRA = window.MRA = window.MRA || {};
  var agg = MRA.rag.aggregate;

  // ---- Seeded PRNG (mulberry32) — deterministic dataset ----
  function makeRng(seed) {
    var s = seed >>> 0;
    return function () {
      s = (s + 0x6D2B79F5) | 0;
      var t = Math.imul(s ^ (s >>> 15), 1 | s);
      t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
      return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
  }
  var rng = makeRng(20260714);
  function pick(arr) { return arr[Math.floor(rng() * arr.length)]; }
  function chance(p) { return rng() < p; }
  function intBetween(lo, hi) { return lo + Math.floor(rng() * (hi - lo + 1)); }
  function shuffle(arr) {
    var a = arr.slice();
    for (var i = a.length - 1; i > 0; i--) {
      var j = Math.floor(rng() * (i + 1));
      var tmp = a[i]; a[i] = a[j]; a[j] = tmp;
    }
    return a;
  }
  function weighted(pairs) { // [[value, weight], ...]
    var total = 0, i;
    for (i = 0; i < pairs.length; i++) total += pairs[i][1];
    var r = rng() * total;
    for (i = 0; i < pairs.length; i++) { r -= pairs[i][1]; if (r <= 0) return pairs[i][0]; }
    return pairs[pairs.length - 1][0];
  }

  // ---- Reference data ----
  var TYPE_CATEGORY = {
    "PD": "Credit Risk", "LGD": "Credit Risk", "EAD": "Credit Risk",
    "IFRS9 Staging": "Impairment", "IFRS9 ECL": "Impairment",
    "Stress": "Capital & Stress", "Capital": "Capital & Stress",
    "LCR": "Liquidity Risk", "NSFR": "Liquidity Risk",
    "IRRBB": "Treasury Risk",
    "VaR": "Market Risk", "Counterparty": "Market Risk"
  };

  // department → { fn, types[], segments[] }
  var DEPARTMENTS = [
    { name: "Retail Credit Risk",      fn: "Finance",  types: ["PD", "LGD", "EAD"],            segments: ["Mortgages", "Cards", "Personal Loans", "Overdraft", "Unsecured"] },
    { name: "Wholesale Credit Risk",   fn: "Finance",  types: ["PD", "LGD", "EAD"],            segments: ["Corporate", "Financial Institutions", "Commercial Real Estate", "SME", "Sovereign"] },
    { name: "Impairment & IFRS9",      fn: "Finance",  types: ["IFRS9 Staging", "IFRS9 ECL"], segments: ["Retail", "Wholesale", "Cards", "Mortgages"] },
    { name: "Capital & Stress Testing",fn: "Finance",  types: ["Stress", "Capital"],          segments: ["Group", "Retail", "Wholesale", "Base", "Adverse"] },
    { name: "Liquidity Risk",          fn: "Treasury", types: ["LCR", "NSFR"],                segments: ["Group", "Retail", "Wholesale"] },
    { name: "Interest Rate Risk",      fn: "Treasury", types: ["IRRBB"],                      segments: ["EVE", "NII", "Banking Book"] },
    { name: "Market Risk",             fn: "Treasury", types: ["VaR", "Counterparty"],        segments: ["Trading Book", "Derivatives", "Rates", "FX"] },
    { name: "Funding & Balance Sheet", fn: "Treasury", types: ["Stress", "Capital"],          segments: ["Funding Plan", "Balance Sheet", "Investment Portfolio"] }
  ];

  var OWNERS = [
    "Sebastien Geroult", "Karl Rodolfo", "Sophie Pass", "Bruno Muongkhot",
    "Priya Nair", "Daniel Okafor", "Elena Rossi", "Marcus Feld", "Aisha Khan", "Tomas Vidal"
  ];
  var DEVELOPERS = [
    "Xiaole Kong", "Loic Thomson", "Charis Koukoutsi", "Songlin Yang",
    "Ravi Patel", "Nadia Iqbal", "Peter Larsson", "Grace Mwangi", "Hiro Tanaka", "Lucia Moreau"
  ];

  // KPI catalogue keyed by category.  Each entry: [code, name, group, subGroup]
  var KEY_POOL = {
    "Credit Risk":     [["GINI", "Gini / AUC", "Discrimination", "Rank ordering"], ["CAL", "Calibration gap", "Calibration", "Accuracy"], ["PSI", "Population stability (PSI)", "Stability", "Population"]],
    "Impairment":      [["CAL", "Calibration gap", "Calibration", "Accuracy"], ["TRANS", "Stage transition rate", "Transitions", "Staging"]],
    "Market Risk":     [["BACK", "Backtest exceptions", "Calibration", "Accuracy"]],
    "Treasury Risk":   [["BACK", "Backtest exceptions", "Calibration", "Accuracy"], ["SENS", "Rate-shift sensitivity", "Stability", "Sensitivity"]],
    "Liquidity Risk":  [["RATIO", "Regulatory ratio adherence", "Adequacy", "Threshold"]],
    "Capital & Stress":[["PROJ", "Projection stability", "Scenario", "Robustness"]]
  };
  var NONKEY_POOL = {
    "Credit Risk":     [["KS", "KS statistic", "Discrimination", "Rank ordering"], ["DRIFT", "Feature drift (KS)", "Stability", "Feature"], ["BIAS", "Predicted vs observed bias", "Calibration", "Bias"], ["COMPL", "Data completeness", "Data Quality", "Completeness"], ["COV", "Portfolio coverage", "Data Quality", "Coverage"], ["LAT", "Run latency", "Operational", "Timeliness"]],
    "Impairment":      [["BIAS", "Predicted vs observed bias", "Calibration", "Bias"], ["DRIFT", "Feature drift (KS)", "Stability", "Feature"], ["COMPL", "Data completeness", "Data Quality", "Completeness"], ["COV", "Portfolio coverage", "Data Quality", "Coverage"], ["RECON", "Reconciliation breaks", "Data Quality", "Controls"]],
    "Market Risk":     [["DRIFT", "Feature drift (KS)", "Stability", "Feature"], ["COMPL", "Data completeness", "Data Quality", "Completeness"], ["COV", "P&L attribution coverage", "Data Quality", "Coverage"], ["LAT", "Run latency", "Operational", "Timeliness"], ["RECON", "Reconciliation breaks", "Data Quality", "Controls"]],
    "Treasury Risk":   [["COMPL", "Data completeness", "Data Quality", "Completeness"], ["COV", "Portfolio coverage", "Data Quality", "Coverage"], ["LAT", "Run latency", "Operational", "Timeliness"], ["RECON", "Reconciliation breaks", "Data Quality", "Controls"]],
    "Liquidity Risk":  [["COMPL", "Input completeness", "Data Quality", "Completeness"], ["COV", "Portfolio coverage", "Data Quality", "Coverage"], ["LAT", "Run latency", "Operational", "Timeliness"], ["RECON", "Reconciliation breaks", "Data Quality", "Controls"], ["REFRESH", "Data refresh timeliness", "Operational", "Timeliness"]],
    "Capital & Stress":[["COMPL", "Data completeness", "Data Quality", "Completeness"], ["COV", "Scenario coverage", "Data Quality", "Coverage"], ["RECON", "Reconciliation breaks", "Data Quality", "Controls"], ["LAT", "Run latency", "Operational", "Timeliness"]]
  };

  // ---- 12-month timeline (last 12 complete months, ending Jul 2026) ----
  function buildMonths(endYear, endMonth, count) {
    var out = [];
    var y = endYear, m = endMonth;
    for (var i = 0; i < count; i++) {
      out.unshift(y + "-" + (m < 10 ? "0" + m : "" + m));
      m -= 1; if (m === 0) { m = 12; y -= 1; }
    }
    return out;
  }
  var MONTHS = buildMonths(2026, 7, 12); // ["2025-08" ... "2026-07"]

  // Ordinal helpers for the RAG random walk (0 g, 1 a, 2 r)
  var ORD = { g: 0, a: 1, r: 2 };
  var CHR = ["g", "a", "r"];

  var DRIFT = {
    stable:        { worse: 0.05, better: 0.16, start: [[0, 8], [1, 1]] },
    floored:       { worse: 0.10, better: 0.12, start: [[0, 6], [1, 2]] },
    wobbly:        { worse: 0.22, better: 0.18, start: [[0, 5], [1, 3]] },
    deteriorating: { worse: 0.30, better: 0.07, start: [[0, 4], [1, 3]] }
  };

  function walk(len, profile) {
    var d = DRIFT[profile];
    var s = weighted(d.start);
    var hist = [];
    for (var i = 0; i < len; i++) {
      var roll = rng();
      if (roll < d.worse) s = Math.min(2, s + 1);
      else if (roll < d.worse + d.better) s = Math.max(0, s - 1);
      hist.push(CHR[s]);
    }
    return hist;
  }

  // ---- Model factory ----
  var models = [];
  var TARGET = 100;
  var usedNames = {};
  var seq = 0;

  while (models.length < TARGET) {
    var dept = DEPARTMENTS[seq % DEPARTMENTS.length];
    seq += 1;
    var rawType = pick(dept.types);
    var segment = pick(dept.segments);
    var category = TYPE_CATEGORY[rawType];
    var version = "v" + intBetween(1, 5) + "." + intBetween(0, 9);

    var baseName = segment + " " + rawType;
    var name = baseName;
    if (usedNames[name]) name = baseName + " " + version;
    if (usedNames[name]) name = baseName + " #" + (models.length + 1);
    usedNames[name] = true;

    var riskTier = weighted([["VH", 20], ["H", 34], ["M", 30], ["L", 16]]);
    // higher-tier models skew toward higher-consequence types staying on-appetite
    var profile = weighted([["stable", 50], ["floored", 6], ["wobbly", 26], ["deteriorating", 18]]);
    var newlyDowngraded = chance(0.5);
    var greenWobble = chance(0.2);

    // ---- runs timeline ----
    var runDates = MONTHS.map(function (ym) { return ym + "-28"; });
    // A subset gets an extra mid-month run in the two most recent months
    // (demonstrates "latest run within a month" month-end selection, and
    //  gives US-8 a within-month latest-vs-previous comparison).
    if (chance(0.35)) {
      runDates.push("2026-06-14");
      runDates.push("2026-07-14");
    }
    runDates.sort();
    var runLen = runDates.length;
    var lastIdx = runLen - 1, prevIdx = runLen - 2;

    // ---- KPIs ----
    var keySrc = shuffle(KEY_POOL[category]);
    var nonKeySrc = shuffle(NONKEY_POOL[category]);
    var nKey = Math.min(keySrc.length, intBetween(1, 3) === 1 ? 1 : intBetween(2, keySrc.length));
    if (nKey < 1) nKey = 1;
    var nNon = Math.min(nonKeySrc.length, intBetween(3, 5));
    var chosen = [];
    var seen = {};
    keySrc.slice(0, Math.max(1, nKey)).forEach(function (k) { if (!seen[k[0]]) { seen[k[0]] = 1; chosen.push({ def: k, isKey: true }); } });
    nonKeySrc.slice(0, nNon).forEach(function (k) { if (!seen[k[0]]) { seen[k[0]] = 1; chosen.push({ def: k, isKey: false }); } });

    var kpis = chosen.map(function (c) {
      return {
        code: c.def[0], name: c.def[1], group: c.def[2], subGroup: c.def[3],
        isKey: c.isKey, history: walk(runLen, profile)
      };
    });

    // ---- profile-driven post-processing: enforce the intended model RAG
    //      at the latest run and seed realistic deteriorations. ----
    var keyK = kpis.filter(function (k) { return k.isKey; });
    var nonK = kpis.filter(function (k) { return !k.isKey; });
    var primary = keyK[0];

    if (profile === "deteriorating") {
      primary.history[lastIdx] = "r";
      primary.history[prevIdx] = newlyDowngraded ? "a" : "r";
    } else if (profile === "wobbly") {
      keyK.forEach(function (k) { if (k.history[lastIdx] === "r") k.history[lastIdx] = "a"; });
      primary.history[lastIdx] = "a";
      primary.history[prevIdx] = newlyDowngraded ? "g" : "a";
    } else if (profile === "floored") {
      keyK.forEach(function (k) { k.history[lastIdx] = "g"; });
      // trip the non-key materiality floor (branch 3) at the latest run
      var need = Math.max(1, Math.ceil(nonK.length * 0.4));
      for (var fi = 0; fi < nonK.length; fi++) {
        nonK[fi].history[lastIdx] = fi < need ? "a" : "g";
        if (fi < need) nonK[fi].history[prevIdx] = newlyDowngraded ? "g" : "a";
      }
    } else { // stable → green
      keyK.forEach(function (k) { k.history[lastIdx] = "g"; });
      if (greenWobble && nonK.length) {
        nonK.forEach(function (k, i) { k.history[lastIdx] = "g"; });
        nonK[0].history[prevIdx] = "g";
        nonK[0].history[lastIdx] = "a"; // one non-key downgrade, below the floor
      } else {
        nonK.forEach(function (k) { k.history[lastIdx] = "g"; });
      }
    }

    // ---- per-run + month-end model RAG ----
    function ragAt(idx) {
      return agg(kpis.map(function (k) { return { code: k.code, isKey: k.isKey, rag: k.history[idx] }; })).rag;
    }
    var runs = runDates.map(function (d, i) {
      return { date: d, ym: d.slice(0, 7), rag: ragAt(i) };
    });
    var monthEnd = MONTHS.map(function (ym) {
      // latest run in the month (dates sorted asc → last match wins)
      var idx = -1;
      for (var i = 0; i < runDates.length; i++) if (runDates[i].slice(0, 7) === ym) idx = i;
      return { ym: ym, rag: idx >= 0 ? runs[idx].rag : null };
    });

    kpis.forEach(function (k) {
      k.cur = k.history[lastIdx];
      k.prev = k.history[prevIdx];
    });

    var derivation = agg(kpis.map(function (k) { return { code: k.code, isKey: k.isKey, rag: k.cur }; }));

    models.push({
      id: "m-" + String(models.length + 1).padStart(3, "0"),
      name: name,
      fn: dept.fn,
      department: dept.name,
      businessArea: segment,
      modelType: rawType,
      mappedType: category,
      riskTier: riskTier,
      owner: pick(OWNERS),
      developer: pick(DEVELOPERS),
      kpis: kpis,
      runs: runs,
      monthEnd: monthEnd,
      rag: runs[lastIdx].rag,
      ragPrev: runs[prevIdx].rag,
      latestRunDate: runDates[lastIdx],
      prevRunDate: runDates[prevIdx],
      derivation: derivation
    });
  }

  // ---- distinct filter option lists (sorted, stable) ----
  function distinct(get) {
    var set = {};
    models.forEach(function (m) { set[get(m)] = 1; });
    return Object.keys(set).sort();
  }

  MRA.data = {
    models: models,
    months: MONTHS,
    functions: distinct(function (m) { return m.fn; }),
    departments: distinct(function (m) { return m.department; }),
    tiers: ["VH", "H", "M", "L"],
    types: distinct(function (m) { return m.modelType; }),
    mappedTypes: distinct(function (m) { return m.mappedType; }),
    owners: distinct(function (m) { return m.owner; })
  };
})();
