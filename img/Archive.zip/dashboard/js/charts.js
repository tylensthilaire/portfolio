/* ============================================================
   Chart primitives — hand-rolled inline SVG (zero dependencies,
   matches the sibling prototype's approach). Every data mark
   carries a data-tip attribute; a single delegated hover handler
   in app.js renders the shared tooltip (FR-5-1 interactivity).

     doughnut   — RAG distribution                (US-1 FR-1)
     vStacked   — vertical stacked columns         (US-1 FR-2, US-6 FR-2)
     hStacked   — horizontal stacked bars          (US-2 FR-1/2)
     line       — multi-series line/trend chart    (US-3, US-7)
   ============================================================ */
(function () {
  "use strict";
  var MRA = window.MRA = window.MRA || {};
  var F = MRA.fmt;
  var esc = F.escape;
  var FILL = F.RAG_FILL;
  var LABEL = F.RAG_LABEL;

  function tip(s) { return 'data-tip="' + esc(s) + '"'; }
  function niceMax(v) {
    if (v <= 5) return 5;
    var pow = Math.pow(10, Math.floor(Math.log(v) / Math.LN10));
    var step = pow / 2;
    return Math.ceil(v / step) * step;
  }

  // ---- Doughnut (CSS-stroke technique — no arc-math edge cases) ----
  function doughnut(counts, opts) {
    opts = opts || {};
    var order = ["r", "a", "g"];
    var total = counts.r + counts.a + counts.g;
    var R = 80, SW = 34, C = 2 * Math.PI * R, size = 220, cx = size / 2;
    var svg = '<svg class="chart chart--doughnut" viewBox="0 0 ' + size + ' ' + size + '" '
      + 'role="img" aria-label="RAG distribution: ' + counts.r + ' red, ' + counts.a + ' amber, ' + counts.g + ' green">';
    svg += '<circle cx="' + cx + '" cy="' + cx + '" r="' + R + '" fill="none" stroke="var(--ink-100)" stroke-width="' + SW + '"/>';
    if (total > 0) {
      var acc = 0;
      order.forEach(function (k) {
        var n = counts[k]; if (!n) return;
        var frac = n / total;
        var dash = (frac * C) + " " + (C - frac * C);
        var off = -acc * C;
        svg += '<circle class="ring-seg" cx="' + cx + '" cy="' + cx + '" r="' + R + '" fill="none" '
          + 'stroke="' + FILL[k] + '" stroke-width="' + SW + '" '
          + 'stroke-dasharray="' + dash + '" stroke-dashoffset="' + off + '" '
          + 'transform="rotate(-90 ' + cx + ' ' + cx + ')" '
          + tip(LABEL[k] + " — " + n + " (" + F.pct(n, total) + ")") + '></circle>';
        acc += frac;
      });
    }
    svg += '<text x="' + cx + '" y="' + (cx - 6) + '" class="dough-total" text-anchor="middle">' + total + '</text>';
    svg += '<text x="' + cx + '" y="' + (cx + 16) + '" class="dough-sub" text-anchor="middle">models</text>';
    svg += '</svg>';
    return svg;
  }

  function legend(keys) {
    keys = keys || ["r", "a", "g"];
    return '<ul class="legend">' + keys.map(function (k) {
      return '<li><span class="legend__dot" style="background:' + FILL[k] + '"></span>'
        + LABEL[k] + ' <span class="legend__note muted">' + F.RAG_RISK[k] + '</span></li>';
    }).join("") + '</ul>';
  }

  // ---- Vertical stacked columns ----
  // cats = [{label, sub?, segs:{r,a,g}}]
  function vStacked(cats, opts) {
    opts = opts || {};
    var W = 720, H = 320, L = 44, Rp = 16, T = 26, B = 52;
    var x0 = L, x1 = W - Rp, y0 = T, y1 = H - B;
    var plotW = x1 - x0, plotH = y1 - y0;
    var max = 0;
    cats.forEach(function (c) { max = Math.max(max, c.segs.r + c.segs.a + c.segs.g); });
    max = niceMax(max || 1);
    var yOf = function (v) { return y1 - (v / max) * plotH; };

    var svg = '<svg class="chart chart--vstack" viewBox="0 0 ' + W + ' ' + H + '" role="img" aria-label="' + esc(opts.aria || "Stacked column chart") + '">';
    // y gridlines + labels
    var ticks = 4;
    for (var t = 0; t <= ticks; t++) {
      var v = (max / ticks) * t, y = yOf(v);
      svg += '<line class="grid" x1="' + x0 + '" y1="' + y + '" x2="' + x1 + '" y2="' + y + '"/>';
      svg += '<text class="ax-y" x="' + (x0 - 8) + '" y="' + (y + 4) + '" text-anchor="end">' + Math.round(v) + '</text>';
    }
    var slot = plotW / cats.length;
    var bw = Math.min(96, slot * 0.56);
    cats.forEach(function (c, i) {
      var cxc = x0 + slot * (i + 0.5);
      var bx = cxc - bw / 2;
      var total = c.segs.r + c.segs.a + c.segs.g;
      var yTop = y1;
      ["g", "a", "r"].forEach(function (k) {
        var n = c.segs[k]; if (!n) return;
        var h = (n / max) * plotH;
        yTop -= h;
        svg += '<rect class="bar-seg" x="' + bx + '" y="' + yTop + '" width="' + bw + '" height="' + h + '" fill="' + FILL[k] + '" '
          + tip(esc(c.label) + " · " + LABEL[k] + " — " + n + " (" + F.pct(n, total) + ")") + '></rect>';
      });
      // total above bar (FR-2-2)
      svg += '<text class="bar-total" x="' + cxc + '" y="' + (yOf(total) - 6) + '" text-anchor="middle">' + total + '</text>';
      // x label (+ optional sub)
      svg += '<text class="ax-x" x="' + cxc + '" y="' + (y1 + 20) + '" text-anchor="middle">' + esc(c.label) + '</text>';
      if (c.sub) svg += '<text class="ax-x-sub" x="' + cxc + '" y="' + (y1 + 36) + '" text-anchor="middle">' + esc(c.sub) + '</text>';
    });
    svg += '<line class="axis" x1="' + x0 + '" y1="' + y1 + '" x2="' + x1 + '" y2="' + y1 + '"/>';
    svg += '</svg>';
    return svg;
  }

  // ---- Horizontal stacked bars ----
  // rows = [{label, segs:{r,a,g}}]
  function hStacked(rows, opts) {
    opts = opts || {};
    var W = 720, L = 170, Rp = 46, T = 8, B = 30, rowH = 30, gap = 8;
    var H = T + rows.length * rowH + B;
    var x0 = L, x1 = W - Rp, plotW = x1 - x0;
    var max = 0;
    rows.forEach(function (r) { max = Math.max(max, r.segs.r + r.segs.a + r.segs.g); });
    max = niceMax(max || 1);
    var xOf = function (v) { return x0 + (v / max) * plotW; };

    var svg = '<svg class="chart chart--hstack" viewBox="0 0 ' + W + ' ' + H + '" role="img" aria-label="' + esc(opts.aria || "Horizontal stacked bar chart") + '">';
    // x gridlines
    var ticks = 4, yBot = T + rows.length * rowH;
    for (var t = 0; t <= ticks; t++) {
      var v = (max / ticks) * t, x = xOf(v);
      svg += '<line class="grid" x1="' + x + '" y1="' + T + '" x2="' + x + '" y2="' + yBot + '"/>';
      svg += '<text class="ax-x" x="' + x + '" y="' + (yBot + 18) + '" text-anchor="middle">' + Math.round(v) + '</text>';
    }
    rows.forEach(function (r, i) {
      var y = T + i * rowH + gap / 2;
      var h = rowH - gap;
      var total = r.segs.r + r.segs.a + r.segs.g;
      var xCur = x0;
      svg += '<text class="ax-label" x="' + (x0 - 10) + '" y="' + (y + h / 2 + 4) + '" text-anchor="end">' + esc(r.label) + '</text>';
      ["r", "a", "g"].forEach(function (k) {
        var n = r.segs[k]; if (!n) return;
        var w = (n / max) * plotW;
        svg += '<rect class="bar-seg" x="' + xCur + '" y="' + y + '" width="' + w + '" height="' + h + '" fill="' + FILL[k] + '" '
          + tip(esc(r.label) + " · " + LABEL[k] + " — " + n + " (" + F.pct(n, total) + ")") + '></rect>';
        xCur += w;
      });
      svg += '<text class="bar-total" x="' + (xCur + 6) + '" y="' + (y + h / 2 + 4) + '" text-anchor="start">' + total + '</text>';
    });
    svg += '<line class="axis" x1="' + x0 + '" y1="' + yBot + '" x2="' + x1 + '" y2="' + yBot + '"/>';
    svg += '</svg>';
    return svg;
  }

  // ---- Line / trend chart ----
  // opts.xLabels: []           opts.yMin/yMax, opts.yTicks:[{v,label}]
  // opts.series: [{name,color,values:[],dashed,markerRag:[]}]
  function line(opts) {
    var W = 760, H = 330, L = 46, Rp = 34, T = 18, B = 46;
    var x0 = L, x1 = W - Rp, y0 = T, y1 = H - B;
    var plotW = x1 - x0, plotH = y1 - y0;
    var n = opts.xLabels.length;
    var yMin = opts.yMin, yMax = opts.yMax;
    var xOf = function (i) { return n <= 1 ? (x0 + plotW / 2) : x0 + (i / (n - 1)) * plotW; };
    var yOf = function (v) { return y1 - ((v - yMin) / (yMax - yMin)) * plotH; };

    var svg = '<svg class="chart chart--line" viewBox="0 0 ' + W + ' ' + H + '" role="img" aria-label="' + esc(opts.aria || "Trend line chart") + '">';

    // optional ordinal RAG bands (US-7 background)
    if (opts.bands) {
      var bandDefs = [{ k: "g", lo: -0.5, hi: 0.5 }, { k: "a", lo: 0.5, hi: 1.5 }, { k: "r", lo: 1.5, hi: 2.5 }];
      bandDefs.forEach(function (b) {
        var yt = yOf(b.hi), yb = yOf(b.lo);
        svg += '<rect class="band band--' + b.k + '" x="' + x0 + '" y="' + yt + '" width="' + plotW + '" height="' + (yb - yt) + '"/>';
      });
    }

    // y ticks
    opts.yTicks.forEach(function (tk) {
      var y = yOf(tk.v);
      svg += '<line class="grid" x1="' + x0 + '" y1="' + y + '" x2="' + x1 + '" y2="' + y + '"/>';
      svg += '<text class="ax-y" x="' + (x0 - 8) + '" y="' + (y + 4) + '" text-anchor="end">' + esc(tk.label) + '</text>';
    });

    // x labels (thin out if crowded)
    var everyX = n > 8 ? Math.ceil(n / 8) : 1;
    opts.xLabels.forEach(function (lab, i) {
      var isEnd = i === n - 1, isStart = i === 0;
      // show first + last always; thin the middle, but drop any regular
      // tick that would sit right next to the forced first/last label.
      if (!isStart && !isEnd) {
        if (i % everyX !== 0) return;
        if ((n - 1 - i) < everyX || i < everyX) return;
      }
      var anchor = isEnd ? "end" : (isStart ? "start" : "middle");
      svg += '<text class="ax-x" x="' + xOf(i) + '" y="' + (y1 + 20) + '" text-anchor="' + anchor + '">' + esc(lab) + '</text>';
    });

    // series
    opts.series.forEach(function (s) {
      var pts = s.values.map(function (v, i) { return xOf(i) + "," + yOf(v); }).join(" ");
      svg += '<polyline class="series-line' + (s.dashed ? " series-line--dashed" : "") + '" points="' + pts + '" '
        + 'style="stroke:' + s.color + '" fill="none"/>';
      s.values.forEach(function (v, i) {
        var mc = (s.markerRag && s.markerRag[i]) ? FILL[s.markerRag[i]] : s.color;
        var tt = opts.pointTip ? opts.pointTip(s, i, v) : (s.name + " · " + opts.xLabels[i] + " · " + v);
        svg += '<circle class="series-dot" cx="' + xOf(i) + '" cy="' + yOf(v) + '" r="4.5" style="fill:' + mc + '" ' + tip(tt) + '></circle>';
      });
    });

    svg += '<line class="axis" x1="' + x0 + '" y1="' + y1 + '" x2="' + x1 + '" y2="' + y1 + '"/>';
    svg += '</svg>';
    return svg;
  }

  MRA.charts = { doughnut: doughnut, legend: legend, vStacked: vStacked, hStacked: hStacked, line: line };
})();
