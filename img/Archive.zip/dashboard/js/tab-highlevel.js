/* ============================================================
   TAB 1 — High-Level (Portfolio) View
   Covers US-1, US-2, US-3, US-5. Every component reads the same
   globally-filtered model set (FR-4). All visuals reconcile to
   the in-scope total shown in the filter bar (FR-4-2).
   ============================================================ */
(function () {
  "use strict";
  var MRA = window.MRA = window.MRA || {};
  var F = MRA.fmt, C = MRA.charts, esc = F.escape;

  function tally(items, get) { return F.tally(items, get); }

  function card(opts) {
    return ''
      + '<section class="card">'
      +   '<header class="card__head">'
      +     '<div>'
      +       '<h2 class="card__title">' + esc(opts.title) + '</h2>'
      +       (opts.q ? '<p class="card__q">' + esc(opts.q) + '</p>' : '')
      +     '</div>'
      +     '<span class="req-tag" title="' + esc(opts.regTitle || "") + '">' + esc(opts.req) + '</span>'
      +   '</header>'
      +   '<div class="card__body">' + opts.body + '</div>'
      +   (opts.foot ? '<footer class="card__foot muted">' + opts.foot + '</footer>' : '')
      + '</section>';
  }

  function emptyState(msg) {
    return '<div class="empty">' + esc(msg || "No data available") + '</div>';
  }

  // ---- US-1 : overall risk profile (doughnut + tier stack + KPI table) ----
  function us1(models) {
    if (!models.length) return card({ title: "Overall model-risk profile", q: "What is the overall risk profile of our model risk across Treasury & Finance?", req: "US-1", regTitle: "PRA SS1/23 Principle 2 (Governance)", body: emptyState() });

    var dist = tally(models, function (m) { return m.rag; });
    var total = models.length;

    // FR-1 doughnut
    var doughBlock = ''
      + '<div class="chart-block chart-block--dough">'
      +   C.doughnut(dist)
      +   '<div class="dough-side">'
      +     C.legend(["r", "a", "g"])
      +     '<ul class="mini-stats">'
      +       '<li><span class="rag-dot rag-dot--r"></span>Red <strong>' + dist.r + '</strong><em>' + F.pct(dist.r, total) + '</em></li>'
      +       '<li><span class="rag-dot rag-dot--a"></span>Amber <strong>' + dist.a + '</strong><em>' + F.pct(dist.a, total) + '</em></li>'
      +       '<li><span class="rag-dot rag-dot--g"></span>Green <strong>' + dist.g + '</strong><em>' + F.pct(dist.g, total) + '</em></li>'
      +     '</ul>'
      +   '</div>'
      + '</div>';

    // FR-2 risk tiering by RAG (descending criticality VH→H→M→L)
    var tierCats = F.TIER_ORDER.map(function (t) {
      var inTier = models.filter(function (m) { return m.riskTier === t; });
      return { label: F.TIER_LABEL[t], segs: tally(inTier, function (m) { return m.rag; }) };
    });
    var tierBlock = '<div class="chart-block"><h3 class="sub-h">Risk tiering by RAG</h3>'
      + C.vStacked(tierCats, { aria: "Model counts by risk tier, split by RAG" }) + '</div>';

    // FR-3 primary risk KPI table (Key vs Non-Key)
    var keyT = { r: 0, a: 0, g: 0 }, nonT = { r: 0, a: 0, g: 0 };
    models.forEach(function (m) {
      m.kpis.forEach(function (k) {
        (k.isKey ? keyT : nonT)[k.cur] += 1;
      });
    });
    var totT = { r: keyT.r + nonT.r, a: keyT.a + nonT.a, g: keyT.g + nonT.g };
    function kpiRow(label, t, cls) {
      var sum = t.r + t.a + t.g;
      function cell(k) {
        return '<td class="kpi-cell kpi-cell--' + k + '"><strong>' + t[k] + '</strong> <span class="muted">' + F.pct(t[k], sum) + '</span></td>';
      }
      return '<tr class="' + (cls || "") + '"><th scope="row">' + esc(label) + '</th>'
        + cell("r") + cell("a") + cell("g")
        + '<td class="kpi-cell kpi-cell--tot">' + sum + '</td></tr>';
    }
    var kpiTable = '<div class="chart-block"><h3 class="sub-h">Primary risk KPIs — Key vs Non-Key</h3>'
      + '<table class="grid-table kpi-summary"><thead><tr><th scope="col">KPI class</th>'
      + '<th scope="col">Red</th><th scope="col">Amber</th><th scope="col">Green</th><th scope="col">Total</th></tr></thead>'
      + '<tbody>'
      + kpiRow("Key KPIs", keyT)
      + kpiRow("Non-Key KPIs", nonT)
      + kpiRow("Total", totT, "row-total")
      + '</tbody></table></div>';

    return card({
      title: "Overall model-risk profile",
      q: "What is the overall risk profile of our model risk across Treasury & Finance?",
      req: "US-1",
      regTitle: "PRA SS1/23 Principle 2 (Governance) · Principle 1.2 (Model Inventory)",
      body: '<div class="grid-2">' + doughBlock + tierBlock + '</div>' + kpiTable,
      foot: 'FR-1 Overall RAG distribution · FR-2 Risk tiering by RAG · FR-3 Key-vs-Non-Key KPI summary. Counts reconcile to <strong>' + total + '</strong> in-scope models (FR-4-2).'
    });
  }

  // ---- US-2 : concentration by owner + by model type ----
  function us2(models) {
    if (!models.length) return card({ title: "Concentration of model risk", q: "Which departments or teams currently represent the highest concentration of model risk?", req: "US-2", body: emptyState() });

    function grouped(get) {
      var by = {};
      models.forEach(function (m) {
        var g = get(m);
        by[g] = by[g] || { r: 0, a: 0, g: 0 };
        by[g][m.rag] += 1;
      });
      return Object.keys(by).map(function (label) {
        return { label: label, segs: by[label] };
      }).sort(function (a, b) {
        if (b.segs.r !== a.segs.r) return b.segs.r - a.segs.r;
        return (b.segs.r + b.segs.a + b.segs.g) - (a.segs.r + a.segs.a + a.segs.g);
      });
    }

    var byOwner = grouped(function (m) { return m.owner; });
    var byType = grouped(function (m) { return m.mappedType; });

    var body = '<div class="grid-2">'
      + '<div class="chart-block"><h3 class="sub-h">Model risk by Model Owner</h3>'
      +   C.hStacked(byOwner, { aria: "Model counts by owner, split by RAG" }) + '</div>'
      + '<div class="chart-block"><h3 class="sub-h">Model risk by Model Type <span class="muted">(mapped category)</span></h3>'
      +   C.hStacked(byType, { aria: "Model counts by mapped model type, split by RAG" }) + '</div>'
      + '</div>';

    return card({
      title: "Concentration of model risk",
      q: "Which departments or teams currently represent the highest concentration of model risk?",
      req: "US-2",
      regTitle: "PRA SS1/23 Principle 1.2 (Model Inventory) · Principle 2 (Governance)",
      body: body,
      foot: 'FR-1 Model risk by owner · FR-2 by mapped model type. Sorted by Red concentration.'
    });
  }

  // ---- US-3 : RAG trend over last 12 months (month-end) ----
  function us3(models) {
    var months = MRA.data.months;
    if (!models.length) return card({ title: "Model-health trend — 12 months", q: "How has model health (RAG) changed over the last 12 months?", req: "US-3", body: emptyState() });

    var series = { r: [], a: [], g: [] };
    months.forEach(function (ym) {
      var t = { r: 0, a: 0, g: 0 };
      models.forEach(function (m) {
        var me = m.monthEnd.find(function (x) { return x.ym === ym; });
        if (me && me.rag) t[me.rag] += 1;
      });
      series.r.push(t.r); series.a.push(t.a); series.g.push(t.g);
    });
    var max = 0;
    months.forEach(function (_, i) { max = Math.max(max, series.r[i], series.a[i], series.g[i]); });
    var yMax = Math.max(5, Math.ceil(max / 5) * 5);
    var yTicks = [];
    for (var t = 0; t <= 4; t++) { var v = (yMax / 4) * t; yTicks.push({ v: v, label: Math.round(v) }); }

    var xLabels = months.map(F.monthLabel);
    var chart = C.line({
      aria: "Monthly count of red, amber and green models over the last 12 months",
      xLabels: xLabels, yMin: 0, yMax: yMax, yTicks: yTicks, bands: false,
      series: [
        { name: "Red", color: F.RAG_FILL.r, values: series.r },
        { name: "Amber", color: F.RAG_FILL.a, values: series.a },
        { name: "Green", color: F.RAG_FILL.g, values: series.g }
      ],
      pointTip: function (s, i, v) { return F.monthLabel(months[i]) + " · " + s.name + " — " + v + " models"; }
    });

    return card({
      title: "Model-health trend — last 12 months",
      q: "How has model health (RAG) changed over the last 12 months?",
      req: "US-3",
      regTitle: "PRA SS1/23 Principle 3 (ongoing monitoring)",
      body: '<div class="chart-block">' + C.legend(["r", "a", "g"]) + chart + '</div>',
      foot: 'FR-1 Monthly R/A/G counts using <strong>month-end</strong> RAG (latest run per calendar month) across ' + months.length + ' months.'
    });
  }

  // ---- US-5 : deterioration watchlist (expandable) ----
  function us5(models) {
    var watch = models.filter(function (m) {
      var modelDown = F.isDowngrade(m.ragPrev, m.rag);
      var kpiDown = m.kpis.some(function (k) { return F.isDowngrade(k.prev, k.cur); });
      return modelDown || kpiDown;
    }).sort(function (a, b) {
      return F.RAG_ORDER[b.rag] - F.RAG_ORDER[a.rag];
    });

    var body;
    if (!watch.length) {
      body = '<div class="confirm-msg">✓ No deteriorations detected in the current scope. All in-scope models held or improved their RAG at the latest run.</div>';
    } else {
      var head = '<div class="watch-head">'
        + '<span>Tier</span><span>Model</span><span>Owner</span><span>Developer</span><span>Δ RAG</span><span>Red KPIs</span>'
        + '</div>';
      var rows = watch.map(function (m) {
        var reds = m.kpis.filter(function (k) { return k.cur === "r"; });
        var downgraded = m.kpis.filter(function (k) { return F.isDowngrade(k.prev, k.cur); });
        var chips = (reds.length ? reds : downgraded).map(function (k) {
          return '<span class="kpi-chip kpi-chip--' + k.cur + '">' + esc(k.name)
            + '<em>' + F.RAG_LABEL[k.prev] + '→' + F.RAG_LABEL[k.cur] + '</em></span>';
        }).join("");
        var deltaTxt = F.isDowngrade(m.ragPrev, m.rag)
          ? '<span class="delta delta--down">' + F.RAG_LABEL[m.ragPrev] + ' → ' + F.RAG_LABEL[m.rag] + '</span>'
          : '<span class="delta muted">held · KPI downgrade</span>';
        return ''
          + '<details class="watch-row">'
          +   '<summary>'
          +     '<span class="tier-pill tier-pill--' + m.riskTier.toLowerCase() + '">' + m.riskTier + '</span>'
          +     '<span class="watch-name"><a href="#" class="open-model" data-model="' + esc(m.id) + '">' + esc(m.name) + '</a><small class="muted">' + esc(m.department) + '</small></span>'
          +     '<span>' + esc(m.owner) + '</span>'
          +     '<span>' + esc(m.developer) + '</span>'
          +     '<span>' + deltaTxt + '</span>'
          +     '<span class="watch-redcount">' + (reds.length ? '<span class="rag rag--r">' + reds.length + ' Red</span>' : '<span class="muted">—</span>') + '</span>'
          +   '</summary>'
          +   '<div class="watch-detail">'
          +     '<p class="muted small">KPIs driving the downgrade (latest vs previous run):</p>'
          +     '<div class="kpi-chips">' + (chips || '<span class="muted">No KPI-level change recorded.</span>') + '</div>'
          +   '</div>'
          + '</details>';
      }).join("");
      body = head + '<div class="watch-list">' + rows + '</div>';
    }

    return card({
      title: "Deterioration watchlist",
      q: "Are any key models / KPIs deteriorating in performance?",
      req: "US-5",
      regTitle: "PRA SS1/23 Principle 3 · Principle 5 (Model risk mitigants)",
      body: body,
      foot: 'FR-1 Models downgraded in RAG or KPI status · comparison = latest vs immediately-preceding run (FR-6-2). Expand a row for the associated Red KPIs (FR-5-1).'
    });
  }

  function render() {
    var models = MRA.filters.apply();
    return us1(models) + us2(models) + us3(models) + us5(models);
  }

  MRA.tabs = MRA.tabs || {};
  MRA.tabs.highLevel = { render: render };
})();
