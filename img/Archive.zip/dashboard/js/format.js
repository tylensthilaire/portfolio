/* ============================================================
   MPMP RAG Analytics — small formatting / helper utilities.
   Namespace: window.MRA (Model Risk Analytics)
   ============================================================ */
(function () {
  "use strict";
  var MRA = window.MRA = window.MRA || {};

  function escape(s) {
    if (s === undefined || s === null) return "";
    return String(s)
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;")
      .replace(/'/g, "&#39;");
  }

  // RAG vocabulary — 'r' | 'a' | 'g'. Ordinal: Green < Amber < Red (US-7 FR-1-4).
  var RAG_ORDER = { g: 0, a: 1, r: 2 };
  var RAG_FROM_ORDER = ["g", "a", "r"];
  var RAG_LABEL = { r: "Red", a: "Amber", g: "Green" };
  var RAG_RISK = { r: "High risk", a: "Medium risk", g: "Low risk" };
  // Solid colours pulled from the shared tokens (kept in JS for SVG fills).
  var RAG_FILL = { r: "#b33a2f", a: "#b58200", g: "#2f7a4d" };
  var RAG_KEYS = ["r", "a", "g"];

  var TIER_LABEL = { VH: "Very High", H: "High", M: "Medium", L: "Low" };
  var TIER_ORDER = ["VH", "H", "M", "L"]; // FR-2-4 descending criticality

  function pct(n, total) {
    if (!total) return "0%";
    return Math.round((n / total) * 100) + "%";
  }
  function pct1(n, total) {
    if (!total) return "0.0%";
    return ((n / total) * 100).toFixed(1) + "%";
  }

  // Worse-than comparison for downgrade detection.
  function isDowngrade(fromRag, toRag) {
    return RAG_ORDER[toRag] > RAG_ORDER[fromRag];
  }

  // Count RAG occurrences in an array of models/kpis via accessor.
  function tally(items, get) {
    var t = { r: 0, a: 0, g: 0 };
    items.forEach(function (it) {
      var v = get ? get(it) : it;
      if (t[v] !== undefined) t[v] += 1;
    });
    return t;
  }

  var MONTHS = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
  function monthLabel(ym) { // ym = "2026-07"
    var p = ym.split("-");
    return MONTHS[parseInt(p[1], 10) - 1] + " " + p[0].slice(2);
  }
  function dateLabel(d) { // "2026-07-08" -> "8 Jul 26"
    var p = d.split("-");
    return parseInt(p[2], 10) + " " + MONTHS[parseInt(p[1], 10) - 1] + " " + p[0].slice(2);
  }

  MRA.fmt = {
    escape: escape,
    RAG_ORDER: RAG_ORDER,
    RAG_FROM_ORDER: RAG_FROM_ORDER,
    RAG_LABEL: RAG_LABEL,
    RAG_RISK: RAG_RISK,
    RAG_FILL: RAG_FILL,
    RAG_KEYS: RAG_KEYS,
    TIER_LABEL: TIER_LABEL,
    TIER_ORDER: TIER_ORDER,
    pct: pct,
    pct1: pct1,
    isDowngrade: isDowngrade,
    tally: tally,
    monthLabel: monthLabel,
    dateLabel: dateLabel
  };
})();
