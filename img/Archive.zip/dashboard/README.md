# MPMP — Performance Dashboard Prototype

A **second, parallel** prototype for the MPMP, built to the requirements
matrix (US-1…US-8 and FR-* traceability is surfaced in the UI). Where the
sibling app at the repo root is a
_journey_ tool (triage → investigation → remediation), this one is an
**analytics dashboard**: a portfolio "health snapshot" plus a model-level
drill-down, driven entirely by RAG (Red / Amber / Green) status.

Both apps live in the same repo (monorepo-style), share the design
tokens and fonts, and are served by the same zero-dependency `../server.js`.
Nothing in the original prototype was changed except one additive tweak to the
server (it now serves a folder's `index.html`, so each app can live in its own
directory).

## Run

```bash
cd ..                     # repo root, where server.js lives
node server.js            # http://localhost:8080
```

| App | URL |
| :-- | :-- |
| Prototype hub (landing) | http://localhost:8080/ |
| Analytics dashboard (this) | http://localhost:8080/dashboard/ |
| Journeys prototype | http://localhost:8080/journeys.html |

Zero dependencies — Node built-ins only, vanilla JS, hand-rolled inline-SVG
charts. No build step.

## What's implemented — mapped to the requirements

Two tabs, matching the two tabs in the requirements spec. Every User Story
(US-*) and Functional Requirement (FR-*) reference is surfaced in the UI
(the small `US-n` tag on each card, and the FR notes in each card footer) so
the prototype is traceable back to the matrix.

### Tab 1 — High-Level View (Portfolio)

| US | Requirement | In the UI |
| :-- | :-- | :-- |
| **US-1** | Overall risk profile | RAG **doughnut** (counts + %), **risk-tiering stacked columns** (VH→H→M→L, FR-2-4), **Key-vs-Non-Key KPI summary table** with conditional formatting |
| **US-2** | Concentration of risk | **Model risk by Model Owner** and **by mapped Model Type** — horizontal stacked bars, sorted by Red concentration |
| **US-3** | 12-month health trend | **Line chart** of monthly R/A/G model counts using **month-end** RAG (latest run per calendar month) |
| **US-5** | Deterioration watchlist | **Expandable table** (Tier · Model · Owner · Developer · Δ RAG · Red KPIs); expand a row for the associated Red KPIs. Empty → confirmation message |

### Tab 2 — Model-Level View (single model)

| US | Requirement | In the UI |
| :-- | :-- | :-- |
| **US-6** | Current RAG & drivers | **Status card** (one RAG, latest run, driver + rule branch), **KPI RAG breakdown** stacked column (Key vs Non-Key), **sortable KPI detail table** |
| **US-7** | Performance over time | **Ordinal RAG-band line chart** (Green→Amber→Red, FR-1-4) of model RAG per run, with **toggleable per-KPI trend lines** |
| **US-8** | KPI deterioration | **Table** of KPIs downgraded between the latest run and the immediately-preceding run (Group · Sub-Group · Name · Latest · Previous). Empty → "No KPI deterioration detected" |

> **US-4** is not present in the requirement images (they jump US-3 → US-5), so
> it is intentionally omitted rather than invented.

### Cross-cutting

- **Global filters (FR-4)** — Function · Department · Risk Tier · Model Type ·
  RAG apply consistently to every High-Level component; all visuals reconcile
  to the **"N models in scope"** count shown top-right (FR-4-2). Default =
  all Treasury & Finance models (FR-4-4).
- **Interactivity (FR-5)** — hover any chart mark for counts/percentages;
  expand/collapse watchlist rows; toggle KPI trend lines; sort the KPI table.
- **Validation (FR-6)** — "No data available" on empty scope; confirmation
  messages when no deterioration is found; 12 months always render.

## Data

`js/data.js` **deterministically generates ~100 models** (seeded PRNG, stable
across reloads) across Treasury & Finance, 8 departments, 6 mapped model-type
categories, 4 risk tiers, 10 owners/developers. Each model carries:

- KPIs with `group` / `subGroup` / Key-vs-Non-Key classification;
- a per-run RAG history over the **last 12 complete months** (Aug 2025 – Jul
  2026), some months with an extra mid-month run to exercise the month-end
  "latest run in month" rule;
- current and previous run states for latest-vs-previous comparisons.

The scale (`TARGET = 100` in `js/data.js`) is easy to change.

## Model-level RAG rule (shared assumption)

The overall model RAG is derived from its KPIs using the **same assumed rule**
as the journey app — _"Key-KPI dominance with materiality floor"_ (`js/rag.js`):

1. Any **Key** KPI Red → Red
2. Any **Key** KPI Amber → Amber
3. ≥30% non-key A+R, or ≥15% non-key Red → Amber
4. Otherwise → Green

The source docs leave model-level aggregation open; this is an assumption,
surfaced on the status card (which branch fired). The same rule is applied to
every historical run to build the trend charts.

## Structure

```
dashboard/
├── index.html            # shell: top bar, tabs, global filter bar
├── css/
│   ├── app.css           # layout, cards, tables, status card, watchlist
│   └── charts.css        # inline-SVG chart marks, legend, tooltip
└── js/
    ├── format.js         # escape, RAG vocab, ordinal, percentages
    ├── rag.js            # shared aggregation rule + per-run derivation
    ├── data.js           # deterministic ~100-model generator
    ├── charts.js         # doughnut · vStacked · hStacked · line
    ├── filters.js        # global filter state (FR-4)
    ├── tab-highlevel.js  # Tab 1 — US-1/2/3/5
    ├── tab-model.js      # Tab 2 — US-6/7/8
    └── app.js            # state, tabs, wiring, tooltip, cross-links
```

Uses `../css/tokens.css` and `../assets/*.woff2` from the sibling app for the
shared design system (deep-purple primary, gold accent, Knile display
+ RN House Sans body).

## Not covered (prototype scope)

- Real data / persistence (all fabricated, in-memory)
- Auth, ownership checks, notifications/SLA
- Loading & error states beyond the specified "no data" / "no deterioration"
- US-4 (absent from the source requirement images)
