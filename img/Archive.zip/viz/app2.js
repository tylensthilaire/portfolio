/* =====================================================================
   v2 — 3D Grid Interaction with Content Preview
   Dependency-free port of the Codrops demo (codrops/3DGridContentPreview,
   MIT) adapted to use our six live test-suite visualisations as the grid
   content. No GSAP / Splitting / CDN — runs offline from file://.
   ===================================================================== */
(function () {
  "use strict";
  var TV = window.TestViz;

  /* ---------- math + helpers (ported from utils.js) ---------- */
  var lerp = function (a, b, n) { return (1 - n) * a + n * b; };
  var map = function (x, a, b, c, d) { return (x - a) * (d - c) / (b - a) + c; };
  var clamp = function (v, a, b) { return Math.max(a, Math.min(b, v)); };
  var rand = function (min, max) { return Math.floor(Math.random() * (max - min + 1) + min); };
  var pad = function (n) { return (n < 10 ? "0" : "") + n; };

  /* ---------- easings ---------- */
  var easeOutExpo = function (p) { return p >= 1 ? 1 : 1 - Math.pow(2, -10 * p); };
  var easeInOutExpo = function (p) {
    if (p <= 0) return 0; if (p >= 1) return 1;
    return p < 0.5 ? Math.pow(2, 20 * p - 10) / 2 : (2 - Math.pow(2, -20 * p + 10)) / 2;
  };

  /* ---------- tiny tween engine (replaces gsap timelines) ---------- */
  function animate(opts) {
    var dur = opts.duration || 600, delay = opts.delay || 0;
    var ease = opts.ease || easeOutExpo, onUpdate = opts.onUpdate, onComplete = opts.onComplete;
    var startT = null, raf;
    function step(ts) {
      if (startT === null) startT = ts;
      var el = ts - startT - delay;
      if (el < 0) { raf = requestAnimationFrame(step); return; }
      var p = dur <= 0 ? 1 : Math.min(1, el / dur);
      if (onUpdate) onUpdate(ease(p), p);
      if (p < 1) raf = requestAnimationFrame(step); else if (onComplete) onComplete();
    }
    raf = requestAnimationFrame(step);
    return { cancel: function () { if (raf) cancelAnimationFrame(raf); } };
  }

  /* ---------- split a text node into .char spans ---------- */
  function splitChars(el) {
    var text = el.textContent;
    el.textContent = "";
    var chars = [];
    for (var i = 0; i < text.length; i++) {
      var s = document.createElement("span");
      s.className = "char";
      s.textContent = text[i] === " " ? " " : text[i];
      el.appendChild(s);
      chars.push(s);
    }
    return chars;
  }

  /* ---------- shared pointer + viewport state ---------- */
  var winsize = { width: window.innerWidth, height: window.innerHeight };
  var mouse = { x: winsize.width / 2, y: winsize.height / 2 };
  window.addEventListener("resize", function () { winsize = { width: window.innerWidth, height: window.innerHeight }; });
  window.addEventListener("mousemove", function (e) { mouse.x = e.clientX; mouse.y = e.clientY; });

  /* ===================================================================
     Custom cursor (ported from cursor.js)
     =================================================================== */
  function Cursor(el) {
    this.el = el;
    this.svg = el.querySelector(".cursor__svg");
    this.circle = el.querySelector(".cursor__svg-circle");
    this.text = el.querySelector(".cursor__text");
    this.bounds = this.svg.getBoundingClientRect();
    this.shown = false;
    this.s = {
      tx: { p: 0, c: 0, amt: 0.2 }, ty: { p: 0, c: 0, amt: 0.2 },
      ttx: { p: 0, c: 0, amt: 0.1 }, tty: { p: 0, c: 0, amt: 0.1 },
      scale: { p: 1, c: 1, amt: 0.15 }
    };
  }
  Cursor.prototype.enter = function () { this.s.scale.c = 1.5; };
  Cursor.prototype.leave = function () { this.s.scale.c = 1; };
  Cursor.prototype.setText = function (t) { if (this.text) this.text.innerHTML = t || ""; };
  Cursor.prototype.render = function () {
    var hw = this.bounds.width / 2, hh = this.bounds.height / 2;
    this.s.tx.c = this.s.ttx.c = mouse.x - hw;
    this.s.ty.c = this.s.tty.c = mouse.y - hh;
    for (var k in this.s) this.s[k].p = lerp(this.s[k].p, this.s[k].c, this.s[k].amt);
    if (!this.shown && (mouse.x || mouse.y)) { this.el.style.opacity = 1; this.shown = true; }
    this.svg.style.transform = "translateX(" + this.s.tx.p + "px) translateY(" + this.s.ty.p + "px)";
    if (this.text) this.text.style.transform = "translateX(" + this.s.ttx.p + "px) translateY(" + this.s.tty.p + "px)";
    this.circle.style.transform = "scale(" + this.s.scale.p + ")";
  };

  /* ===================================================================
     Grid item — live thumbnail + 3D parallax (ported from gridItem.js)
     =================================================================== */
  function GridItem(a, img, frame, root, demo, index) {
    this.el = a; this.img = img; this.frame = frame; this.root = root;
    this.demo = demo; this.index = index; this.title = demo.title;

    this.tv = { x: 0, y: 0 };           // translation vals (lerped)
    this.rv = { x: 0, y: 0 };           // rotation vals (lerped)
    this.xstart = rand(70, 100);
    this.ystart = rand(40, 65);
    this.rxstart = 5; this.rystart = 10;

    this.st = { tx: 0, ty: 0, tz: 0, rx: 0, ry: 0, scale: 1.5, opacity: 0, exitY: 0 };

    // magnetic state for the inner image
    this.m = { x: 0, y: 0, scale: 1, hover: false, cx: 0, cy: 0 };

    this.layout();
    this.measureMount();
    this.initMagnetic();
  }
  GridItem.prototype.layout = function () {
    var r = this.el.getBoundingClientRect();
    this.cx = r.left + r.width / 2;
    this.cy = r.top + r.height / 2;
    this.isLeft = this.cx < winsize.width / 2;
    this.isTop = this.cy < winsize.height / 2;
    this.rYbase = this.isLeft
      ? map(this.cx, 0, winsize.width / 2, this.rystart, 0)
      : map(this.cx, winsize.width / 2, winsize.width, 0, -this.rystart);
    this.rXbase = this.isTop
      ? map(this.cy, 0, winsize.height / 2, -this.rxstart, 0)
      : map(this.cy, winsize.height / 2, winsize.height, 0, this.rxstart);
    this.tZbase = this.isLeft
      ? map(this.cx, 0, winsize.width / 2, -200, -600)
      : map(this.cx, winsize.width / 2, winsize.width, -600, -200);
    this.st.rx = this.rXbase; this.st.ry = this.rYbase; this.st.tz = this.tZbase;
  };
  GridItem.prototype.measureMount = function () {
    // clientWidth/Height are layout-based (immune to the parent's 3D transform)
    var w = this.img.clientWidth || 320, h = this.img.clientHeight || 200;
    var DW = 1180, DH = Math.round(DW * h / w);
    this.frame.style.width = DW + "px";
    this.frame.style.height = DH + "px";
    this.frame.style.transform = "scale(" + (w / DW) + ")";
    this.root.style.width = "100%"; this.root.style.height = "100%";
    this.root.innerHTML = "";
    try { this.demo.mount(this.root, TV); } catch (e) { console.error("mini " + this.demo.id, e); }
  };
  GridItem.prototype.initMagnetic = function () {
    var self = this;
    this.img.addEventListener("mouseenter", function () {
      var r = self.img.getBoundingClientRect();
      self.m.cx = r.left + r.width / 2; self.m.cy = r.top + r.height / 2;
      self.m.hover = true;
    });
    this.img.addEventListener("mouseleave", function () { self.m.hover = false; });
  };
  GridItem.prototype.move = function () {
    this.tv.x = lerp(this.tv.x, map(mouse.x, 0, winsize.width, -this.xstart, this.xstart), 0.04);
    this.tv.y = lerp(this.tv.y, map(mouse.y, 0, winsize.height, -this.ystart, this.ystart), 0.04);
    this.rv.x = this.isTop
      ? lerp(this.rv.x, map(mouse.y, 0, winsize.height / 2, this.rxstart, 0), 0.04)
      : lerp(this.rv.x, map(mouse.y, winsize.height / 2, winsize.height, 0, -this.rxstart), 0.04);
    this.rv.y = this.isLeft
      ? lerp(this.rv.y, map(mouse.x, 0, winsize.width / 2, -this.rystart, 0), 0.04)
      : lerp(this.rv.y, map(mouse.x, winsize.width / 2, winsize.width, 0, this.rystart), 0.04);
    this.st.tx = -this.tv.x; this.st.ty = -this.tv.y;
    this.st.rx = -this.rXbase - this.rv.x; this.st.ry = -this.rYbase - this.rv.y;
    this.st.tz = this.tZbase;
    this.write();
  };
  GridItem.prototype.magnetic = function () {
    var tx = 0, ty = 0, ts = 1;
    if (this.m.hover) { tx = (mouse.x - this.m.cx) * 0.3; ty = (mouse.y - this.m.cy) * 0.3; ts = 1.1; }
    this.m.x = lerp(this.m.x, tx, 0.08);
    this.m.y = lerp(this.m.y, ty, 0.08);
    this.m.scale = lerp(this.m.scale, ts, 0.1);
    this.img.style.transform = "translate3d(" + this.m.x.toFixed(2) + "px," + this.m.y.toFixed(2) + "px,0) scale(" + this.m.scale.toFixed(3) + ")";
  };
  GridItem.prototype.write = function () {
    var s = this.st;
    this.el.style.transform =
      "translate3d(" + s.tx.toFixed(2) + "px," + (s.ty + s.exitY).toFixed(2) + "px," + s.tz.toFixed(2) + "px) " +
      "rotateX(" + s.rx.toFixed(2) + "deg) rotateY(" + s.ry.toFixed(2) + "deg) scale(" + s.scale.toFixed(3) + ")";
    this.el.style.opacity = s.opacity;
  };

  /* ===================================================================
     init
     =================================================================== */
  function init() {
    if (!TV || !TV.registry || !TV.registry.length) {
      document.body.classList.remove("loading");
      return;
    }
    var demos = TV.registry;
    var byId = {}; demos.forEach(function (d) { byId[d.id] = d; });

    var fine = window.matchMedia ? window.matchMedia("(pointer: fine)").matches : true;
    var reduce = !!(window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches);

    var gridEl = document.getElementById("grid");
    var cursorEl = document.querySelector(".cursor");
    var cursor = new Cursor(cursorEl);
    if (fine) document.body.classList.add("has-cursor");

    /* scattered positions on the 50x50 grid (row, col); span 11x10 (see CSS) */
    var LAYOUT = [
      { id: "status-grid", row: 7,  col: 3 },
      { id: "waffle",      row: 2,  col: 21 },
      { id: "treemap",     row: 8,  col: 38 },
      { id: "sunburst",    row: 28, col: 8 },
      { id: "trend-wall",  row: 33, col: 26 },
      { id: "quadrant",    row: 24, col: 40 }
    ];

    /* ---- build grid DOM ---- */
    var items = [];
    LAYOUT.forEach(function (cfg, i) {
      var demo = byId[cfg.id]; if (!demo) return;
      var a = document.createElement("a");
      a.className = "grid__item";
      a.href = "#" + demo.id;
      a.setAttribute("data-title", demo.title);
      a.style.setProperty("--grid-row", cfg.row);
      a.style.setProperty("--grid-column", cfg.col);

      var img = document.createElement("div"); img.className = "grid__item-img";
      var frame = document.createElement("div"); frame.className = "thumb-frame";
      var root = document.createElement("div");
      root.className = "demo-root viz-" + demo.id;
      root.style.cssText = "display:flex;min-width:0;min-height:0;";
      frame.appendChild(root);
      img.appendChild(frame);

      var label = document.createElement("div");
      label.className = "grid__item-label";
      label.innerHTML = '<span class="n">' + pad(i + 1) + '</span><span class="t">' + demo.title + "</span>";
      img.appendChild(label);

      a.appendChild(img);
      gridEl.appendChild(a);
      items.push(new GridItem(a, img, frame, root, demo, i));
    });

    document.body.classList.remove("loading");

    /* ---- giant title: split chars ---- */
    var titleLines = [].slice.call(document.querySelectorAll(".content__title-line"));
    var titleChars = [];
    titleLines.forEach(function (ln) { titleChars = titleChars.concat(splitChars(ln)); });

    /* ---- main render loop (cursor always; parallax while grid active) ---- */
    var isOpen = false;
    function renderLoop() {
      if (fine) cursor.render();
      if (!isOpen && !reduce) {
        for (var i = 0; i < items.length; i++) { items[i].move(); items[i].magnetic(); }
      }
      requestAnimationFrame(renderLoop);
    }
    // initial paint + intro
    items.forEach(function (it) { it.write(); });
    requestAnimationFrame(renderLoop);

    /* ---- intro: scale 1.5 -> 1, fade in, stagger from centre ---- */
    var cxw = winsize.width / 2, cyw = winsize.height / 2, maxD = Math.hypot(cxw, cyw) || 1;
    items.forEach(function (it) {
      var d = Math.hypot(it.cx - cxw, it.cy - cyw);
      var delay = reduce ? 0 : (1 - d / maxD) * 350;
      animate({
        duration: reduce ? 0 : 1100, delay: delay, ease: easeOutExpo,
        onUpdate: function (e) { it.st.scale = 1.5 - 0.5 * e; it.st.opacity = e; }
      });
    });

    /* ---- cursor hover wiring ---- */
    function bindHover(el, title) {
      el.addEventListener("mouseenter", function () { cursor.enter(); if (title) cursor.setText(title); });
      el.addEventListener("mouseleave", function () { cursor.leave(); cursor.setText(""); });
    }
    items.forEach(function (it) { bindHover(it.el, it.title); });

    /* ---- resize: re-measure + re-mount minis, recompute layout ---- */
    var rT;
    window.addEventListener("resize", function () {
      clearTimeout(rT);
      rT = setTimeout(function () {
        items.forEach(function (it) { it.measureMount(); });
      }, 160);
    });

    /* ===================== content preview ===================== */
    var preview = document.getElementById("preview");
    var previewItem = document.getElementById("preview-item");
    var pStage = document.getElementById("pv-stage");
    var pTitle = document.getElementById("pv-title");
    var pIndex = document.getElementById("pv-index");
    var pTag = document.getElementById("pv-tagline");
    var pHow = document.getElementById("pv-how");
    var pWhen = document.getElementById("pv-when");
    var pInfo = previewItem.querySelector(".preview__item-info");
    var pTop = previewItem.querySelector(".preview__item-top");
    var current = -1, currentDemo = null;

    function wrap(i) { return ((i % demos.length) + demos.length) % demos.length; }

    function mountPreviewDemo(demo) {
      if (currentDemo && typeof currentDemo.unmount === "function") { try { currentDemo.unmount(); } catch (e) {} }
      pStage.innerHTML = "";
      var root = document.createElement("div");
      root.className = "demo-root viz-" + demo.id;
      root.style.cssText = "flex:1 1 auto;display:flex;min-width:0;min-height:0;";
      pStage.appendChild(root);
      currentDemo = demo;
      try { demo.mount(root, TV); } catch (e) { console.error("preview " + demo.id, e); }
    }

    // animate the preview's own elements in
    function previewElementsIn() {
      var chars = splitChars(pTitle);
      chars.forEach(function (c) { c.style.transform = "translateY(110%)"; c.style.opacity = 0; });
      chars.forEach(function (c, i) {
        animate({ duration: 900, delay: 80 + i * 35, ease: easeInOutExpo,
          onUpdate: function (e) { c.style.transform = "translateY(" + (110 - 110 * e) + "%)"; c.style.opacity = e; } });
      });
      [pStage, pInfo, pTop].forEach(function (node, idx) {
        node.style.opacity = 0; node.style.transform = "translateY(24px)";
        animate({ duration: 1000, delay: 250 + idx * 90, ease: easeOutExpo,
          onUpdate: function (e) { node.style.opacity = e; node.style.transform = "translateY(" + (24 - 24 * e) + "px)"; } });
      });
    }

    function showPreview(i) {
      i = wrap(i); current = i;
      var demo = demos[i];
      pIndex.textContent = pad(i + 1) + " / " + pad(demos.length);
      pTitle.textContent = demo.title || demo.id;
      pTag.textContent = demo.tagline || "";
      pHow.textContent = demo.how || "";
      pWhen.textContent = demo.when || "";
      mountPreviewDemo(demo);
      previewItem.classList.add("preview__item--open");
      previewElementsIn();
    }

    function open(i) {
      if (isOpen) return; isOpen = true;
      gridEl.classList.add("grid--inactive");
      document.body.classList.add("preview-open");

      // grid flies up + fades (stagger from top)
      var byTop = items.slice().sort(function (a, b) { return a.cy - b.cy; });
      byTop.forEach(function (it, k) {
        var fly = rand(1000, 1600);
        var sy = it.st.ty, sop = it.st.opacity;
        animate({ duration: 1000, delay: k * 45, ease: easeInOutExpo,
          onUpdate: function (e) { it.st.exitY = -fly * e; it.st.opacity = sop * (1 - e); it.write(); } });
      });
      // title chars out
      titleChars.forEach(function (c, k) {
        animate({ duration: 800, delay: k * 28, ease: easeInOutExpo,
          onUpdate: function (e) { c.style.transform = "translateY(" + (-110 * e) + "%)"; c.style.opacity = 1 - e; } });
      });
      // reveal preview shortly after
      setTimeout(function () { showPreview(i); }, reduce ? 0 : 350);
    }

    function previewElementsOut(cb) {
      var chars = [].slice.call(pTitle.querySelectorAll(".char"));
      chars.forEach(function (c, i) {
        animate({ duration: 600, delay: i * 18, ease: easeInOutExpo,
          onUpdate: function (e) { c.style.transform = "translateY(" + (100 * e) + "%)"; c.style.opacity = 1 - e; } });
      });
      [pStage, pInfo, pTop].forEach(function (node) {
        animate({ duration: 600, ease: easeInOutExpo,
          onUpdate: function (e) { node.style.opacity = 1 - e; node.style.transform = "translateY(" + (20 * e) + "px)"; } });
      });
      setTimeout(cb, reduce ? 0 : 600);
    }

    function close() {
      if (!isOpen) return;
      previewElementsOut(function () {
        previewItem.classList.remove("preview__item--open");
        if (currentDemo && typeof currentDemo.unmount === "function") { try { currentDemo.unmount(); } catch (e) {} }
        currentDemo = null; pStage.innerHTML = ""; current = -1;

        // bring grid back: reset parallax, scale 0.2 -> 1, fade in (stagger from centre)
        items.forEach(function (it) { it.tv.x = it.tv.y = it.rv.x = it.rv.y = 0; it.st.exitY = 0; });
        var byCentre = items.slice().sort(function (a, b) {
          return Math.hypot(a.cx - cxw, a.cy - cyw) - Math.hypot(b.cx - cxw, b.cy - cyw);
        });
        byCentre.forEach(function (it, k) {
          animate({ duration: 900, delay: k * 45, ease: easeOutExpo,
            onUpdate: function (e) { it.st.scale = 0.2 + 0.8 * e; it.st.opacity = e; it.write(); },
            onComplete: function () { it.st.scale = 1; it.st.opacity = 1; } });
        });
        // title back in
        titleChars.forEach(function (c, k) {
          animate({ duration: 800, delay: 200 + k * 24, ease: easeInOutExpo,
            onUpdate: function (e) { c.style.transform = "translateY(" + (-110 * (1 - e)) + "%)"; c.style.opacity = e; } });
        });
        gridEl.classList.remove("grid--inactive");
        document.body.classList.remove("preview-open");
        isOpen = false;
      });
    }

    function navTo(dir) {
      if (!isOpen || current < 0) return;
      previewElementsOut(function () { showPreview(current + dir); });
    }

    // wire clicks
    items.forEach(function (it) {
      it.el.addEventListener("click", function (ev) { ev.preventDefault(); open(it.index); });
    });
    document.getElementById("pv-back").addEventListener("click", close);
    document.getElementById("pv-prev").addEventListener("click", function () { navTo(-1); });
    document.getElementById("pv-next").addEventListener("click", function () { navTo(1); });
    document.addEventListener("keydown", function (e) {
      if (!isOpen) return;
      if (e.key === "Escape") close();
      else if (e.key === "ArrowRight") navTo(1);
      else if (e.key === "ArrowLeft") navTo(-1);
    });
  }

  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", init);
  else init();
})();
