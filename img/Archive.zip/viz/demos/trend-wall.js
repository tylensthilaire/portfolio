/* =====================================================================
   TestViz — Trend Wall demo
   Small-multiples wall: each test as a 12-segment strip, grouped by
   module, sorted by flakiness descending. Flags flaky + regressing tests.
   ===================================================================== */
(function () {
  "use strict";
  if (!window.TestViz) return;

  /* ------------------------------------------------------------------ *
   * Inject scoped styles once
   * ------------------------------------------------------------------ */
  var STYLE_ID = "viz-trend-wall-styles";
  if (!document.getElementById(STYLE_ID)) {
    var s = document.createElement("style");
    s.id = STYLE_ID;
    s.textContent = [
      /* outer scroll container */
      ".viz-trend-wall {",
      "  flex-direction: column;",
      "  overflow: hidden;",
      "}",

      /* toolbar: legend + axis cue */
      ".viz-trend-wall .tw-toolbar {",
      "  flex: 0 0 auto;",
      "  display: flex;",
      "  align-items: center;",
      "  justify-content: space-between;",
      "  flex-wrap: wrap;",
      "  gap: 8px 20px;",
      "  padding: 0 2px 14px;",
      "  border-bottom: 1px solid var(--border);",
      "  margin-bottom: 16px;",
      "}",

      ".viz-trend-wall .tw-axis-cue {",
      "  display: flex;",
      "  align-items: center;",
      "  gap: 6px;",
      "  font-family: var(--mono);",
      "  font-size: 11px;",
      "  color: var(--faint);",
      "  user-select: none;",
      "}",

      ".viz-trend-wall .tw-axis-arrow {",
      "  display: flex;",
      "  align-items: center;",
      "  gap: 3px;",
      "}",

      ".viz-trend-wall .tw-axis-arrow span {",
      "  width: 32px;",
      "  height: 2px;",
      "  background: linear-gradient(to right, var(--faint), var(--muted));",
      "  border-radius: 1px;",
      "  display: inline-block;",
      "}",

      /* scrollable wall */
      ".viz-trend-wall .tw-scroll {",
      "  flex: 1 1 0;",
      "  min-height: 0;",
      "  overflow-y: auto;",
      "  overflow-x: hidden;",
      "  padding-right: 6px;",
      "}",

      ".viz-trend-wall .tw-scroll::-webkit-scrollbar {",
      "  width: 6px;",
      "}",

      ".viz-trend-wall .tw-scroll::-webkit-scrollbar-thumb {",
      "  background: var(--border-strong);",
      "  border-radius: 6px;",
      "}",

      /* module section */
      ".viz-trend-wall .tw-section {",
      "  margin-bottom: 24px;",
      "}",

      ".viz-trend-wall .tw-section-header {",
      "  display: flex;",
      "  align-items: baseline;",
      "  gap: 8px;",
      "  margin-bottom: 10px;",
      "  padding-bottom: 6px;",
      "  border-bottom: 1px solid var(--grid);",
      "}",

      ".viz-trend-wall .tw-mod-name {",
      "  font-size: 12px;",
      "  font-weight: 700;",
      "  letter-spacing: 0.1em;",
      "  text-transform: uppercase;",
      "  color: var(--text-2);",
      "}",

      ".viz-trend-wall .tw-mod-count {",
      "  font-family: var(--mono);",
      "  font-size: 11px;",
      "  color: var(--faint);",
      "}",

      /* the grid of minis */
      ".viz-trend-wall .tw-grid {",
      "  display: grid;",
      "  grid-template-columns: repeat(auto-fill, minmax(220px, 1fr));",
      "  gap: 5px 8px;",
      "}",

      /* single mini card */
      ".viz-trend-wall .tw-mini {",
      "  display: flex;",
      "  flex-direction: column;",
      "  gap: 4px;",
      "  padding: 7px 8px 7px 10px;",
      "  background: var(--panel);",
      "  border: 1px solid var(--border);",
      "  border-left: 3px solid var(--border);",
      "  border-radius: var(--radius-sm);",
      "  cursor: default;",
      "  transition: border-color 0.18s var(--ease), background 0.18s var(--ease);",
      "  opacity: 0;",
      "  transform: translateY(6px);",
      "  animation: tw-fadein 0.32s var(--ease) forwards;",
      "}",

      ".viz-trend-wall .tw-mini:hover {",
      "  background: var(--panel-2);",
      "  border-color: var(--border-strong);",
      "  border-left-color: var(--border-strong);",
      "}",

      /* flaky left-border accent */
      ".viz-trend-wall .tw-mini.is-flaky {",
      "  border-left-color: var(--skip);",
      "}",

      ".viz-trend-wall .tw-mini.is-flaky:hover {",
      "  border-left-color: var(--skip);",
      "}",

      /* regressing left-border accent (overrides flaky) */
      ".viz-trend-wall .tw-mini.is-regressing {",
      "  border-left-color: var(--fail);",
      "}",

      ".viz-trend-wall .tw-mini.is-regressing:hover {",
      "  border-left-color: var(--fail);",
      "}",

      /* name row */
      ".viz-trend-wall .tw-name-row {",
      "  display: flex;",
      "  align-items: center;",
      "  gap: 5px;",
      "  min-width: 0;",
      "}",

      ".viz-trend-wall .tw-test-name {",
      "  font-size: 11.5px;",
      "  color: var(--text-2);",
      "  white-space: nowrap;",
      "  overflow: hidden;",
      "  text-overflow: ellipsis;",
      "  flex: 1 1 0;",
      "  min-width: 0;",
      "}",

      /* small flag badges */
      ".viz-trend-wall .tw-badge {",
      "  flex: 0 0 auto;",
      "  font-family: var(--mono);",
      "  font-size: 9px;",
      "  letter-spacing: 0.06em;",
      "  padding: 1px 4px;",
      "  border-radius: 3px;",
      "  text-transform: uppercase;",
      "  font-weight: 600;",
      "  line-height: 1.5;",
      "}",

      ".viz-trend-wall .tw-badge.flaky {",
      "  background: rgba(251,191,36,0.14);",
      "  color: var(--skip);",
      "}",

      ".viz-trend-wall .tw-badge.regressing {",
      "  background: rgba(248,113,113,0.14);",
      "  color: var(--fail);",
      "}",

      /* the 12-segment strip */
      ".viz-trend-wall .tw-strip {",
      "  display: flex;",
      "  gap: 2px;",
      "  height: 8px;",
      "}",

      ".viz-trend-wall .tw-seg {",
      "  flex: 1 1 0;",
      "  border-radius: 2px;",
      "  transition: opacity 0.12s var(--ease), transform 0.12s var(--ease);",
      "}",

      ".viz-trend-wall .tw-mini:hover .tw-seg {",
      "  opacity: 0.7;",
      "}",

      ".viz-trend-wall .tw-mini:hover .tw-seg.is-hover {",
      "  opacity: 1;",
      "  transform: scaleY(1.35);",
      "}",

      /* entrance animation */
      "@keyframes tw-fadein {",
      "  to { opacity: 1; transform: translateY(0); }",
      "}",

      "@media (prefers-reduced-motion: reduce) {",
      "  .viz-trend-wall .tw-mini {",
      "    animation: none;",
      "    opacity: 1;",
      "    transform: none;",
      "  }",
      "}"
    ].join("\n");
    document.head.appendChild(s);
  }

  /* ------------------------------------------------------------------ *
   * State for unmount
   * ------------------------------------------------------------------ */
  var _tooltip = null;
  var _mousemoveHandler = null;
  var _mouseoutHandler = null;

  /* ------------------------------------------------------------------ *
   * Helpers
   * ------------------------------------------------------------------ */

  /* Detect regressing: had a pass in the first half, currently failing */
  function isRegressing(test, H) {
    var firstHalf = test.history.slice(0, Math.ceil(H / 2));
    var hadPass = firstHalf.some(function (s) { return s === "pass"; });
    var nowFail = test.history[H - 1] === "fail";
    return hadPass && nowFail;
  }

  /* Truncate to max chars with ellipsis */
  function truncate(str, max) {
    return str.length > max ? str.slice(0, max - 1) + "…" : str;
  }

  /* Position tooltip near cursor but keep it in viewport */
  function posTooltip(tooltip, cx, cy) {
    var TW = tooltip.offsetWidth || 240;
    var TH = tooltip.offsetHeight || 80;
    var vw = window.innerWidth;
    var vh = window.innerHeight;
    var x = cx + 14;
    var y = cy + 14;
    if (x + TW > vw - 8) x = cx - TW - 12;
    if (y + TH > vh - 8) y = cy - TH - 12;
    if (x < 8) x = 8;
    if (y < 8) y = 8;
    tooltip.style.left = x + "px";
    tooltip.style.top = y + "px";
  }

  /* ------------------------------------------------------------------ *
   * mount
   * ------------------------------------------------------------------ */
  function mount(root, TV) {
    var H = TV.helpers;
    var runs = TV.runs;
    var FLAKY_THRESHOLD = 0.35;

    /* --- tooltip singleton --- */
    var tooltip = document.createElement("div");
    tooltip.className = "viz-tooltip";
    tooltip.setAttribute("role", "tooltip");
    document.body.appendChild(tooltip);
    _tooltip = tooltip;

    /* ---- toolbar ---- */
    var toolbar = document.createElement("div");
    toolbar.className = "tw-toolbar";

    /* legend */
    var legend = document.createElement("div");
    legend.className = "viz-legend";
    ["pass", "fail", "skip"].forEach(function (st) {
      var key = document.createElement("span");
      key.className = "key";
      var sw = document.createElement("span");
      sw.className = "swatch";
      sw.style.background = TV.colorFor(st);
      var lbl = document.createTextNode(TV.LABELS[st]);
      key.appendChild(sw);
      key.appendChild(lbl);
      legend.appendChild(key);
    });

    /* flags legend */
    ["flaky", "regressing"].forEach(function (flag) {
      var key = document.createElement("span");
      key.className = "key";
      var badge = document.createElement("span");
      badge.className = "tw-badge " + flag;
      badge.textContent = flag;
      var lbl = document.createTextNode(
        flag === "flaky" ? " ≥ 35% volatility" : " was passing, now failing"
      );
      key.appendChild(badge);
      key.appendChild(lbl);
      legend.appendChild(key);
    });

    toolbar.appendChild(legend);

    /* axis cue */
    var axisCue = document.createElement("div");
    axisCue.className = "tw-axis-cue";
    var arrow = document.createElement("div");
    arrow.className = "tw-axis-arrow";
    arrow.innerHTML =
      "<span></span>" +
      '<svg width="8" height="10" viewBox="0 0 8 10" fill="none" aria-hidden="true">' +
      '<path d="M4 0v8M1 6l3 3 3-3" stroke="var(--muted)" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>' +
      "</svg>";
    var axisLabel = document.createElement("span");
    axisLabel.textContent = "older → newer";
    axisCue.appendChild(arrow);
    axisCue.appendChild(axisLabel);
    toolbar.appendChild(axisCue);

    root.appendChild(toolbar);

    /* ---- scrollable wall ---- */
    var scroll = document.createElement("div");
    scroll.className = "tw-scroll";
    root.appendChild(scroll);

    /* ---- build sections per module ---- */
    TV.modules.forEach(function (mod, modIdx) {
      /* sort tests by flakiness desc */
      var tests = mod.tests.slice().sort(function (a, b) {
        return H.flakiness(b) - H.flakiness(a);
      });

      var section = document.createElement("section");
      section.className = "tw-section";
      section.setAttribute("aria-label", mod.name + " module");

      /* section header */
      var header = document.createElement("div");
      header.className = "tw-section-header";
      var nameEl = document.createElement("span");
      nameEl.className = "tw-mod-name";
      nameEl.textContent = mod.name;
      var countEl = document.createElement("span");
      countEl.className = "tw-mod-count";
      countEl.textContent = tests.length + " test" + (tests.length !== 1 ? "s" : "");
      header.appendChild(nameEl);
      header.appendChild(countEl);
      section.appendChild(header);

      /* grid */
      var grid = document.createElement("div");
      grid.className = "tw-grid";

      tests.forEach(function (test, testIdx) {
        var flakinessVal = H.flakiness(test);
        var regressing = isRegressing(test, runs.length);
        var flaky = flakinessVal >= FLAKY_THRESHOLD;

        /* mini card */
        var mini = document.createElement("div");
        mini.className = "tw-mini" +
          (regressing ? " is-regressing" : flaky ? " is-flaky" : "");

        /* staggered animation delay */
        var delay = (modIdx * 0.04 + testIdx * 0.018).toFixed(3);
        mini.style.animationDelay = delay + "s";
        mini.setAttribute("aria-label", test.name);

        /* name row */
        var nameRow = document.createElement("div");
        nameRow.className = "tw-name-row";

        var nameSpan = document.createElement("span");
        nameSpan.className = "tw-test-name";
        nameSpan.textContent = truncate(test.name, 28);
        nameSpan.title = test.name;
        nameRow.appendChild(nameSpan);

        if (regressing) {
          var badge = document.createElement("span");
          badge.className = "tw-badge regressing";
          badge.textContent = "regr";
          badge.setAttribute("aria-label", "regressing");
          nameRow.appendChild(badge);
        } else if (flaky) {
          var badge2 = document.createElement("span");
          badge2.className = "tw-badge flaky";
          badge2.textContent = "flaky";
          badge2.setAttribute("aria-label", "flaky");
          nameRow.appendChild(badge2);
        }

        mini.appendChild(nameRow);

        /* strip of 12 segments */
        var strip = document.createElement("div");
        strip.className = "tw-strip";
        strip.setAttribute("role", "img");
        strip.setAttribute("aria-label", test.name + " run history");

        var segEls = [];
        test.history.forEach(function (status, runIdx) {
          var seg = document.createElement("div");
          seg.className = "tw-seg";
          seg.style.background = TV.colorFor(status);
          seg.setAttribute("data-run-idx", runIdx);
          strip.appendChild(seg);
          segEls.push(seg);
        });

        mini.appendChild(strip);

        /* ---- hover: show tooltip, highlight segment ---- */
        function showTooltip(e) {
          /* build tooltip content */
          tooltip.innerHTML = "";

          var ttTitle = document.createElement("div");
          ttTitle.className = "tt-title";
          ttTitle.textContent = test.name;
          tooltip.appendChild(ttTitle);

          var ttMod = document.createElement("div");
          ttMod.className = "tt-row";
          ttMod.textContent = mod.name;
          tooltip.appendChild(ttMod);

          var ttSep = document.createElement("div");
          ttSep.style.cssText = "border-top:1px solid var(--border);margin:5px 0;";
          tooltip.appendChild(ttSep);

          runs.forEach(function (run, ri) {
            var status = test.history[ri];
            var row = document.createElement("div");
            row.className = "tt-row";
            row.style.display = "flex";
            row.style.alignItems = "center";
            row.style.gap = "6px";
            row.style.marginBottom = "1px";

            var dot = document.createElement("span");
            dot.style.cssText =
              "width:7px;height:7px;border-radius:50%;flex:0 0 auto;background:" +
              TV.colorFor(status) + ";";
            var lbl = document.createElement("span");
            lbl.style.cssText = "flex:1;min-width:0;";
            lbl.textContent = run.label;
            var stText = document.createElement("span");
            stText.style.color = TV.colorFor(status);
            stText.textContent = status;

            /* mark current run */
            if (ri === runs.length - 1) {
              lbl.style.color = "var(--text)";
              stText.style.fontWeight = "700";
            }

            row.appendChild(dot);
            row.appendChild(lbl);
            row.appendChild(stText);
            tooltip.appendChild(row);
          });

          /* flag row */
          if (regressing || flaky) {
            var flagRow = document.createElement("div");
            flagRow.style.cssText = "border-top:1px solid var(--border);margin-top:5px;padding-top:4px;";
            if (regressing) {
              var rb = document.createElement("span");
              rb.className = "tw-badge regressing";
              rb.style.marginRight = "4px";
              rb.textContent = "regressing";
              flagRow.appendChild(rb);
            }
            if (flaky) {
              var fb = document.createElement("span");
              fb.className = "tw-badge flaky";
              fb.textContent = "flaky · " + Math.round(flakinessVal * 100) + "% volatility";
              flagRow.appendChild(fb);
            }
            tooltip.appendChild(flagRow);
          }

          tooltip.classList.add("is-visible");
          posTooltip(tooltip, e.clientX, e.clientY);
        }

        function moveTooltip(e) {
          if (tooltip.classList.contains("is-visible")) {
            posTooltip(tooltip, e.clientX, e.clientY);
          }
          /* highlight hovered segment */
          var target = e.target;
          var hovIdx = target && target.dataset && target.dataset.runIdx != null
            ? parseInt(target.dataset.runIdx, 10)
            : -1;
          segEls.forEach(function (sg, si) {
            sg.classList.toggle("is-hover", si === hovIdx);
          });
        }

        function hideTooltip() {
          tooltip.classList.remove("is-visible");
          segEls.forEach(function (sg) { sg.classList.remove("is-hover"); });
        }

        mini.addEventListener("mouseenter", showTooltip);
        mini.addEventListener("mousemove", moveTooltip);
        mini.addEventListener("mouseleave", hideTooltip);
        mini.addEventListener("focus", showTooltip);
        mini.addEventListener("blur", hideTooltip);
        mini.setAttribute("tabindex", "0");

        grid.appendChild(mini);
      });

      section.appendChild(grid);
      scroll.appendChild(section);
    });
  }

  /* ------------------------------------------------------------------ *
   * unmount
   * ------------------------------------------------------------------ */
  function unmount() {
    if (_tooltip) {
      _tooltip.classList.remove("is-visible");
      if (_tooltip.parentNode) _tooltip.parentNode.removeChild(_tooltip);
      _tooltip = null;
    }
    if (_mousemoveHandler) {
      document.removeEventListener("mousemove", _mousemoveHandler);
      _mousemoveHandler = null;
    }
    if (_mouseoutHandler) {
      document.removeEventListener("mouseout", _mouseoutHandler);
      _mouseoutHandler = null;
    }
  }

  /* ------------------------------------------------------------------ *
   * Register
   * ------------------------------------------------------------------ */
  window.TestViz.register({
    id: "trend-wall",
    title: "Trend Wall",
    navLabel: "Trends",
    tagline: "12-run history at a glance — spot flakiness and regression in seconds.",
    how: "Every test is a horizontal strip of 12 colour-coded segments (oldest left, newest right). Tests are grouped by module and sorted by flakiness so the most volatile sit at the top. A coloured left-border flags flaky or regressing tests.",
    when: "Ideal after a run where you suspect intermittent failures or a sudden regression. The wall layout lets you scan all 83 tests at once and immediately identify which module and which specific tests need attention.",
    mount: mount,
    unmount: unmount
  });
})();
