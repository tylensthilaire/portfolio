(function () {
  "use strict";
  if (!window.TestViz) return;

  /* ------------------------------------------------------------------ *
   * Styles — injected once, scoped under .viz-quadrant
   * ------------------------------------------------------------------ */
  var STYLE_ID = "viz-quadrant-styles";
  if (!document.getElementById(STYLE_ID)) {
    var s = document.createElement("style");
    s.id = STYLE_ID;
    s.textContent = [
      ".viz-quadrant {",
      "  width: 100%;",
      "  height: 100%;",
      "  display: flex;",
      "  flex-direction: column;",
      "  align-items: center;",
      "  justify-content: center;",
      "  position: relative;",
      "  overflow: hidden;",
      "}",
      ".viz-quadrant .qsvg {",
      "  display: block;",
      "  overflow: visible;",
      "  max-width: 100%;",
      "  max-height: 100%;",
      "}",
      ".viz-quadrant .q-dot {",
      "  cursor: pointer;",
      "  transition: r 0.15s var(--ease, cubic-bezier(.22,.61,.36,1)),",
      "    filter 0.15s var(--ease, cubic-bezier(.22,.61,.36,1));",
      "}",
      ".viz-quadrant .q-dot:hover {",
      "  filter: brightness(1.4) drop-shadow(0 0 4px currentColor);",
      "}",
      ".viz-quadrant .q-axis-label {",
      "  font-family: var(--mono);",
      "  font-size: 11px;",
      "  fill: var(--muted);",
      "}",
      ".viz-quadrant .q-tick-label {",
      "  font-family: var(--mono);",
      "  font-size: 10px;",
      "  fill: var(--faint);",
      "}",
      ".viz-quadrant .q-region-label {",
      "  font-family: var(--sans);",
      "  font-size: 11px;",
      "  font-weight: 600;",
      "  letter-spacing: 0.06em;",
      "  text-transform: uppercase;",
      "  pointer-events: none;",
      "}",
      ".viz-quadrant .q-legend {",
      "  display: flex;",
      "  gap: 18px;",
      "  align-items: center;",
      "  flex-wrap: wrap;",
      "  font-size: 12px;",
      "  color: var(--muted);",
      "  font-family: var(--sans);",
      "  position: absolute;",
      "  bottom: 4px;",
      "  left: 50%;",
      "  transform: translateX(-50%);",
      "}",
      ".viz-quadrant .q-legend .key {",
      "  display: inline-flex;",
      "  align-items: center;",
      "  gap: 6px;",
      "  white-space: nowrap;",
      "}",
      ".viz-quadrant .q-legend .swatch {",
      "  width: 9px;",
      "  height: 9px;",
      "  border-radius: 50%;",
      "  display: inline-block;",
      "}",
      "@media (prefers-reduced-motion: reduce) {",
      "  .viz-quadrant .q-dot { transition: none !important; }",
      "  .viz-quadrant .qsvg * { animation: none !important; }",
      "}"
    ].join("\n");
    document.head.appendChild(s);
  }

  /* ------------------------------------------------------------------ *
   * Module-level cleanup handle (tooltip + listeners)
   * ------------------------------------------------------------------ */
  var _tooltip = null;
  var _mousemoveHandler = null;
  var _mouseleaveHandler = null;
  var _activeDot = null;

  function ensureTooltip() {
    if (!_tooltip) {
      _tooltip = document.createElement("div");
      _tooltip.className = "viz-tooltip";
      document.body.appendChild(_tooltip);
    }
    return _tooltip;
  }

  function showTooltip(test, passRatePct, flak, currentStatus, clientX, clientY) {
    var tt = ensureTooltip();
    var colorDot =
      '<span style="display:inline-block;width:8px;height:8px;border-radius:50%;' +
      'background:' + window.TestViz.colorFor(currentStatus) + ';margin-right:5px;vertical-align:middle;"></span>';
    tt.innerHTML =
      '<div class="tt-title">' + escHtml(test.name) + "</div>" +
      '<div class="tt-row">Module &nbsp;<strong style="color:var(--text-2)">' + escHtml(test.module) + "</strong></div>" +
      '<div class="tt-row">Pass rate &nbsp;<strong style="color:var(--text-2)">' + passRatePct + "%</strong></div>" +
      '<div class="tt-row">Flakiness &nbsp;<strong style="color:var(--text-2)">' + (Math.round(flak * 100)) + "%</strong></div>" +
      '<div class="tt-row">Current &nbsp;' + colorDot + '<strong style="color:' + window.TestViz.colorFor(currentStatus) + '">' +
        window.TestViz.LABELS[currentStatus] + "</strong></div>";
    positionTooltip(clientX, clientY);
    tt.classList.add("is-visible");
  }

  function positionTooltip(cx, cy) {
    if (!_tooltip) return;
    var tw = _tooltip.offsetWidth || 220;
    var th = _tooltip.offsetHeight || 100;
    var vw = window.innerWidth;
    var vh = window.innerHeight;
    var x = cx + 14;
    var y = cy - 10;
    if (x + tw > vw - 12) x = cx - tw - 14;
    if (y + th > vh - 12) y = vh - th - 12;
    if (y < 8) y = 8;
    _tooltip.style.left = x + "px";
    _tooltip.style.top = y + "px";
  }

  function hideTooltip() {
    if (_tooltip) _tooltip.classList.remove("is-visible");
  }

  function escHtml(str) {
    return String(str)
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;");
  }

  /* ------------------------------------------------------------------ *
   * Deterministic jitter (seeded by test id so stable across resize)
   * ------------------------------------------------------------------ */
  function seededRand(seed) {
    var s = seed | 0;
    s = (s + 0x6d2b79f5) | 0;
    var t = Math.imul(s ^ (s >>> 15), 1 | s);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  }

  function jitterFor(testId, axis) {
    // extract numeric portion of id like "t17" -> 17
    var num = parseInt(String(testId).replace(/\D/g, ""), 10) || 0;
    var seedX = num * 7919 + 1;
    var seedY = num * 6271 + 2;
    var seed = axis === "x" ? seedX : seedY;
    // jitter range: ±2.5% of the plot dimension (small but clusters still legible)
    return (seededRand(seed) - 0.5) * 0.05;
  }

  /* ------------------------------------------------------------------ *
   * SVG helper
   * ------------------------------------------------------------------ */
  var SVG_NS = "http://www.w3.org/2000/svg";
  function svgEl(tag, attrs) {
    var el = document.createElementNS(SVG_NS, tag);
    Object.keys(attrs || {}).forEach(function (k) { el.setAttribute(k, attrs[k]); });
    return el;
  }
  function svgText(parent, txt, attrs) {
    var el = svgEl("text", attrs);
    el.textContent = txt;
    parent.appendChild(el);
    return el;
  }

  /* ------------------------------------------------------------------ *
   * mount
   * ------------------------------------------------------------------ */
  function mount(root, TV) {
    // ---- sizing --------------------------------------------------
    var W = root.clientWidth  || 900;
    var H = root.clientHeight || 620;

    // margins leave room for axis labels
    var ML = 64;   // left  — y-axis labels
    var MR = 28;   // right
    var MT = 32;   // top
    var MB = 64;   // bottom — x-axis labels

    var PW = W - ML - MR;   // plot width
    var PH = H - MT - MB;   // plot height

    // ---- quadrant thresholds ------------------------------------
    var X_THRESH = 0.80;   // pass-rate threshold  (80 %)
    var Y_THRESH = 0.30;   // flakiness threshold  (0.30)

    // ---- collect data -------------------------------------------
    var tests = TV.helpers.allTests();

    // ---- coordinate mappers ------------------------------------
    // passRate:  0 → left edge,  1 → right edge
    // flakiness: 0 → bottom edge, 1 → top edge  (SVG y is inverted)
    function toX(pr, jx) {
      return ML + (pr + (jx || 0)) * PW;
    }
    function toY(fl, jy) {
      // clamp to [0,1] after jitter
      return MT + (1 - Math.min(1, Math.max(0, fl + (jy || 0)))) * PH;
    }

    // ---- pixel positions for divider lines ----------------------
    var divX = toX(X_THRESH, 0);   // vertical divider (x = 80%)
    var divY = toY(Y_THRESH, 0);   // horizontal divider (y = 30% flakiness)

    // ---- build SVG ----------------------------------------------
    var svg = svgEl("svg", {
      class: "qsvg",
      viewBox: "0 0 " + W + " " + H,
      width: W,
      height: H,
      role: "img",
      "aria-label": "Flakiness Quadrant scatter plot"
    });

    // ---- region tints -------------------------------------------
    var regions = [
      // priority region: low pass + high flake (top-left)
      { x: ML, y: MT, w: divX - ML, h: divY - MT, fill: "rgba(248,113,113,0.055)", label: "Priority — fix first",   lx: ML + (divX - ML) * 0.5,         ly: MT + (divY - MT) * 0.5,         anchor: "middle", fc: "rgba(248,113,113,0.55)" },
      // flaky region: high pass + high flake (top-right)
      { x: divX, y: MT, w: ML + PW - divX, h: divY - MT, fill: "rgba(251,191,36,0.03)", label: "Flaky / unstable",    lx: divX + (ML + PW - divX) * 0.5,  ly: MT + (divY - MT) * 0.5,         anchor: "middle", fc: "rgba(251,191,36,0.45)" },
      // broken region: low pass + low flake (bottom-left)
      { x: ML, y: divY, w: divX - ML, h: MT + PH - divY, fill: "rgba(248,113,113,0.03)", label: "Consistently failing", lx: ML + (divX - ML) * 0.5,       ly: divY + (MT + PH - divY) * 0.5,  anchor: "middle", fc: "rgba(248,113,113,0.4)" },
      // healthy region: high pass + low flake (bottom-right)
      { x: divX, y: divY, w: ML + PW - divX, h: MT + PH - divY, fill: "rgba(52,211,153,0.04)", label: "Healthy",  lx: divX + (ML + PW - divX) * 0.5,  ly: divY + (MT + PH - divY) * 0.5,  anchor: "middle", fc: "rgba(52,211,153,0.45)" }
    ];

    regions.forEach(function (r) {
      var rect = svgEl("rect", {
        x: r.x, y: r.y, width: r.w, height: r.h,
        fill: r.fill,
        "pointer-events": "none"
      });
      svg.appendChild(rect);
    });

    // ---- gridlines ----------------------------------------------
    var gridG = svgEl("g", { class: "q-grid", "pointer-events": "none" });
    svg.appendChild(gridG);

    // vertical grid lines (every 10% pass rate)
    for (var gx = 0; gx <= 10; gx++) {
      var gxPx = toX(gx / 10, 0);
      var gl = svgEl("line", {
        x1: gxPx, y1: MT, x2: gxPx, y2: MT + PH,
        stroke: "rgba(176,140,245,0.09)",
        "stroke-width": "1"
      });
      gridG.appendChild(gl);
    }
    // horizontal grid lines (every 0.1 flakiness)
    for (var gy = 0; gy <= 10; gy++) {
      var gyPx = toY(gy / 10, 0);
      var glh = svgEl("line", {
        x1: ML, y1: gyPx, x2: ML + PW, y2: gyPx,
        stroke: "rgba(176,140,245,0.09)",
        "stroke-width": "1"
      });
      gridG.appendChild(glh);
    }

    // ---- quadrant divider lines ----------------------------------
    var dGroup = svgEl("g", { "pointer-events": "none" });
    svg.appendChild(dGroup);

    // vertical divider at X_THRESH
    dGroup.appendChild(svgEl("line", {
      x1: divX, y1: MT, x2: divX, y2: MT + PH,
      stroke: "rgba(176,140,245,0.30)",
      "stroke-width": "1.5",
      "stroke-dasharray": "4 4"
    }));
    // horizontal divider at Y_THRESH
    dGroup.appendChild(svgEl("line", {
      x1: ML, y1: divY, x2: ML + PW, y2: divY,
      stroke: "rgba(176,140,245,0.30)",
      "stroke-width": "1.5",
      "stroke-dasharray": "4 4"
    }));

    // ---- region labels ------------------------------------------
    var lGroup = svgEl("g", { "pointer-events": "none" });
    svg.appendChild(lGroup);

    regions.forEach(function (r) {
      var el = svgEl("text", {
        class: "q-region-label",
        x: r.lx,
        y: r.ly,
        "text-anchor": r.anchor,
        "dominant-baseline": "middle",
        fill: r.fc,
        "font-size": "10.5"
      });
      el.textContent = r.label;
      lGroup.appendChild(el);
    });

    // ---- axes ---------------------------------------------------
    var axisG = svgEl("g", { "pointer-events": "none" });
    svg.appendChild(axisG);

    // axis borders
    axisG.appendChild(svgEl("line", {
      x1: ML, y1: MT + PH, x2: ML + PW, y2: MT + PH,
      stroke: "rgba(176,140,245,0.22)", "stroke-width": "1.5"
    }));
    axisG.appendChild(svgEl("line", {
      x1: ML, y1: MT, x2: ML, y2: MT + PH,
      stroke: "rgba(176,140,245,0.22)", "stroke-width": "1.5"
    }));

    // X axis ticks + labels
    for (var xi = 0; xi <= 10; xi++) {
      var xPx = toX(xi / 10, 0);
      axisG.appendChild(svgEl("line", {
        x1: xPx, y1: MT + PH, x2: xPx, y2: MT + PH + 5,
        stroke: "rgba(176,140,245,0.28)", "stroke-width": "1"
      }));
      var xLbl = svgEl("text", {
        class: "q-tick-label",
        x: xPx,
        y: MT + PH + 16,
        "text-anchor": "middle",
        "font-size": "10"
      });
      xLbl.textContent = (xi * 10) + "%";
      axisG.appendChild(xLbl);
    }

    // Y axis ticks + labels
    for (var yi = 0; yi <= 10; yi++) {
      var yPx = toY(yi / 10, 0);
      axisG.appendChild(svgEl("line", {
        x1: ML - 5, y1: yPx, x2: ML, y2: yPx,
        stroke: "rgba(176,140,245,0.28)", "stroke-width": "1"
      }));
      var yLbl = svgEl("text", {
        class: "q-tick-label",
        x: ML - 9,
        y: yPx,
        "text-anchor": "end",
        "dominant-baseline": "middle",
        "font-size": "10"
      });
      yLbl.textContent = (yi * 10) + "%";
      axisG.appendChild(yLbl);
    }

    // axis title: X
    var xTitle = svgEl("text", {
      class: "q-axis-label",
      x: ML + PW / 2,
      y: MT + PH + MB - 6,
      "text-anchor": "middle",
      "font-size": "11"
    });
    xTitle.textContent = "Pass Rate (% of runs passing)";
    axisG.appendChild(xTitle);

    // axis title: Y (rotated)
    var yTitle = svgEl("text", {
      class: "q-axis-label",
      x: 0,
      y: 0,
      transform: "rotate(-90) translate(" + (-(MT + PH / 2)) + ", " + 14 + ")",
      "text-anchor": "middle",
      "font-size": "11"
    });
    yTitle.textContent = "Flakiness (run-to-run volatility)";
    axisG.appendChild(yTitle);

    // ---- dots ---------------------------------------------------
    var dotGroup = svgEl("g", { class: "q-dots" });
    svg.appendChild(dotGroup);

    var DOT_R = Math.max(4, Math.min(7, PW / 80));

    tests.forEach(function (test, idx) {
      var pr   = TV.helpers.passRate(test);
      var flak = TV.helpers.flakiness(test);
      var cur  = TV.helpers.current(test);
      var col  = TV.colorFor(cur);

      var jx = jitterFor(test.id, "x");
      var jy = jitterFor(test.id, "y");

      // scale jitter proportionally to data range
      var cx = toX(pr + jx, 0);
      var cy = toY(flak + jy, 0);

      // clamp inside plot area
      cx = Math.max(ML + DOT_R + 1, Math.min(ML + PW - DOT_R - 1, cx));
      cy = Math.max(MT + DOT_R + 1, Math.min(MT + PH - DOT_R - 1, cy));

      var circle = svgEl("circle", {
        class: "q-dot",
        cx: cx,
        cy: cy,
        r: DOT_R,
        fill: col,
        opacity: "0.80",
        "stroke-width": "0",
        "data-idx": idx
      });

      // entrance animation (staggered, no library)
      var motionOk = !(typeof window.matchMedia === "function" &&
        window.matchMedia("(prefers-reduced-motion: reduce)").matches);
      if (motionOk) {
        circle.style.opacity = "0";
        circle.style.transform = "scale(0)";
        circle.style.transformOrigin = cx + "px " + cy + "px";
        circle.style.transition =
          "opacity 0.35s var(--ease, cubic-bezier(.22,.61,.36,1)) " + (idx * 6) + "ms, " +
          "transform 0.35s var(--ease, cubic-bezier(.22,.61,.36,1)) " + (idx * 6) + "ms";
      }

      dotGroup.appendChild(circle);

      // trigger animation next frame
      if (motionOk) {
        (function (el, op) {
          requestAnimationFrame(function () {
            requestAnimationFrame(function () {
              el.style.opacity = op;
              el.style.transform = "scale(1)";
            });
          });
        })(circle, "0.80");
      }

      // ---- hover handlers -----------------------------------------
      var passRatePct = Math.round(pr * 100);

      function onEnter(e) {
        _activeDot = circle;
        circle.setAttribute("r", DOT_R + 3);
        circle.setAttribute("opacity", "1");
        showTooltip(test, passRatePct, flak, cur, e.clientX, e.clientY);
      }

      function onMove(e) {
        positionTooltip(e.clientX, e.clientY);
      }

      function onLeave() {
        if (_activeDot === circle) _activeDot = null;
        circle.setAttribute("r", DOT_R);
        circle.setAttribute("opacity", "0.80");
        hideTooltip();
      }

      circle.addEventListener("mouseenter", onEnter);
      circle.addEventListener("mousemove",  onMove);
      circle.addEventListener("mouseleave", onLeave);
    });

    // ---- legend --------------------------------------------------
    var legendDiv = document.createElement("div");
    legendDiv.className = "q-legend";
    ["pass", "fail", "skip"].forEach(function (st) {
      var key = document.createElement("span");
      key.className = "key";
      var sw = document.createElement("span");
      sw.className = "swatch";
      sw.style.background = TV.colorFor(st);
      var lbl = document.createTextNode(TV.LABELS[st]);
      key.appendChild(sw);
      key.appendChild(lbl);
      legendDiv.appendChild(key);
    });
    root.appendChild(legendDiv);

    root.appendChild(svg);
  }

  /* ------------------------------------------------------------------ *
   * unmount — remove tooltip and any dangling listeners
   * ------------------------------------------------------------------ */
  function unmount() {
    if (_tooltip && _tooltip.parentNode) {
      _tooltip.parentNode.removeChild(_tooltip);
      _tooltip = null;
    }
    if (_mousemoveHandler) {
      document.removeEventListener("mousemove", _mousemoveHandler);
      _mousemoveHandler = null;
    }
    if (_mouseleaveHandler) {
      document.removeEventListener("mouseleave", _mouseleaveHandler);
      _mouseleaveHandler = null;
    }
    _activeDot = null;
  }

  /* ------------------------------------------------------------------ *
   * Register
   * ------------------------------------------------------------------ */
  window.TestViz.register({
    id: "quadrant",
    title: "Flakiness Quadrant",
    navLabel: "Quadrant",
    tagline: "Prioritise what to fix by reliability and volatility",
    how: "Each dot is one test, placed by pass rate (x) and run-to-run volatility (y), coloured by current status. Quadrant dividers separate Healthy tests from those that are Flaky, Consistently Failing, or Priority fixes.",
    when: "Use after a wave of failures to triage: tests in the top-left demand immediate attention; bottom-right dots can be ignored. Especially useful when you need to communicate risk to stakeholders at a glance.",
    mount: mount,
    unmount: unmount
  });
})();
