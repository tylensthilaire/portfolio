/* =====================================================================
   TestViz — Status Grid demo
   A heatmap of the current run: every test as a coloured cell,
   grouped by module, with hover tooltips and entrance animation.
   ===================================================================== */
(function () {
  "use strict";
  if (!window.TestViz) return;

  /* ---- inject scoped styles once ---- */
  var STYLE_ID = "viz-status-grid-styles";
  if (!document.getElementById(STYLE_ID)) {
    var s = document.createElement("style");
    s.id = STYLE_ID;
    s.textContent = [
      ".viz-status-grid {",
      "  flex: 1 1 auto;",
      "  display: flex;",
      "  flex-direction: column;",
      "  min-height: 0;",
      "  overflow: hidden;",
      "}",

      /* ---- top header bar ---- */
      ".viz-status-grid .sg-header {",
      "  flex: 0 0 auto;",
      "  display: flex;",
      "  align-items: center;",
      "  justify-content: space-between;",
      "  flex-wrap: wrap;",
      "  gap: 10px 18px;",
      "  padding: 0 2px 16px;",
      "}",

      ".viz-status-grid .sg-headline {",
      "  display: flex;",
      "  align-items: baseline;",
      "  gap: 10px;",
      "}",

      ".viz-status-grid .sg-pass-pct {",
      "  font-family: var(--mono);",
      "  font-size: 28px;",
      "  font-weight: 700;",
      "  letter-spacing: -0.02em;",
      "  color: var(--pass);",
      "  line-height: 1;",
      "}",

      ".viz-status-grid .sg-total {",
      "  font-family: var(--mono);",
      "  font-size: 13px;",
      "  color: var(--muted);",
      "  letter-spacing: 0.01em;",
      "}",

      /* ---- legend ---- */
      ".viz-status-grid .sg-legend {",
      "  display: flex;",
      "  gap: 16px;",
      "  align-items: center;",
      "  flex-wrap: wrap;",
      "  font-size: 12px;",
      "  color: var(--muted);",
      "}",

      ".viz-status-grid .sg-legend .key {",
      "  display: inline-flex;",
      "  align-items: center;",
      "  gap: 7px;",
      "  font-family: var(--mono);",
      "}",

      ".viz-status-grid .sg-legend .swatch {",
      "  width: 11px;",
      "  height: 11px;",
      "  border-radius: 3px;",
      "  display: inline-block;",
      "  flex-shrink: 0;",
      "}",

      ".viz-status-grid .sg-legend .swatch.pass { background: var(--pass); }",
      ".viz-status-grid .sg-legend .swatch.fail { background: var(--fail); }",
      ".viz-status-grid .sg-legend .swatch.skip { background: var(--skip); }",

      ".viz-status-grid .sg-legend .key-count {",
      "  color: var(--text-2);",
      "  font-weight: 600;",
      "}",

      /* ---- scrollable body ---- */
      ".viz-status-grid .sg-body {",
      "  flex: 1 1 auto;",
      "  overflow-y: auto;",
      "  overflow-x: hidden;",
      "  min-height: 0;",
      "  padding-right: 4px;",
      "}",

      ".viz-status-grid .sg-body::-webkit-scrollbar {",
      "  width: 6px;",
      "}",
      ".viz-status-grid .sg-body::-webkit-scrollbar-thumb {",
      "  background: var(--border-strong);",
      "  border-radius: 6px;",
      "}",

      /* ---- modules grid ---- */
      ".viz-status-grid .sg-modules {",
      "  display: grid;",
      "  grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));",
      "  gap: 14px;",
      "}",

      /* ---- single module block ---- */
      ".viz-status-grid .sg-block {",
      "  background: var(--panel);",
      "  border: 1px solid var(--border);",
      "  border-radius: var(--radius);",
      "  padding: 14px 16px 16px;",
      "  display: flex;",
      "  flex-direction: column;",
      "  gap: 12px;",
      "}",

      /* ---- block header ---- */
      ".viz-status-grid .sg-block-head {",
      "  display: flex;",
      "  align-items: center;",
      "  justify-content: space-between;",
      "  gap: 8px;",
      "  min-width: 0;",
      "}",

      ".viz-status-grid .sg-mod-name {",
      "  font-size: 12.5px;",
      "  font-weight: 600;",
      "  letter-spacing: 0.01em;",
      "  color: var(--text);",
      "  white-space: nowrap;",
      "  overflow: hidden;",
      "  text-overflow: ellipsis;",
      "  min-width: 0;",
      "}",

      ".viz-status-grid .sg-counts {",
      "  display: flex;",
      "  gap: 6px;",
      "  align-items: center;",
      "  flex-shrink: 0;",
      "  font-family: var(--mono);",
      "  font-size: 10.5px;",
      "}",

      ".viz-status-grid .sg-counts .c-pass { color: var(--pass); }",
      ".viz-status-grid .sg-counts .c-fail { color: var(--fail); }",
      ".viz-status-grid .sg-counts .c-skip { color: var(--skip); }",
      ".viz-status-grid .sg-counts .c-sep  { color: var(--faint); }",

      /* ---- cells wrapper ---- */
      ".viz-status-grid .sg-cells {",
      "  display: flex;",
      "  flex-wrap: wrap;",
      "  gap: 5px;",
      "}",

      /* ---- individual test cell ---- */
      ".viz-status-grid .sg-cell {",
      "  width: 18px;",
      "  height: 18px;",
      "  border-radius: 5px;",
      "  cursor: pointer;",
      "  flex-shrink: 0;",
      "  opacity: 0;",
      "  transform: scale(0.6);",
      "  transition:",
      "    transform 0.18s var(--ease),",
      "    box-shadow 0.18s var(--ease),",
      "    opacity 0.22s var(--ease);",
      "  border: 1px solid rgba(0,0,0,0.25);",
      "}",

      ".viz-status-grid .sg-cell.sg-anim {",
      "  opacity: 1;",
      "  transform: scale(1);",
      "}",

      ".viz-status-grid .sg-cell.pass  { background: var(--pass); }",
      ".viz-status-grid .sg-cell.fail  { background: var(--fail); }",
      ".viz-status-grid .sg-cell.skip  { background: var(--skip); }",

      ".viz-status-grid .sg-cell.pass:hover {",
      "  transform: scale(1.25);",
      "  box-shadow: 0 0 8px var(--pass);",
      "  z-index: 1;",
      "}",
      ".viz-status-grid .sg-cell.fail:hover {",
      "  transform: scale(1.25);",
      "  box-shadow: 0 0 8px var(--fail);",
      "  z-index: 1;",
      "}",
      ".viz-status-grid .sg-cell.skip:hover {",
      "  transform: scale(1.25);",
      "  box-shadow: 0 0 8px var(--skip);",
      "  z-index: 1;",
      "}",

      /* ---- reduced-motion overrides ---- */
      "@media (prefers-reduced-motion: reduce) {",
      "  .viz-status-grid .sg-cell {",
      "    transition: none !important;",
      "    opacity: 1 !important;",
      "    transform: none !important;",
      "  }",
      "  .viz-status-grid .sg-cell.sg-anim {",
      "    opacity: 1;",
      "    transform: none;",
      "  }",
      "}"
    ].join("\n");
    document.head.appendChild(s);
  }

  /* ---- module-level state for unmount ---- */
  var _tooltip = null;
  var _animFrames = [];
  var _listeners = []; /* [{el, type, fn}] for cleanup */

  function addListener(el, type, fn) {
    el.addEventListener(type, fn);
    _listeners.push({ el: el, type: type, fn: fn });
  }

  function clearListeners() {
    _listeners.forEach(function (l) { l.el.removeEventListener(l.type, l.fn); });
    _listeners = [];
  }

  function clearTooltip() {
    if (_tooltip) {
      if (_tooltip.parentNode) _tooltip.parentNode.removeChild(_tooltip);
      _tooltip = null;
    }
  }

  function clearAnims() {
    _animFrames.forEach(function (id) { clearTimeout(id); });
    _animFrames = [];
  }

  /* ---- tooltip helpers ---- */
  function ensureTooltip() {
    if (!_tooltip) {
      _tooltip = document.createElement("div");
      _tooltip.className = "viz-tooltip";
      document.body.appendChild(_tooltip);
    }
    return _tooltip;
  }

  function showTooltip(test, TV, clientX, clientY) {
    var tt = ensureTooltip();
    var status = TV.helpers.current(test);
    var pct = Math.round(TV.helpers.passRate(test) * 100);
    var color = TV.colorFor(status);

    tt.innerHTML = [
      '<div class="tt-title">' + escHtml(test.name) + "</div>",
      '<div class="tt-row">' + escHtml(test.module) + "</div>",
      '<div class="tt-row" style="margin-top:5px">',
      '  <span style="color:' + color + ';font-weight:600;">' + capFirst(status) + "</span>",
      "  &nbsp;·&nbsp; " + pct + "% pass rate over all runs",
      "</div>"
    ].join("");

    positionTooltip(tt, clientX, clientY);
    tt.classList.add("is-visible");
  }

  function moveTooltip(clientX, clientY) {
    if (!_tooltip) return;
    positionTooltip(_tooltip, clientX, clientY);
  }

  function hideTooltip() {
    if (_tooltip) _tooltip.classList.remove("is-visible");
  }

  function positionTooltip(tt, cx, cy) {
    var pad = 14;
    var tw = tt.offsetWidth || 220;
    var th = tt.offsetHeight || 80;
    var vw = window.innerWidth;
    var vh = window.innerHeight;
    var x = cx + pad;
    var y = cy + pad;
    if (x + tw > vw - 8) x = cx - tw - pad;
    if (y + th > vh - 8) y = cy - th - pad;
    tt.style.left = Math.max(8, x) + "px";
    tt.style.top  = Math.max(8, y) + "px";
  }

  function escHtml(str) {
    return String(str)
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;");
  }

  function capFirst(str) {
    return str.charAt(0).toUpperCase() + str.slice(1);
  }

  /* ---- mount ---- */
  function mount(root, TV) {
    /* clean up any previous cycle's state */
    clearListeners();
    clearTooltip();
    clearAnims();

    var helpers = TV.helpers;
    var overall = helpers.currentCounts();
    var passPct = overall.total > 0
      ? Math.round((overall.pass / overall.total) * 100)
      : 0;

    /* ---- outer wrapper ---- */
    var wrap = document.createElement("div");
    wrap.style.cssText = "flex:1 1 auto; display:flex; flex-direction:column; min-height:0; width:100%;";

    /* ---- header ---- */
    var header = document.createElement("div");
    header.className = "sg-header";

    /* headline: pass % + total */
    var headline = document.createElement("div");
    headline.className = "sg-headline";

    var pctEl = document.createElement("span");
    pctEl.className = "sg-pass-pct";
    pctEl.textContent = passPct + "%";

    var totalEl = document.createElement("span");
    totalEl.className = "sg-total";
    totalEl.textContent = overall.total + " tests · current run";

    headline.appendChild(pctEl);
    headline.appendChild(totalEl);

    /* legend */
    var legend = document.createElement("div");
    legend.className = "sg-legend";

    [
      { status: "pass", count: overall.pass,  label: "Passed"  },
      { status: "fail", count: overall.fail,  label: "Failed"  },
      { status: "skip", count: overall.skip,  label: "Skipped" }
    ].forEach(function (item) {
      var key = document.createElement("span");
      key.className = "key";

      var sw = document.createElement("span");
      sw.className = "swatch " + item.status;

      var cnt = document.createElement("span");
      cnt.className = "key-count";
      cnt.textContent = item.count;

      var lbl = document.createElement("span");
      lbl.textContent = " " + item.label;

      key.appendChild(sw);
      key.appendChild(cnt);
      key.appendChild(lbl);
      legend.appendChild(key);
    });

    header.appendChild(headline);
    header.appendChild(legend);

    /* ---- scrollable body ---- */
    var body = document.createElement("div");
    body.className = "sg-body";

    /* ---- modules grid ---- */
    var grid = document.createElement("div");
    grid.className = "sg-modules";

    /* track all cells for staggered animation */
    var allCells = [];

    TV.modules.forEach(function (mod) {
      var mc = helpers.moduleCountsAt(mod.name, null);

      var block = document.createElement("div");
      block.className = "sg-block";

      /* block header */
      var blockHead = document.createElement("div");
      blockHead.className = "sg-block-head";

      var modName = document.createElement("div");
      modName.className = "sg-mod-name";
      modName.textContent = mod.name;

      var counts = document.createElement("div");
      counts.className = "sg-counts";

      /* pass count */
      var cp = document.createElement("span");
      cp.className = "c-pass";
      cp.textContent = mc.pass;

      var sep1 = document.createElement("span");
      sep1.className = "c-sep";
      sep1.textContent = "/";

      /* fail count */
      var cf = document.createElement("span");
      cf.className = "c-fail";
      cf.textContent = mc.fail;

      var sep2 = document.createElement("span");
      sep2.className = "c-sep";
      sep2.textContent = "/";

      /* skip count */
      var cs = document.createElement("span");
      cs.className = "c-skip";
      cs.textContent = mc.skip;

      counts.appendChild(cp);
      counts.appendChild(sep1);
      counts.appendChild(cf);
      counts.appendChild(sep2);
      counts.appendChild(cs);

      blockHead.appendChild(modName);
      blockHead.appendChild(counts);

      /* cells wrapper */
      var cells = document.createElement("div");
      cells.className = "sg-cells";

      mod.tests.forEach(function (test) {
        var status = helpers.current(test);
        var cell = document.createElement("div");
        cell.className = "sg-cell " + status;
        cell.setAttribute("role", "img");
        cell.setAttribute("aria-label", test.name + " — " + status);
        cell.dataset.testId = test.id;

        /* hover listeners */
        addListener(cell, "mouseenter", function (e) {
          showTooltip(test, TV, e.clientX, e.clientY);
        });
        addListener(cell, "mousemove", function (e) {
          moveTooltip(e.clientX, e.clientY);
        });
        addListener(cell, "mouseleave", function () {
          hideTooltip();
        });

        cells.appendChild(cell);
        allCells.push(cell);
      });

      block.appendChild(blockHead);
      block.appendChild(cells);
      grid.appendChild(block);
    });

    body.appendChild(grid);
    wrap.appendChild(header);
    wrap.appendChild(body);
    root.appendChild(wrap);

    /* ---- staggered entrance animation ---- */
    var reducedMotion = window.matchMedia &&
      window.matchMedia("(prefers-reduced-motion: reduce)").matches;

    if (reducedMotion) {
      /* show instantly */
      allCells.forEach(function (cell) { cell.classList.add("sg-anim"); });
    } else {
      /* stagger: batch cells in groups of 5 every 18 ms */
      var BATCH = 5;
      var DELAY = 18;
      allCells.forEach(function (cell, i) {
        var id = setTimeout(function () {
          cell.classList.add("sg-anim");
        }, Math.floor(i / BATCH) * DELAY + 60);
        _animFrames.push(id);
      });
    }
  }

  /* ---- unmount ---- */
  function unmount() {
    clearListeners();
    clearTooltip();
    clearAnims();
  }

  /* ---- register ---- */
  window.TestViz.register({
    id: "status-grid",
    title: "Status Grid",
    navLabel: "Grid",
    tagline: "Every test as a cell — the current run at a glance.",
    how: "Each test in the current run is rendered as a small coloured cell (green pass, red fail, amber skip), grouped into a labelled block per module. Block headers show compact pass/fail/skip counts for that module; hovering a cell reveals its name, module, and historical pass-rate.",
    when: "Use this view first — it is the fastest way to spot which modules have failures or skips and how widespread the damage is. Switch to a history-focused view when you need to understand whether issues are new regressions or long-standing.",
    mount: mount,
    unmount: unmount
  });
})();
