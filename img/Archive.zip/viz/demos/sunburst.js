(function () {
  "use strict";
  if (!window.TestViz) return;

  /* ------------------------------------------------------------------ *
   * Scoped styles — injected once
   * ------------------------------------------------------------------ */
  var STYLE_ID = "viz-sunburst-styles";
  if (!document.getElementById(STYLE_ID)) {
    var s = document.createElement("style");
    s.id = STYLE_ID;
    s.textContent = [
      ".viz-sunburst {",
      "  width: 100%;",
      "  height: 100%;",
      "  display: flex;",
      "  align-items: center;",
      "  justify-content: center;",
      "  position: relative;",
      "  overflow: hidden;",
      "}",

      ".viz-sunburst svg {",
      "  overflow: visible;",
      "  display: block;",
      "}",

      /* Arc base */
      ".viz-sunburst .arc-module {",
      "  cursor: pointer;",
      "  transition: filter 0.18s var(--ease, ease);",
      "}",
      ".viz-sunburst .arc-module:hover {",
      "  filter: brightness(1.25);",
      "}",
      ".viz-sunburst .arc-test {",
      "  cursor: pointer;",
      "  transition: filter 0.18s var(--ease, ease), transform 0.18s var(--ease, ease);",
      "  transform-box: fill-box;",
      "  transform-origin: center;",
      "}",
      ".viz-sunburst .arc-test:hover {",
      "  filter: brightness(1.35) saturate(1.2);",
      "}",

      /* Centre text */
      ".viz-sunburst .centre-pct {",
      "  font-family: var(--mono, monospace);",
      "  font-size: 22px;",
      "  font-weight: 700;",
      "  fill: var(--text, #f1edfa);",
      "  dominant-baseline: middle;",
      "  text-anchor: middle;",
      "}",
      ".viz-sunburst .centre-sub {",
      "  font-family: var(--mono, monospace);",
      "  font-size: 11px;",
      "  fill: var(--muted, #9a8dbd);",
      "  dominant-baseline: middle;",
      "  text-anchor: middle;",
      "}",

      /* Module labels */
      ".viz-sunburst .label-mod {",
      "  font-family: var(--sans, sans-serif);",
      "  font-size: 11px;",
      "  font-weight: 600;",
      "  fill: var(--text, #f1edfa);",
      "  dominant-baseline: middle;",
      "  text-anchor: middle;",
      "  pointer-events: none;",
      "  letter-spacing: 0.04em;",
      "}",

      /* Legend */
      ".viz-sunburst .sb-legend {",
      "  position: absolute;",
      "  bottom: 16px;",
      "  left: 50%;",
      "  transform: translateX(-50%);",
      "  display: flex;",
      "  gap: 20px;",
      "  align-items: center;",
      "  pointer-events: none;",
      "}",
      ".viz-sunburst .sb-legend-item {",
      "  display: flex;",
      "  align-items: center;",
      "  gap: 7px;",
      "  font-size: 11px;",
      "  font-family: var(--mono, monospace);",
      "  color: var(--muted, #9a8dbd);",
      "}",
      ".viz-sunburst .sb-legend-swatch {",
      "  width: 10px;",
      "  height: 10px;",
      "  border-radius: 3px;",
      "}",

      /* Entrance sweep animation */
      "@keyframes sb-sweep-in {",
      "  from { opacity: 0; transform: scale(0.72); }",
      "  to   { opacity: 1; transform: scale(1); }",
      "}",
      ".viz-sunburst .sb-chart-g {",
      "  transform-origin: 50% 50%;",
      "  animation: sb-sweep-in 0.56s cubic-bezier(0.22, 0.61, 0.36, 1) forwards;",
      "}",
      "@media (prefers-reduced-motion: reduce) {",
      "  .viz-sunburst .sb-chart-g {",
      "    animation: none;",
      "    opacity: 1;",
      "    transform: none;",
      "  }",
      "}"
    ].join("\n");
    document.head.appendChild(s);
  }

  /* ------------------------------------------------------------------ *
   * Module colour palette — distinct tints layered over a dark base
   * ------------------------------------------------------------------ */
  var MODULE_COLORS = [
    "#a855f7",  // purple
    "#d8b4fe",  // light lavender
    "#7c3aed",  // deep violet
    "#e879f9",  // fuchsia
    "#8b5cf6",  // violet
    "#f0abfc",  // light fuchsia
    "#9333ea",  // deep purple
    "#c084fc"   // lavender
  ];

  /* ------------------------------------------------------------------ *
   * SVG arc-path helpers
   * ------------------------------------------------------------------ */
  var TAU = 2 * Math.PI;

  /**
   * Polar to Cartesian.
   * angle 0 = top (12-o'clock), increases clockwise.
   */
  function polar(cx, cy, r, angleDeg) {
    var a = (angleDeg - 90) * (Math.PI / 180);
    return {
      x: cx + r * Math.cos(a),
      y: cy + r * Math.sin(a)
    };
  }

  /**
   * Build an SVG arc-path for an annulus sector.
   * startDeg / endDeg: clockwise from top (0 = 12-o'clock).
   * innerR / outerR: inner and outer radii.
   */
  function arcPath(cx, cy, innerR, outerR, startDeg, endDeg) {
    /* Clamp sweep to avoid degenerate arcs */
    var sweep = endDeg - startDeg;
    if (sweep < 0.001) return "";
    /* Cap at just under 360 to keep large-arc-flag working cleanly */
    var cappedEnd = startDeg + Math.min(sweep, 359.9999);

    var largeArc = (cappedEnd - startDeg) > 180 ? 1 : 0;

    var p0 = polar(cx, cy, outerR, startDeg);
    var p1 = polar(cx, cy, outerR, cappedEnd);
    var p2 = polar(cx, cy, innerR, cappedEnd);
    var p3 = polar(cx, cy, innerR, startDeg);

    return [
      "M", p0.x, p0.y,
      "A", outerR, outerR, 0, largeArc, 1, p1.x, p1.y,
      "L", p2.x, p2.y,
      "A", innerR, innerR, 0, largeArc, 0, p3.x, p3.y,
      "Z"
    ].join(" ");
  }

  /* ------------------------------------------------------------------ *
   * Tooltip helpers (reuse .viz-tooltip)
   * ------------------------------------------------------------------ */
  var _tooltip = null;

  function getTooltip() {
    if (!_tooltip) {
      _tooltip = document.createElement("div");
      _tooltip.className = "viz-tooltip";
      document.body.appendChild(_tooltip);
    }
    return _tooltip;
  }

  function showTooltip(html, x, y) {
    var tt = getTooltip();
    tt.innerHTML = html;
    var vw = window.innerWidth;
    var vh = window.innerHeight;
    var offset = 14;
    var left = x + offset;
    var top = y - 10;
    /* Keep inside viewport (rough) */
    if (left + 290 > vw) left = x - offset - 290;
    if (top + 130 > vh) top = vh - 140;
    if (top < 6) top = 6;
    tt.style.left = left + "px";
    tt.style.top = top + "px";
    tt.classList.add("is-visible");
  }

  function hideTooltip() {
    if (_tooltip) _tooltip.classList.remove("is-visible");
  }

  function removeTooltip() {
    if (_tooltip) {
      _tooltip.remove();
      _tooltip = null;
    }
  }

  /* ------------------------------------------------------------------ *
   * Format helpers
   * ------------------------------------------------------------------ */
  function pct(n) {
    return Math.round(n * 100) + "%";
  }

  function statusDot(status) {
    var colors = { pass: "#34d399", fail: "#f87171", skip: "#fbbf24" };
    var c = colors[status] || "#9a8dbd";
    return '<span style="display:inline-block;width:7px;height:7px;border-radius:50%;background:' + c + ';margin-right:5px;vertical-align:middle;"></span>';
  }

  /* ------------------------------------------------------------------ *
   * SVG namespace helper
   * ------------------------------------------------------------------ */
  var NS = "http://www.w3.org/2000/svg";

  function svgEl(tag, attrs) {
    var el = document.createElementNS(NS, tag);
    if (attrs) {
      Object.keys(attrs).forEach(function (k) {
        el.setAttribute(k, attrs[k]);
      });
    }
    return el;
  }

  /* ------------------------------------------------------------------ *
   * Curved text path helper (for module labels)
   * ------------------------------------------------------------------ */
  function midAngle(startDeg, endDeg) {
    return (startDeg + endDeg) / 2;
  }

  /* ------------------------------------------------------------------ *
   * mount
   * ------------------------------------------------------------------ */
  function mount(root, TV) {
    /* --- Measure container --- */
    var rect = root.getBoundingClientRect();
    var W = root.clientWidth  || rect.width  || 700;
    var H = root.clientHeight || rect.height || 600;

    /* Reserve bottom space for legend */
    var legendH = 36;
    var availH = H - legendH;

    /* Radii — fit in the smaller of W / availH with generous padding */
    var maxR = Math.min(W, availH) * 0.5 - 20;
    maxR = Math.max(maxR, 80); // floor for very small containers

    var innerHoleR  = maxR * 0.28;   // centre hole
    var moduleInnerR = innerHoleR + maxR * 0.02;  // thin gap
    var moduleOuterR = moduleInnerR + maxR * 0.24; // module ring width
    var testGap      = maxR * 0.025;               // gap between rings
    var testInnerR   = moduleOuterR + testGap;
    var testOuterR   = testInnerR   + maxR * 0.26; // outer test ring

    /* Centre of SVG */
    var cx = W / 2;
    var cy = availH / 2;

    /* --- Build SVG --- */
    var svg = svgEl("svg", {
      width: W,
      height: availH,
      viewBox: "0 0 " + W + " " + availH,
      "aria-label": "Test suite sunburst chart"
    });

    /* Wrapper group for entrance animation */
    var chartG = svgEl("g", { "class": "sb-chart-g" });
    svg.appendChild(chartG);

    /* --- Data: modules + tests --- */
    var modules = TV.modules;
    var allTests = TV.helpers.allTests();
    var totalTests = allTests.length;
    var counts = TV.helpers.currentCounts();
    var overallPassPct = totalTests > 0 ? Math.round((counts.pass / totalTests) * 100) : 0;

    /* Total test count across all modules (should equal totalTests) */
    var totalCount = 0;
    modules.forEach(function (m) { totalCount += m.tests.length; });

    /* ---- Inner ring: modules ---- */
    var startDeg = 0;
    var defs = svgEl("defs");
    svg.appendChild(defs);

    /* A group for arcs and a group for labels to keep labels on top */
    var arcsG  = svgEl("g");
    var labelsG = svgEl("g");
    chartG.appendChild(arcsG);
    chartG.appendChild(labelsG);

    modules.forEach(function (mod, mi) {
      var modCount = mod.tests.length;
      var sweep = (modCount / totalCount) * 360;
      var endDeg = startDeg + sweep;

      /* Module fill: tinted accent colour */
      var modColor = MODULE_COLORS[mi % MODULE_COLORS.length];

      /* Pass-rate influence: slightly dim low-pass-rate modules */
      var mc = TV.helpers.moduleCountsAt(mod.name, null);
      var modPassRate = mc.total > 0 ? mc.pass / mc.total : 0;
      /* opacity 0.55 (all failed) → 1.0 (all passed) */
      var modOpacity = (0.55 + modPassRate * 0.45).toFixed(3);

      var pathD = arcPath(cx, cy, moduleInnerR, moduleOuterR, startDeg, endDeg);
      if (!pathD) { startDeg = endDeg; return; }

      var arcEl = svgEl("path", {
        d: pathD,
        fill: modColor,
        "fill-opacity": modOpacity,
        stroke: "#160a2b",
        "stroke-width": "1.5",
        "class": "arc-module",
        "data-module": mod.name,
        "aria-label": mod.name
      });

      /* Module tooltip */
      arcEl.addEventListener("mousemove", function (e) {
        var html =
          '<div class="tt-title">' + mod.name + '</div>' +
          '<div class="tt-row">' +
          statusDot("pass") + mc.pass + " passed&nbsp;&nbsp;" +
          statusDot("fail") + mc.fail + " failed&nbsp;&nbsp;" +
          statusDot("skip") + mc.skip + " skipped" +
          '</div>' +
          '<div class="tt-row" style="margin-top:4px;">Pass rate: ' +
          pct(modPassRate) + " &nbsp;·&nbsp; " + modCount + " tests</div>";
        showTooltip(html, e.clientX, e.clientY);
      });
      arcEl.addEventListener("mouseleave", hideTooltip);
      arcsG.appendChild(arcEl);

      /* ---- Module label (curved or radial) ---- */
      /* Only show label if the wedge is wide enough */
      var MIN_SWEEP_FOR_LABEL = 18; // degrees
      if (sweep >= MIN_SWEEP_FOR_LABEL) {
        var mid = midAngle(startDeg, endDeg);
        var labelR = (moduleInnerR + moduleOuterR) / 2;
        var lp = polar(cx, cy, labelR, mid);

        /* For short labels, radial text works fine.
           Use a textPath on a circular arc for curved text. */
        var pathId = "mod-label-path-" + mi;
        /* Determine if label should curve upward or downward based on angle
           Bottom half (90–270 deg from top) → flip so text reads correctly */
        var isBottom = mid > 90 && mid < 270;

        /* Build a small arc path centred on the mid-angle label radius */
        var arcSpan = Math.min(sweep * 0.8, 40); // degrees to span
        var arcStart = mid - arcSpan / 2;
        var arcEnd   = mid + arcSpan / 2;

        /* For bottom half, reverse start/end so text flows left→right */
        if (isBottom) {
          var tmp = arcStart; arcStart = arcEnd; arcEnd = tmp;
        }

        var textLabelR = labelR;
        var tp0 = polar(cx, cy, textLabelR, arcStart);
        var tp1 = polar(cx, cy, textLabelR, arcEnd);
        var largeArcFlag = arcSpan > 180 ? 1 : 0;
        var sweepFlag = isBottom ? 0 : 1;

        var labelPathEl = svgEl("path", {
          id: pathId,
          d: "M " + tp0.x + " " + tp0.y + " A " + textLabelR + " " + textLabelR + " 0 " + largeArcFlag + " " + sweepFlag + " " + tp1.x + " " + tp1.y,
          fill: "none"
        });
        defs.appendChild(labelPathEl);

        /* Truncate long module names if sweep is narrow */
        var displayName = mod.name;
        if (sweep < 30 && displayName.length > 8) {
          displayName = displayName.slice(0, 7) + "…";
        } else if (sweep < 45 && displayName.length > 10) {
          displayName = displayName.slice(0, 9) + "…";
        }

        var textEl = svgEl("text");
        var textPathEl = svgEl("textPath", {
          href: "#" + pathId,
          startOffset: "50%"
        });
        textEl.setAttribute("class", "label-mod");
        textPathEl.textContent = displayName;
        textEl.appendChild(textPathEl);
        labelsG.appendChild(textEl);
      }

      /* ---- Outer ring: individual tests ---- */
      var testStartDeg = startDeg;
      /* One thin arc per test — equal angular slices within the module's wedge */
      var perTest = sweep / modCount;

      mod.tests.forEach(function (test, ti) {
        var tStart = testStartDeg + ti * perTest;
        var tEnd   = tStart + perTest;

        /* Tiny gap between test arcs */
        var gap = Math.min(0.8, perTest * 0.1);
        var tStartG = tStart + gap / 2;
        var tEndG   = tEnd   - gap / 2;

        var status = TV.helpers.current(test);
        var tColor = TV.colorFor(status);

        var testPathD = arcPath(cx, cy, testInnerR, testOuterR, tStartG, tEndG);
        if (!testPathD) return;

        var passRate = TV.helpers.passRate(test);

        var testEl = svgEl("path", {
          d: testPathD,
          fill: tColor,
          "fill-opacity": "0.88",
          stroke: "#160a2b",
          "stroke-width": "0.8",
          "class": "arc-test",
          "data-test-id": test.id,
          "aria-label": test.name + " — " + status
        });

        testEl.addEventListener("mousemove", function (e) {
          var html =
            '<div class="tt-title">' + test.name + '</div>' +
            '<div class="tt-row" style="color:var(--muted);margin-bottom:3px;">' + mod.name + '</div>' +
            '<div class="tt-row">' + statusDot(status) + TV.LABELS[status] + '</div>' +
            '<div class="tt-row">Pass rate: ' + pct(passRate) + '</div>';
          showTooltip(html, e.clientX, e.clientY);
        });
        testEl.addEventListener("mouseleave", hideTooltip);
        arcsG.appendChild(testEl);
      });

      startDeg = endDeg;
    });

    /* ---- Centre hole content ---- */
    /* Subtle background circle */
    var holeBg = svgEl("circle", {
      cx: cx,
      cy: cy,
      r: innerHoleR - 1,
      fill: "#160a2b",
      "fill-opacity": "0.9"
    });
    chartG.appendChild(holeBg);

    /* Pass percentage — large */
    var pctColor = overallPassPct >= 80 ? "#34d399" : overallPassPct >= 60 ? "#fbbf24" : "#f87171";
    var pctText = svgEl("text", {
      x: cx,
      y: cy - 9,
      "class": "centre-pct",
      fill: pctColor
    });
    pctText.textContent = overallPassPct + "%";
    chartG.appendChild(pctText);

    /* "N tests" sub-label */
    var subText = svgEl("text", {
      x: cx,
      y: cy + 11,
      "class": "centre-sub"
    });
    subText.textContent = totalTests + " tests";
    chartG.appendChild(subText);

    root.appendChild(svg);

    /* ---- Legend ---- */
    var legend = document.createElement("div");
    legend.className = "sb-legend";
    var legendItems = [
      { status: "pass", label: "Passed" },
      { status: "fail", label: "Failed" },
      { status: "skip", label: "Skipped" }
    ];
    legendItems.forEach(function (item) {
      var li = document.createElement("div");
      li.className = "sb-legend-item";
      var sw = document.createElement("div");
      sw.className = "sb-legend-swatch";
      sw.style.background = TV.colorFor(item.status);
      var span = document.createElement("span");
      span.textContent = item.label + " (" + counts[item.status] + ")";
      li.appendChild(sw);
      li.appendChild(span);
      legend.appendChild(li);
    });
    root.appendChild(legend);
  }

  /* ------------------------------------------------------------------ *
   * unmount — clean up tooltip + listeners
   * ------------------------------------------------------------------ */
  function unmount() {
    removeTooltip();
  }

  /* ------------------------------------------------------------------ *
   * Register
   * ------------------------------------------------------------------ */
  window.TestViz.register({
    id: "sunburst",
    title: "Sunburst",
    navLabel: "Sunburst",
    tagline: "Radial hierarchy of modules and individual tests",
    how: "Two concentric rings: the inner ring divides the circle into module slices (sweep proportional to test count, tinted by pass rate), and the outer ring subdivides each slice into individual test arcs coloured by current status — pass, fail, or skip. The centre shows the overall pass percentage.",
    when: "Best for quickly spotting which module accounts for a concentration of failures or skips, and for seeing the relative size of each module at a glance. Most effective when the number of modules is small (≤12) and you want both hierarchy and individual-test status in one view.",
    mount: mount,
    unmount: unmount
  });

})();
