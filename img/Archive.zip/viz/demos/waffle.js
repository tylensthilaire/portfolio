(function () {
  "use strict";
  if (!window.TestViz) return;

  /* ------------------------------------------------------------------ *
   * Styles — injected once, scoped under .viz-waffle
   * ------------------------------------------------------------------ */
  var STYLE_ID = "viz-waffle-styles";
  if (!document.getElementById(STYLE_ID)) {
    var s = document.createElement("style");
    s.id = STYLE_ID;
    s.textContent = [
      ".viz-waffle {",
      "  display: flex;",
      "  flex-direction: row;",
      "  align-items: stretch;",
      "  gap: 32px;",
      "  padding: 24px 28px;",
      "  width: 100%;",
      "  height: 100%;",
      "  box-sizing: border-box;",
      "  overflow: hidden;",
      "}",

      /* Left column: headline + waffle + legend */
      ".viz-waffle .wf-left {",
      "  display: flex;",
      "  flex-direction: column;",
      "  align-items: center;",
      "  justify-content: center;",
      "  gap: 20px;",
      "  flex: 0 0 auto;",
      "}",

      /* Right column: module bars */
      ".viz-waffle .wf-right {",
      "  display: flex;",
      "  flex-direction: column;",
      "  justify-content: center;",
      "  gap: 10px;",
      "  flex: 1 1 auto;",
      "  min-width: 0;",
      "}",

      /* Headline readout */
      ".viz-waffle .wf-headline {",
      "  text-align: center;",
      "  line-height: 1;",
      "}",
      ".viz-waffle .wf-pct {",
      "  font-family: var(--mono);",
      "  font-size: clamp(48px, 6vw, 80px);",
      "  font-weight: 700;",
      "  letter-spacing: -0.03em;",
      "  color: var(--pass);",
      "  display: block;",
      "  line-height: 1;",
      "}",
      ".viz-waffle .wf-total {",
      "  font-family: var(--mono);",
      "  font-size: 13px;",
      "  color: var(--muted);",
      "  margin-top: 5px;",
      "  display: block;",
      "}",

      /* Waffle grid container */
      ".viz-waffle .wf-grid-wrap {",
      "  position: relative;",
      "}",
      ".viz-waffle .wf-grid {",
      "  display: grid;",
      "  grid-template-columns: repeat(10, 1fr);",
      "  gap: 3px;",
      "}",

      /* Individual squares */
      ".viz-waffle .wf-sq {",
      "  border-radius: 3px;",
      "  opacity: 0;",
      "  transform: scale(0.55);",
      "  transition: opacity 0.28s var(--ease), transform 0.28s var(--ease),",
      "              filter 0.15s var(--ease);",
      "  cursor: default;",
      "}",
      ".viz-waffle .wf-sq.is-in {",
      "  opacity: 1;",
      "  transform: scale(1);",
      "}",
      ".viz-waffle .wf-sq:hover {",
      "  filter: brightness(1.3);",
      "}",

      /* Legend */
      ".viz-waffle .wf-legend {",
      "  display: flex;",
      "  gap: 18px;",
      "  align-items: center;",
      "  flex-wrap: wrap;",
      "  justify-content: center;",
      "}",
      ".viz-waffle .wf-legend .wf-key {",
      "  display: inline-flex;",
      "  align-items: center;",
      "  gap: 8px;",
      "  cursor: default;",
      "}",
      ".viz-waffle .wf-legend .wf-swatch {",
      "  width: 12px;",
      "  height: 12px;",
      "  border-radius: 3px;",
      "  flex-shrink: 0;",
      "}",
      ".viz-waffle .wf-legend .wf-label {",
      "  font-size: 12.5px;",
      "  font-family: var(--sans);",
      "  color: var(--text-2);",
      "}",
      ".viz-waffle .wf-legend .wf-count {",
      "  font-family: var(--mono);",
      "  font-size: 11px;",
      "  color: var(--muted);",
      "}",

      /* Right panel heading */
      ".viz-waffle .wf-modules-heading {",
      "  font-size: 10.5px;",
      "  letter-spacing: 0.15em;",
      "  text-transform: uppercase;",
      "  color: var(--faint);",
      "  font-weight: 600;",
      "  margin: 0 0 4px;",
      "}",

      /* Module bar rows */
      ".viz-waffle .wf-mod-row {",
      "  display: flex;",
      "  align-items: center;",
      "  gap: 10px;",
      "  min-width: 0;",
      "}",
      ".viz-waffle .wf-mod-name {",
      "  font-size: 11.5px;",
      "  color: var(--muted);",
      "  font-family: var(--sans);",
      "  white-space: nowrap;",
      "  overflow: hidden;",
      "  text-overflow: ellipsis;",
      "  flex: 0 0 90px;",
      "  text-align: right;",
      "}",
      ".viz-waffle .wf-bar-track {",
      "  flex: 1 1 auto;",
      "  height: 8px;",
      "  border-radius: 4px;",
      "  overflow: hidden;",
      "  background: var(--panel-3);",
      "  display: flex;",
      "}",
      ".viz-waffle .wf-bar-seg {",
      "  height: 100%;",
      "  transition: width 0.5s var(--ease);",
      "}",
      ".viz-waffle .wf-mod-pct {",
      "  font-family: var(--mono);",
      "  font-size: 10.5px;",
      "  color: var(--faint);",
      "  flex: 0 0 30px;",
      "  text-align: right;",
      "}",

      /* Reduced motion */
      "@media (prefers-reduced-motion: reduce) {",
      "  .viz-waffle .wf-sq {",
      "    transition: none !important;",
      "    opacity: 1 !important;",
      "    transform: none !important;",
      "  }",
      "  .viz-waffle .wf-bar-seg {",
      "    transition: none !important;",
      "  }",
      "}"
    ].join("\n");
    document.head.appendChild(s);
  }

  /* ------------------------------------------------------------------ *
   * Largest-remainder rounding — ensures 100 squares sum to exactly 100
   * Input:  values = [n1, n2, ...] (raw counts, sum = total)
   * Output: [r1, r2, ...] integers that sum to 100
   * ------------------------------------------------------------------ */
  function largestRemainder(values, total, target) {
    if (!target) target = 100;
    var floors = values.map(function (v) { return Math.floor((v / total) * target); });
    var remainders = values.map(function (v, i) {
      return (v / total) * target - floors[i];
    });
    var allocated = floors.reduce(function (a, b) { return a + b; }, 0);
    var deficit = target - allocated;
    // Build index array sorted by remainder descending
    var indices = values.map(function (_, i) { return i; });
    indices.sort(function (a, b) { return remainders[b] - remainders[a]; });
    for (var k = 0; k < deficit; k++) {
      floors[indices[k]] += 1;
    }
    return floors;
  }

  /* ------------------------------------------------------------------ *
   * Module proportions helper (used for the per-module bars)
   * ------------------------------------------------------------------ */
  function getModulePcts(TV) {
    return TV.modules.map(function (mod) {
      var c = TV.helpers.moduleCountsAt(mod.name, null);
      return {
        name: mod.name,
        counts: c,
        pass: c.total ? c.pass / c.total : 0,
        fail: c.total ? c.fail / c.total : 0,
        skip: c.total ? c.skip / c.total : 0
      };
    });
  }

  /* ------------------------------------------------------------------ *
   * State shared between mount and unmount
   * ------------------------------------------------------------------ */
  var _tooltip = null;
  var _animFrames = [];

  function removeTooltip() {
    if (_tooltip && _tooltip.parentNode) {
      _tooltip.parentNode.removeChild(_tooltip);
    }
    _tooltip = null;
  }

  function getOrCreateTooltip() {
    if (!_tooltip) {
      _tooltip = document.createElement("div");
      _tooltip.className = "viz-tooltip";
      document.body.appendChild(_tooltip);
    }
    return _tooltip;
  }

  function showTooltip(e, titleText, rows) {
    var tt = getOrCreateTooltip();
    var html = "<div class=\"tt-title\">" + titleText + "</div>";
    rows.forEach(function (row) {
      html += "<div class=\"tt-row\">" + row + "</div>";
    });
    tt.innerHTML = html;
    tt.classList.add("is-visible");
    positionTooltip(e);
  }

  function positionTooltip(e) {
    if (!_tooltip) return;
    var x = e.clientX + 14;
    var y = e.clientY - 10;
    var tw = _tooltip.offsetWidth || 160;
    var th = _tooltip.offsetHeight || 50;
    if (x + tw > window.innerWidth - 8) x = e.clientX - tw - 14;
    if (y + th > window.innerHeight - 8) y = window.innerHeight - th - 8;
    _tooltip.style.left = x + "px";
    _tooltip.style.top  = y + "px";
  }

  function hideTooltip() {
    if (_tooltip) _tooltip.classList.remove("is-visible");
  }

  /* ------------------------------------------------------------------ *
   * mount
   * ------------------------------------------------------------------ */
  function mount(root, TV) {
    // Clear any lingering animation IDs from previous mount
    _animFrames.forEach(function (id) { clearTimeout(id); });
    _animFrames = [];

    var counts = TV.helpers.currentCounts();
    var total  = counts.total;

    // Largest-remainder distribution over 100 squares
    var rawValues = [counts.pass, counts.fail, counts.skip];
    var squares   = largestRemainder(rawValues, total, 100);
    var passSq    = squares[0];
    var failSq    = squares[1];
    var skipSq    = squares[2];

    // Headline pass %
    var passPct = total > 0 ? Math.round((counts.pass / total) * 100) : 0;

    // ---- Outer layout ----------------------------------------
    var outer = document.createElement("div");
    outer.className = "viz-waffle";
    root.appendChild(outer);

    // ---- Left column -----------------------------------------
    var left = document.createElement("div");
    left.className = "wf-left";
    outer.appendChild(left);

    // Headline
    var headline = document.createElement("div");
    headline.className = "wf-headline";
    var pctSpan = document.createElement("span");
    pctSpan.className = "wf-pct";
    pctSpan.textContent = passPct + "%";
    var totalSpan = document.createElement("span");
    totalSpan.className = "wf-total";
    totalSpan.textContent = total + " tests";
    headline.appendChild(pctSpan);
    headline.appendChild(totalSpan);
    left.appendChild(headline);

    // Waffle grid — size it to be square and fit the container
    // We calculate the max dimension available.  Because left column is
    // centered we just pick a fixed max and let CSS clamp it.
    var availH = root.clientHeight || 500;
    var availW = root.clientWidth  || 800;
    // Rough estimate: left col takes ~half width on wide screens, but
    // the grid itself should be as large as possible while square.
    // We constrain to a reasonable max so it stays readable.
    var maxSize = Math.min(
      availW * 0.42,   // never more than 42% of total width
      availH * 0.56,   // never more than 56% of height
      380              // absolute cap
    );
    // Minimum: honour ~700px viewport
    var gridSize = Math.max(maxSize, 180);

    var gridWrap = document.createElement("div");
    gridWrap.className = "wf-grid-wrap";
    gridWrap.style.width  = gridSize + "px";
    gridWrap.style.height = gridSize + "px";
    left.appendChild(gridWrap);

    var grid = document.createElement("div");
    grid.className = "wf-grid";
    // Cell size = (gridSize - 9*gap) / 10
    var gap     = Math.max(2, Math.round(gridSize * 0.008));
    var cellSize = Math.floor((gridSize - gap * 9) / 10);
    grid.style.gap = gap + "px";
    grid.style.width  = gridSize + "px";
    grid.style.height = gridSize + "px";
    gridWrap.appendChild(grid);

    // Build 100 squares: pass block first, then skip, then fail
    // (skip in middle so the "good" green block reads clean)
    var statusOrder = [
      { status: "pass", count: passSq },
      { status: "skip", count: skipSq },
      { status: "fail", count: failSq }
    ];
    var allSquares = [];
    statusOrder.forEach(function (entry) {
      for (var i = 0; i < entry.count; i++) {
        allSquares.push(entry.status);
      }
    });

    var colorMap = {
      pass: TV.colorFor("pass"),
      fail: TV.colorFor("fail"),
      skip: TV.colorFor("skip")
    };

    // Track hover for module-bar highlight (not strictly needed, but future-proof)
    allSquares.forEach(function (status, idx) {
      var sq = document.createElement("div");
      sq.className = "wf-sq";
      sq.style.width       = cellSize + "px";
      sq.style.height      = cellSize + "px";
      sq.style.background  = colorMap[status];
      sq.dataset.status    = status;

      // Hover tooltip
      sq.addEventListener("mouseenter", function (e) {
        var st  = sq.dataset.status;
        var cnt = counts[st];
        var pct = total > 0 ? Math.round((cnt / total) * 100) : 0;
        var sqCount = st === "pass" ? passSq : (st === "fail" ? failSq : skipSq);
        showTooltip(e,
          TV.LABELS[st],
          [
            cnt + " test" + (cnt !== 1 ? "s" : "") + " (" + pct + "%)",
            sqCount + " / 100 squares"
          ]
        );
      });
      sq.addEventListener("mousemove", positionTooltip);
      sq.addEventListener("mouseleave", hideTooltip);

      grid.appendChild(sq);
    });

    // Staggered entrance animation
    var allSqEls = grid.querySelectorAll(".wf-sq");
    allSqEls.forEach(function (el, i) {
      var delay = 15 + i * 12; // ~1.2 s total for 100 squares
      var id = setTimeout(function () {
        el.classList.add("is-in");
      }, delay);
      _animFrames.push(id);
    });

    // ---- Legend ----------------------------------------------
    var legend = document.createElement("div");
    legend.className = "wf-legend";
    left.appendChild(legend);

    TV.STATUSES.forEach(function (st) {
      var cnt = counts[st];
      var pct = total > 0 ? Math.round((cnt / total) * 100) : 0;
      var key = document.createElement("span");
      key.className = "wf-key";

      var swatch = document.createElement("span");
      swatch.className = "wf-swatch";
      swatch.style.background = colorMap[st];

      var labelEl = document.createElement("span");
      labelEl.className = "wf-label";
      labelEl.textContent = TV.LABELS[st];

      var countEl = document.createElement("span");
      countEl.className = "wf-count";
      countEl.textContent = cnt + " · " + pct + "%";

      key.appendChild(swatch);
      key.appendChild(labelEl);
      key.appendChild(countEl);

      // Hover tooltip on legend key
      key.addEventListener("mouseenter", function (e) {
        var sqCount = st === "pass" ? passSq : (st === "fail" ? failSq : skipSq);
        showTooltip(e,
          TV.LABELS[st],
          [
            cnt + " test" + (cnt !== 1 ? "s" : "") + " (" + pct + "%)",
            sqCount + " / 100 squares"
          ]
        );
      });
      key.addEventListener("mousemove", positionTooltip);
      key.addEventListener("mouseleave", hideTooltip);

      legend.appendChild(key);
    });

    // ---- Right column: module bars ---------------------------
    var right = document.createElement("div");
    right.className = "wf-right";
    outer.appendChild(right);

    var modHeading = document.createElement("p");
    modHeading.className = "wf-modules-heading";
    modHeading.textContent = "By Module";
    right.appendChild(modHeading);

    var modData = getModulePcts(TV);
    modData.forEach(function (mod) {
      var row = document.createElement("div");
      row.className = "wf-mod-row";

      var nameEl = document.createElement("span");
      nameEl.className = "wf-mod-name";
      nameEl.textContent = mod.name;
      nameEl.title = mod.name;

      var track = document.createElement("div");
      track.className = "wf-bar-track";

      var pctEl = document.createElement("span");
      pctEl.className = "wf-mod-pct";
      var modPassPct = mod.counts.total > 0
        ? Math.round((mod.counts.pass / mod.counts.total) * 100)
        : 0;
      pctEl.textContent = modPassPct + "%";

      // Three segments: pass / skip / fail
      var segs = [
        { status: "pass", pct: mod.pass },
        { status: "skip", pct: mod.skip },
        { status: "fail", pct: mod.fail }
      ];
      segs.forEach(function (seg) {
        var segEl = document.createElement("div");
        segEl.className = "wf-bar-seg";
        segEl.style.width      = (seg.pct * 100).toFixed(2) + "%";
        segEl.style.background = colorMap[seg.status];
        track.appendChild(segEl);
      });

      // Tooltip for each module bar
      row.addEventListener("mouseenter", function (e) {
        var c = mod.counts;
        showTooltip(e,
          mod.name,
          [
            "✔ " + c.pass + " passed",
            "✕ " + c.fail + " failed",
            "▶ " + c.skip + " skipped",
            modPassPct + "% pass rate"
          ]
        );
      });
      row.addEventListener("mousemove", positionTooltip);
      row.addEventListener("mouseleave", hideTooltip);

      row.appendChild(nameEl);
      row.appendChild(track);
      row.appendChild(pctEl);
      right.appendChild(row);
    });
  }

  /* ------------------------------------------------------------------ *
   * unmount — clean up tooltip + pending animation timeouts
   * ------------------------------------------------------------------ */
  function unmount() {
    _animFrames.forEach(function (id) { clearTimeout(id); });
    _animFrames = [];
    removeTooltip();
  }

  /* ------------------------------------------------------------------ *
   * Register
   * ------------------------------------------------------------------ */
  window.TestViz.register({
    id:       "waffle",
    title:    "Waffle Chart",
    navLabel: "Waffle",
    tagline:  "Pass rate at a glance — 100 squares, each worth 1%",
    how:  "100 equal squares represent the full test suite. Each square's colour (green / amber / red) shows whether that slice of tests passed, was skipped, or failed. Squares are allocated by largest-remainder rounding so proportions are exact. A secondary row of per-module stacked bars breaks down the same data by team area.",
    when: "Reach for the waffle when you need an immediate, non-technical read of overall health — at a stand-up, on a status dashboard, or when communicating coverage to stakeholders who don't read tables. It trades granularity for instant legibility.",
    mount:   mount,
    unmount: unmount
  });
})();
