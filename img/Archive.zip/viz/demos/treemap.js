/* =====================================================================
   TestViz — Treemap demo
   Two-level squarified treemap: Level 1 = modules (area ∝ test count),
   Level 2 = individual tests coloured by current status.
   ===================================================================== */
(function () {
  "use strict";
  if (!window.TestViz) return;

  /* ------------------------------------------------------------------ *
   * Scoped styles — injected once
   * ------------------------------------------------------------------ */
  var STYLE_ID = "viz-treemap-styles";
  if (!document.getElementById(STYLE_ID)) {
    var s = document.createElement("style");
    s.id = STYLE_ID;
    s.textContent = [
      /* Container */
      ".viz-treemap { width:100%; height:100%; position:relative; overflow:hidden; }",

      /* SVG fills container */
      ".viz-treemap svg { display:block; width:100%; height:100%; }",

      /* Module group entrance animation */
      ".viz-treemap .tm-module { cursor:default; }",
      ".viz-treemap .tm-module-bg {",
      "  fill: var(--panel-2);",
      "  rx: 8;",
      "  stroke: var(--border-strong);",
      "  stroke-width: 1;",
      "}",

      /* Test cells */
      ".viz-treemap .tm-cell {",
      "  cursor: pointer;",
      "  transition: opacity 0.15s ease;",
      "}",
      ".viz-treemap .tm-cell:hover { opacity: 0.75; }",
      ".viz-treemap .tm-cell rect {",
      "  transition: transform 0.15s ease;",
      "}",
      ".viz-treemap .tm-cell.is-hovered rect {",
      "  stroke: #fff;",
      "  stroke-width: 1.5;",
      "  stroke-opacity: 0.7;",
      "}",

      /* Module label */
      ".viz-treemap .tm-mod-label {",
      "  font-family: var(--sans);",
      "  font-weight: 700;",
      "  fill: var(--text);",
      "  pointer-events: none;",
      "  dominant-baseline: auto;",
      "}",
      ".viz-treemap .tm-mod-sub {",
      "  font-family: var(--mono);",
      "  fill: var(--muted);",
      "  pointer-events: none;",
      "  dominant-baseline: auto;",
      "}",

      /* Entrance keyframes */
      "@keyframes tm-fade-in {",
      "  from { opacity: 0; transform: scale(0.94); }",
      "  to   { opacity: 1; transform: scale(1); }",
      "}",
      "@media (prefers-reduced-motion: no-preference) {",
      "  .viz-treemap .tm-module {",
      "    transform-origin: center;",
      "    animation: tm-fade-in 0.4s var(--ease) both;",
      "  }",
      "}",

      /* Legend strip */
      ".viz-treemap .tm-legend {",
      "  position: absolute;",
      "  bottom: 0;",
      "  left: 50%;",
      "  transform: translateX(-50%);",
      "  display: flex;",
      "  gap: 18px;",
      "  align-items: center;",
      "  padding: 6px 16px;",
      "  background: rgba(13,14,18,0.75);",
      "  border: 1px solid var(--border);",
      "  border-radius: 999px;",
      "  font-size: 11.5px;",
      "  font-family: var(--sans);",
      "  color: var(--muted);",
      "  backdrop-filter: blur(6px);",
      "  -webkit-backdrop-filter: blur(6px);",
      "  pointer-events: none;",
      "}",
      ".viz-treemap .tm-legend .key {",
      "  display: inline-flex; align-items: center; gap: 6px;",
      "}",
      ".viz-treemap .tm-legend .swatch {",
      "  width: 10px; height: 10px; border-radius: 2px; display: inline-block;",
      "}"
    ].join("\n");
    document.head.appendChild(s);
  }

  /* ------------------------------------------------------------------ *
   * Squarified treemap algorithm
   * Ref: Bruls, Huizing, van Wijk (2000)
   *
   * squarify(items, rect) → [{item, x, y, w, h}, ...]
   *   items: [{value, ...}] sorted descending
   *   rect:  {x, y, w, h}
   * ------------------------------------------------------------------ */
  function squarify(items, rect) {
    if (!items.length) return [];
    var results = [];
    squarifyHelper(items.slice(), rect, results);
    return results;
  }

  function squarifyHelper(items, rect, results) {
    if (!items.length) return;
    if (items.length === 1) {
      results.push({ item: items[0], x: rect.x, y: rect.y, w: rect.w, h: rect.h });
      return;
    }

    var totalValue = 0;
    for (var i = 0; i < items.length; i++) totalValue += items[i].value;

    var row = [];
    var remaining = items.slice();

    while (remaining.length) {
      var candidate = remaining[0];
      var newRow = row.concat([candidate]);

      if (row.length === 0 || worstAspect(newRow, rect, totalValue) <= worstAspect(row, rect, totalValue)) {
        row = newRow;
        remaining.shift();
      } else {
        break;
      }
    }

    /* Lay out the committed row and recurse on the leftover rectangle */
    var newRect = layoutRow(row, rect, totalValue, results);
    squarifyHelper(remaining, newRect, results);
  }

  function worstAspect(row, rect, totalValue) {
    /* Aspect ratio of worst tile in the row */
    var rowValue = 0;
    for (var i = 0; i < row.length; i++) rowValue += row[i].value;

    var shortSide = Math.min(rect.w, rect.h);
    if (shortSide <= 0 || rowValue <= 0 || totalValue <= 0) return Infinity;

    var rowArea = (rowValue / totalValue) * (rect.w * rect.h);
    var rowWidth = rowArea / shortSide;  /* width of the strip */

    var worst = 0;
    for (var j = 0; j < row.length; j++) {
      var cellH = (row[j].value / rowValue) * shortSide;
      if (cellH <= 0) continue;
      var aspect = Math.max(rowWidth / cellH, cellH / rowWidth);
      if (aspect > worst) worst = aspect;
    }
    return worst;
  }

  function layoutRow(row, rect, totalValue, results) {
    var rowValue = 0;
    for (var i = 0; i < row.length; i++) rowValue += row[i].value;

    var areaFrac = rowValue / totalValue;
    var isWide = rect.w >= rect.h; /* lay horizontally or vertically */

    var newRect;
    if (isWide) {
      /* Row is a vertical strip on the left */
      var stripW = areaFrac * rect.w;
      var cursor = rect.y;
      for (var j = 0; j < row.length; j++) {
        var cellH = (row[j].value / rowValue) * rect.h;
        results.push({ item: row[j], x: rect.x, y: cursor, w: stripW, h: cellH });
        cursor += cellH;
      }
      newRect = { x: rect.x + stripW, y: rect.y, w: rect.w - stripW, h: rect.h };
    } else {
      /* Row is a horizontal strip on the top */
      var stripH = areaFrac * rect.h;
      var cursorX = rect.x;
      for (var k = 0; k < row.length; k++) {
        var cellW = (row[k].value / rowValue) * rect.w;
        results.push({ item: row[k], x: cursorX, y: rect.y, w: cellW, h: stripH });
        cursorX += cellW;
      }
      newRect = { x: rect.x, y: rect.y + stripH, w: rect.w, h: rect.h - stripH };
    }
    return newRect;
  }

  /* ------------------------------------------------------------------ *
   * Module-level layout helpers
   * ------------------------------------------------------------------ */
  function computeModuleLayout(TV, W, H, padding) {
    var modules = TV.modules;
    /* Sort descending by test count for squarify (best results) */
    var sorted = modules.slice().sort(function (a, b) {
      return b.tests.length - a.tests.length;
    });
    var items = sorted.map(function (m) {
      return { value: m.tests.length, mod: m };
    });
    var outerPad = padding;
    var rect = { x: outerPad, y: outerPad, w: W - outerPad * 2, h: H - outerPad * 2 };
    return squarify(items, rect);
  }

  function computeTestLayout(tests, modRect, modPad, labelH) {
    /* Inner rect leaving room for module label and padding */
    var innerX = modRect.x + modPad;
    var innerY = modRect.y + labelH;
    var innerW = modRect.w - modPad * 2;
    var innerH = modRect.h - labelH - modPad;
    if (innerW <= 0 || innerH <= 0) return [];

    var sorted = tests.slice().sort(function (a, b) {
      return 1; /* equal weight; natural order is fine */
    });
    /* All tests have equal value = 1 */
    var items = sorted.map(function (t) {
      return { value: 1, test: t };
    });
    return squarify(items, { x: innerX, y: innerY, w: innerW, h: innerH });
  }

  /* ------------------------------------------------------------------ *
   * SVG helpers
   * ------------------------------------------------------------------ */
  var SVG_NS = "http://www.w3.org/2000/svg";

  function svgEl(tag, attrs) {
    var el = document.createElementNS(SVG_NS, tag);
    if (attrs) {
      Object.keys(attrs).forEach(function (k) {
        el.setAttribute(k, attrs[k]);
      });
    }
    return el;
  }

  function hexToRgba(hex, alpha) {
    var r = parseInt(hex.slice(1, 3), 16);
    var g = parseInt(hex.slice(3, 5), 16);
    var b = parseInt(hex.slice(5, 7), 16);
    return "rgba(" + r + "," + g + "," + b + "," + alpha + ")";
  }

  /* ------------------------------------------------------------------ *
   * Tooltip
   * ------------------------------------------------------------------ */
  var _tooltip = null;

  function getTooltip() {
    if (!_tooltip) {
      _tooltip = document.createElement("div");
      _tooltip.className = "viz-tooltip";
      document.body.appendChild(_tooltip);
    }
    return _tooltip;
  }

  function showTooltip(e, test, TV) {
    var tt = getTooltip();
    var status = TV.helpers.current(test);
    var passRate = Math.round(TV.helpers.passRate(test) * 100);
    var flak = Math.round(TV.helpers.flakiness(test) * 100);
    var statusColor = TV.colorFor(status);

    tt.innerHTML =
      '<div class="tt-title">' + escHtml(test.name) + '</div>' +
      '<div class="tt-row">Module: ' + escHtml(test.module) + '</div>' +
      '<div class="tt-row" style="color:' + statusColor + '">Status: ' + TV.LABELS[status] + '</div>' +
      '<div class="tt-row">Pass rate: ' + passRate + '%  &nbsp;Flakiness: ' + flak + '%</div>';

    positionTooltip(tt, e);
    tt.classList.add("is-visible");
  }

  function positionTooltip(tt, e) {
    var x = e.clientX + 14;
    var y = e.clientY - 10;
    var w = tt.offsetWidth || 220;
    var h = tt.offsetHeight || 80;
    if (x + w > window.innerWidth - 8) x = e.clientX - w - 14;
    if (y + h > window.innerHeight - 8) y = e.clientY - h - 4;
    tt.style.left = x + "px";
    tt.style.top = y + "px";
  }

  function hideTooltip() {
    if (_tooltip) _tooltip.classList.remove("is-visible");
  }

  function removeTooltip() {
    if (_tooltip && _tooltip.parentNode) {
      _tooltip.parentNode.removeChild(_tooltip);
    }
    _tooltip = null;
  }

  function escHtml(str) {
    return String(str)
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;");
  }

  /* ------------------------------------------------------------------ *
   * mount
   * ------------------------------------------------------------------ */
  var _mousemoveHandler = null;

  function mount(root, TV) {
    /* ---- measure container ---- */
    var W = root.clientWidth  || root.offsetWidth  || 900;
    var H = root.clientHeight || root.offsetHeight || 600;

    /* ---- constants ---- */
    var OUTER_PAD   = 6;   /* gap from container edge */
    var MOD_GAP     = 4;   /* gap between module tiles */
    var CELL_PAD    = 1.5; /* gap between test cells inside a module */
    var LABEL_FONT  = Math.min(13, Math.max(10, W / 80));
    var LABEL_H_MIN = 34;  /* minimum header height for module label */

    /* ---- build SVG ---- */
    var svg = svgEl("svg", {
      viewBox: "0 0 " + W + " " + H,
      width: W,
      height: H,
      role: "img",
      "aria-label": "Treemap of test suite modules and individual tests"
    });

    /* ---- module layout ---- */
    var modLayouts = computeModuleLayout(TV, W, H, OUTER_PAD);

    modLayouts.forEach(function (ml, mi) {
      var mod = ml.item.mod;

      /* Inset the module rect by MOD_GAP/2 for gap between tiles */
      var gap2 = MOD_GAP / 2;
      var mx = ml.x + gap2;
      var my = ml.y + gap2;
      var mw = ml.w - MOD_GAP;
      var mh = ml.h - MOD_GAP;
      if (mw <= 0 || mh <= 0) return;

      /* ---- module group ---- */
      var g = svgEl("g", { "class": "tm-module" });
      g.style.animationDelay = (mi * 40) + "ms";

      /* Module background rect */
      var bgRect = svgEl("rect", {
        x: mx, y: my, width: mw, height: mh,
        rx: 8, ry: 8,
        fill: "var(--panel-2)",
        stroke: "var(--border-strong)",
        "stroke-width": "1"
      });
      g.appendChild(bgRect);

      /* ---- compute label height ---- */
      var counts = TV.helpers.moduleCountsAt(mod.name, null);
      var passRate = counts.total ? Math.round((counts.pass / counts.total) * 100) : 0;
      var labelH = Math.max(LABEL_H_MIN, mh * 0.14);

      /* ---- test cell layout ---- */
      var testLayouts = computeTestLayout(mod.tests, { x: mx, y: my, w: mw, h: mh }, CELL_PAD * 2, labelH);

      testLayouts.forEach(function (tl) {
        var test = tl.item.test;
        var status = TV.helpers.current(test);
        var color = TV.colorFor(status);

        var cx = tl.x + CELL_PAD;
        var cy = tl.y + CELL_PAD;
        var cw = tl.w - CELL_PAD * 2;
        var ch = tl.h - CELL_PAD * 2;
        if (cw <= 0 || ch <= 0) return;

        var cellG = svgEl("g", { "class": "tm-cell" });
        cellG.setAttribute("role", "img");
        cellG.setAttribute("aria-label", test.name + " – " + TV.LABELS[status]);

        var radius = Math.min(3, cw / 4, ch / 4);
        var cellRect = svgEl("rect", {
          x: cx, y: cy, width: cw, height: ch,
          rx: radius, ry: radius,
          fill: color,
          "fill-opacity": "0.88"
        });
        cellG.appendChild(cellRect);

        /* Hover events on the cell group */
        cellG.addEventListener("mouseenter", function (e) {
          cellG.classList.add("is-hovered");
          showTooltip(e, test, TV);
        });
        cellG.addEventListener("mouseleave", function () {
          cellG.classList.remove("is-hovered");
          hideTooltip();
        });

        g.appendChild(cellG);
      });

      /* ---- module label (on top so it overlaps cells) ---- */
      var showLabel = mw > 60 && mh > 38;
      if (showLabel) {
        var lx = mx + 9;
        var ly = my + 8;
        var maxLabelW = mw - 18;

        /* Module name */
        var nameEl = svgEl("text", {
          x: lx, y: ly + LABEL_FONT,
          "font-size": LABEL_FONT,
          "font-weight": "700",
          "class": "tm-mod-label",
          "clip-path": "url(#lbl-clip-" + mi + ")"
        });
        nameEl.textContent = mod.name;
        g.appendChild(nameEl);

        /* Sub-label: counts */
        var subFontSize = Math.max(9, LABEL_FONT - 2);
        var subY = ly + LABEL_FONT + subFontSize + 2;
        if (subY < my + labelH) {
          var passStr = counts.pass + "/" + counts.total + " pass";
          if (counts.fail > 0) passStr += " · " + counts.fail + " fail";
          if (counts.skip > 0) passStr += " · " + counts.skip + " skip";

          var subEl = svgEl("text", {
            x: lx, y: subY,
            "font-size": subFontSize,
            "class": "tm-mod-sub"
          });
          subEl.textContent = passStr;
          g.appendChild(subEl);
        }

        /* Clip path to constrain label to module width */
        var defs = svg.querySelector("defs") || svgEl("defs", {});
        if (!svg.querySelector("defs")) svg.insertBefore(defs, svg.firstChild);
        var cp = svgEl("clipPath", { id: "lbl-clip-" + mi });
        cp.appendChild(svgEl("rect", { x: mx, y: my, width: maxLabelW, height: labelH }));
        defs.appendChild(cp);

        /* Subtle gradient header wash so label is readable over cells */
        var gradId = "tm-hdr-" + mi;
        var grad = svgEl("linearGradient", {
          id: gradId, x1: "0", y1: "0", x2: "0", y2: "1",
          gradientUnits: "objectBoundingBox"
        });
        var stop1 = svgEl("stop", { offset: "0%", "stop-color": "#160a2b", "stop-opacity": "0.82" });
        var stop2 = svgEl("stop", { offset: "100%", "stop-color": "#160a2b", "stop-opacity": "0" });
        grad.appendChild(stop1);
        grad.appendChild(stop2);
        defs.appendChild(grad);

        var headerRect = svgEl("rect", {
          x: mx, y: my, width: mw, height: labelH,
          rx: 8, ry: 8,
          fill: "url(#" + gradId + ")",
          "pointer-events": "none"
        });
        g.insertBefore(headerRect, nameEl);
      }

      svg.appendChild(g);
    });

    root.appendChild(svg);

    /* ---- mouse move for continuous tooltip repositioning ---- */
    _mousemoveHandler = function (e) {
      if (_tooltip && _tooltip.classList.contains("is-visible")) {
        positionTooltip(_tooltip, e);
      }
    };
    document.addEventListener("mousemove", _mousemoveHandler);

    /* ---- legend ---- */
    var legend = document.createElement("div");
    legend.className = "tm-legend";
    TV.STATUSES.forEach(function (st) {
      var key = document.createElement("span");
      key.className = "key";
      var swatch = document.createElement("span");
      swatch.className = "swatch";
      swatch.style.background = TV.colorFor(st);
      var label = document.createElement("span");
      label.textContent = TV.LABELS[st];
      key.appendChild(swatch);
      key.appendChild(label);
      legend.appendChild(key);
    });
    root.appendChild(legend);
  }

  /* ------------------------------------------------------------------ *
   * unmount
   * ------------------------------------------------------------------ */
  function unmount() {
    hideTooltip();
    removeTooltip();
    if (_mousemoveHandler) {
      document.removeEventListener("mousemove", _mousemoveHandler);
      _mousemoveHandler = null;
    }
  }

  /* ------------------------------------------------------------------ *
   * Register
   * ------------------------------------------------------------------ */
  window.TestViz.register({
    id: "treemap",
    title: "Treemap",
    navLabel: "Treemap",
    tagline: "Module hierarchy and per-test status at a glance",
    how: "Each module is a rectangle sized proportional to its test count, laid out using a squarified algorithm to keep tiles close to square. Inside each module, individual tests are subdivided as equal-weight cells coloured by their current status (green = pass, red = fail, amber = skip).",
    when: "Use when you want to see both the structural scale of each module and the distribution of failures or skips within it. Large red patches in a big module immediately signal where attention is needed.",
    mount: mount,
    unmount: unmount
  });

})();
