/* =====================================================================
   TestViz — shared foundation
   Namespace + demo registry + seeded mock dataset + helpers.
   Classic script (NO ES modules) so the whole site runs from file://.
   This file MUST be loaded first (before any demo and before app.js).
   Read-only for demo agents.
   ===================================================================== */
(function () {
  "use strict";

  var TV = (window.TestViz = window.TestViz || {});

  /* ------------------------------------------------------------------ *
   * 1. Demo registry
   *    Each demo file calls TestViz.register({...}) exactly once.
   * ------------------------------------------------------------------ */
  TV.registry = TV.registry || [];
  TV.register = function (demo) {
    if (!demo || !demo.id || typeof demo.mount !== "function") {
      console.error("TestViz.register: invalid demo object", demo);
      return;
    }
    TV.registry.push(demo);
  };

  /* ------------------------------------------------------------------ *
   * 2. Status vocabulary + colour tokens (mirror styles.css :root)
   * ------------------------------------------------------------------ */
  TV.STATUS = { PASS: "pass", FAIL: "fail", SKIP: "skip" };
  TV.STATUSES = ["pass", "fail", "skip"];
  TV.LABELS = { pass: "Passed", fail: "Failed", skip: "Skipped" };
  TV.COLORS = {
    pass: "#34d399",
    fail: "#f87171",
    skip: "#fbbf24",
    accent: "#a855f7",
    accent2: "#f472b6",
    bg: "#160a2b",
    panel: "#241046",
    panel2: "#2c1452",
    text: "#f1edfa",
    muted: "#9a8dbd",
    border: "rgba(176,140,245,0.16)",
    grid: "rgba(176,140,245,0.09)"
  };
  TV.colorFor = function (status) {
    return TV.COLORS[status] || TV.COLORS.muted;
  };

  /* ------------------------------------------------------------------ *
   * 3. Deterministic PRNG (mulberry32) — stable data every load
   * ------------------------------------------------------------------ */
  function mulberry32(seed) {
    return function () {
      seed |= 0;
      seed = (seed + 0x6d2b79f5) | 0;
      var t = Math.imul(seed ^ (seed >>> 15), 1 | seed);
      t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
      return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
  }
  var rand = mulberry32(20260626);
  function chance(p) { return rand() < p; }
  function pick(arr) { return arr[Math.floor(rand() * arr.length)]; }

  /* ------------------------------------------------------------------ *
   * 4. Runs (12 runs of history, oldest -> newest; last = current)
   * ------------------------------------------------------------------ */
  var RUN_COUNT = 12;
  var runs = [];
  var nowTs = Date.UTC(2026, 5, 26, 9, 0, 0); // 26 Jun 2026 09:00 UTC
  for (var i = 0; i < RUN_COUNT; i++) {
    var ts = nowTs - (RUN_COUNT - 1 - i) * 24 * 3600 * 1000;
    runs.push({
      index: i,
      id: "run-" + (i + 1),
      label: "#" + (101 + i),
      build: 101 + i,
      ts: ts,
      date: new Date(ts)
    });
  }

  /* ------------------------------------------------------------------ *
   * 5. Module + test definitions (names are fixed; behaviour is seeded)
   * ------------------------------------------------------------------ */
  var SCENARIOS = {
    Authentication: [
      "logs in with valid credentials", "rejects invalid password",
      "handles 2FA challenge", "locks after 5 attempts",
      "refreshes expired token", "resends OTP code",
      "enforces session timeout", "blocks reused password",
      "signs out all devices", "supports biometric login",
      "rejects revoked token", "enforces password policy"
    ],
    Payments: [
      "processes standard payment", "declines insufficient funds",
      "applies daily limit", "retries on gateway timeout",
      "handles duplicate request", "validates payee details",
      "processes scheduled payment", "reverses failed payment",
      "applies FX conversion", "flags suspicious amount",
      "confirms with 3DS", "handles partial settlement",
      "records audit trail", "rejects expired mandate",
      "batches direct debits", "notifies on completion"
    ],
    Accounts: [
      "creates current account", "lists transactions",
      "calculates balance", "applies overdraft",
      "closes dormant account", "updates address",
      "links joint holder", "exports CSV",
      "paginates history", "filters by date range",
      "computes interest", "flags negative balance"
    ],
    Transfers: [
      "schedules transfer", "validates IBAN",
      "cancels pending transfer", "enforces transfer limit",
      "handles same-day transfer", "splits standing order",
      "retries on rejection", "confirms recipient",
      "logs reference", "handles weekend delay"
    ],
    Cards: [
      "freezes card", "orders replacement",
      "sets contactless limit", "activates new card",
      "reports lost card", "views PIN securely",
      "toggles online payments", "adds to wallet",
      "tracks delivery"
    ],
    Statements: [
      "renders statement PDF", "emails monthly statement",
      "aggregates by category", "handles empty period",
      "exports OFX", "redacts sensitive data",
      "paginates long statement", "includes pending items"
    ],
    Notifications: [
      "sends push alert", "batches digest email",
      "respects quiet hours", "retries failed delivery",
      "unsubscribes user", "localises message",
      "throttles duplicates"
    ],
    Onboarding: [
      "verifies identity document", "captures selfie",
      "checks credit file", "creates profile",
      "accepts terms", "sets up direct deposit",
      "completes KYC review", "resumes saved application",
      "sends welcome pack"
    ]
  };

  // Exact archetype mix per module (counts; padded with "stable" to fit size).
  // Tuned so the suite reads ~80% green with clear hotspots in Payments/Transfers.
  var MIX = {
    Authentication: { stable: 11, flaky: 1 },
    Payments:       { stable: 8, flaky: 3, broken: 2, regressing: 2, improving: 1 },
    Accounts:       { stable: 10, skipped: 2 },
    Transfers:      { stable: 6, flaky: 2, broken: 1, regressing: 1 },
    Cards:          { stable: 8, improving: 1 },
    Statements:     { stable: 6, skipped: 2 },
    Notifications:  { stable: 5, flaky: 1, skipped: 1 },
    Onboarding:     { stable: 6, improving: 2, flaky: 1 }
  };

  function buildArchetypeList(mix, size) {
    var list = [];
    Object.keys(mix).forEach(function (k) {
      for (var i = 0; i < mix[k]; i++) list.push(k);
    });
    while (list.length < size) list.push("stable");
    for (var j = list.length - 1; j > 0; j--) {      // seeded Fisher–Yates shuffle
      var r = Math.floor(rand() * (j + 1));
      var tmp = list[j]; list[j] = list[r]; list[r] = tmp;
    }
    return list.slice(0, size);
  }

  function genHistory(archetype) {
    var h = [], k, at;
    switch (archetype) {
      case "broken": {                                 // healthy briefly, then red
        var breakAt = Math.floor(rand() * 3);
        for (k = 0; k < RUN_COUNT; k++) h.push(k < breakAt ? "pass" : (chance(0.1) ? "skip" : "fail"));
        break;
      }
      case "flaky":                                    // genuinely volatile
        for (k = 0; k < RUN_COUNT; k++) h.push(chance(0.4) ? "fail" : (chance(0.1) ? "skip" : "pass"));
        break;
      case "improving": {                              // red/skip early -> green later
        var fixAt = 5 + Math.floor(rand() * 3);
        for (k = 0; k < RUN_COUNT; k++) h.push(k < fixAt ? (chance(0.45) ? "fail" : "skip") : "pass");
        break;
      }
      case "regressing": {                             // green early -> red now
        var rb = 6 + Math.floor(rand() * 3);
        for (k = 0; k < RUN_COUNT; k++) h.push(k < rb ? "pass" : (chance(0.12) ? "skip" : "fail"));
        break;
      }
      case "skipped":                                  // mostly skipped (flagged off)
        for (k = 0; k < RUN_COUNT; k++) h.push(chance(0.72) ? "skip" : (chance(0.4) ? "fail" : "pass"));
        if (chance(0.7)) h[RUN_COUNT - 1] = "skip";
        break;
      case "stable":                                   // green with at most one blip
      default:
        for (k = 0; k < RUN_COUNT; k++) h.push("pass");
        if (chance(0.28)) { at = Math.floor(rand() * RUN_COUNT); h[at] = chance(0.5) ? "skip" : "fail"; }
        break;
    }
    return h;
  }

  var modules = [];
  var tIdCounter = 0;
  Object.keys(SCENARIOS).forEach(function (modName) {
    var names = SCENARIOS[modName];
    var arches = buildArchetypeList(MIX[modName], names.length);
    var tests = names.map(function (scenario, i) {
      return {
        id: "t" + (++tIdCounter),
        name: scenario,
        module: modName,
        archetype: arches[i],
        history: genHistory(arches[i])
      };
    });
    modules.push({ name: modName, tests: tests });
  });

  /* ------------------------------------------------------------------ *
   * 6. Helpers (pure functions over the dataset)
   * ------------------------------------------------------------------ */
  function current(t) { return t.history[t.history.length - 1]; }
  function statusAt(t, runIndex) { return t.history[runIndex]; }
  function rateOf(t, status) {
    var n = 0;
    for (var i = 0; i < t.history.length; i++) if (t.history[i] === status) n++;
    return n / t.history.length;
  }
  function flakiness(t) {
    var c = 0;
    for (var i = 1; i < t.history.length; i++) if (t.history[i] !== t.history[i - 1]) c++;
    return c / (t.history.length - 1);
  }
  function allTests() {
    var out = [];
    modules.forEach(function (m) { m.tests.forEach(function (t) { out.push(t); }); });
    return out;
  }
  function countsAt(runIndex) {
    var c = { pass: 0, fail: 0, skip: 0, total: 0 };
    allTests().forEach(function (t) {
      var s = runIndex == null ? current(t) : statusAt(t, runIndex);
      c[s]++; c.total++;
    });
    return c;
  }
  function moduleCountsAt(moduleName, runIndex) {
    var c = { pass: 0, fail: 0, skip: 0, total: 0 };
    var m = modules.filter(function (x) { return x.name === moduleName; })[0];
    if (!m) return c;
    m.tests.forEach(function (t) {
      var s = runIndex == null ? current(t) : statusAt(t, runIndex);
      c[s]++; c.total++;
    });
    return c;
  }

  TV.runs = runs;
  TV.modules = modules;
  TV.helpers = {
    current: current,
    statusAt: statusAt,
    passRate: function (t) { return rateOf(t, "pass"); },
    failRate: function (t) { return rateOf(t, "fail"); },
    skipRate: function (t) { return rateOf(t, "skip"); },
    flakiness: flakiness,
    allTests: allTests,
    totalTests: function () { return allTests().length; },
    countsAt: countsAt,
    currentCounts: function () { return countsAt(null); },
    moduleCountsAt: moduleCountsAt
  };

  /* Convenience: a single object some demos may prefer to receive. */
  TV.data = { runs: runs, modules: modules, helpers: TV.helpers };
})();
