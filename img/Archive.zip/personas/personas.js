/* ============================================================
   MPMP personas — data
   Five duty-based archetypes across the Fix / Review / Report model.
   Model Developer and Model Owner are grounded in detailed research
   with the two 1st-line roles. Model Risk Owner, MRM Governance and
   the Finance & Treasury executive are working hypotheses, built to
   the same shape, pending validation with those audiences.
   ============================================================ */

window.PERSONAS = [

  /* ---------------------------------------------------------- */
  {
    id: "model-developer",
    name: "Model Developer",
    line: "1st line of defence &middot; model execution",
    duty: "Fix",
    dutyFamily: "op",
    tier: "full",
    initials: "MD",
    colour: "#3c1053",
    summary: "Builds, runs and maintains the model day to day. First to see a breach, and usually the one who digs in and fixes it.",
    quote: "I want one place where I can see: are all the KPIs fine, and if anything isn&rsquo;t, why &mdash; so I can go straight to the cause instead of hunting for it.",
    snapshot: [
      ["Scope", "Owns the model itself &mdash; the code, the checks around it, and getting it through model-risk sign-off. Usually part of a small team of two to four."],
      ["Cadence", "Bursty, not daily. Comes to the platform after a formal run, or the moment something breaks &mdash; not on a fixed schedule. Formal runs happen a handful of times a year, plus stress-test cycles and seasonal peaks."],
      ["Also carries", "Often holds a slice of Review responsibility too &mdash; signing off a colleague&rsquo;s fix, standing in for the owner. Duties overlap more than job titles suggest."]
    ],
    behaviours: {
      intro: "How they work today &mdash; the habits any new tool has to fit around, not fight:",
      items: [
        "Code lives in version control with strict change control: the main branch is protected, changes need a second reviewer, and nobody approves their own change.",
        "Development and formal runs often happen in the same environment &mdash; there&rsquo;s rarely a separate, sealed-off production space.",
        "Confirming a run succeeded today usually means downloading an exported results file and checking it by eye.",
        "The busiest teams already run their own detailed monitoring alongside the bank&rsquo;s tools, because the volume of checks outgrew what a person can read unaided.",
        "Task tracking is slowly shifting from spreadsheets to a shared ticketing tool &mdash; because that&rsquo;s what the rest of the bank uses."
      ]
    },
    goals: [
      "See run status, runtime and KPI results together the moment a run finishes &mdash; not after a manual download.",
      "See how each KPI moved versus the previous run, automatically &mdash; not just where it stands today.",
      "See KPI history over time, to tell a genuine drift from a one-off blip.",
      "Trust thresholds because they carry context &mdash; seasonality, known exceptions, who set them &mdash; not just a static line that fires on noise.",
      "Get a fast read on what changed between model versions: a material change, or just housekeeping.",
      "Know straight away whether a breach is coming from the data or the model, and which part of the model it points to.",
      "See the status of upstream models and feeds from their own model&rsquo;s screen, so an inherited failure doesn&rsquo;t cost the first day of an investigation chasing the wrong cause.",
      "Get a tracked, assigned ticket when something needs fixing &mdash; not a line in a spreadsheet.",
      "See exceptions first, not a wall of every KPI on every model.",
      "Get results close to when a run finishes, so checking fits inside the two-to-three-day fix window instead of eating into it."
    ],
    questions: [
      "Did my last run succeed, and finish in a normal time?",
      "Is anything breaching right now on my model, and which KPI?",
      "What moved since the previous run?",
      "How has this KPI behaved over time &mdash; is this drift, or a blip?",
      "What changed between this version and the last, and does it matter?",
      "Is this breach coming from the data, or from the model itself?",
      "Which part of the model does this KPI actually point to?",
      "Is this breach mine &mdash; or inherited from an upstream model or feed?",
      "Could this be an infrastructure issue rather than a model problem?"
    ],
    pains: [
      "Confirming a run succeeded means a manual download-and-eyeball exercise, every time.",
      "Breaches inherited from an upstream model or feed look identical to a fault in their own model &mdash; telling them apart can cost a full day.",
      "Static thresholds fire on noise, and every false alarm makes the next real one easier to ignore.",
      "The busiest models already generate more monitoring output than one person can absorb &mdash; a new tool that adds noise instead of ranking it makes things worse.",
      "A fix made quickly and quietly may never get written down anywhere.",
      "A tool that doesn&rsquo;t fit around the code repository, ticketing system and chat they already live in is one more place to check, not a time-saver."
    ]
  },

  /* ---------------------------------------------------------- */
  {
    id: "model-owner",
    name: "Model Owner",
    line: "1st line of defence &middot; accountable for the model",
    duty: "Review",
    dutyFamily: "op",
    tier: "full",
    initials: "MO",
    colour: "#6a2a8a",
    summary: "Accountable for the model being fit for purpose and for signing off its health &mdash; but day-to-day fixing is almost always delegated.",
    callout: "In practice, the person accountable for a model is rarely its most frequent user. Hands-on remediation is usually delegated to a deputy or to the model developer; the owner&rsquo;s real need is a trustworthy, passive view of who&rsquo;s on it and by when &mdash; not a tool they have to operate themselves.",
    quote: "Let me know who&rsquo;s addressing it and by when &mdash; and tell me again when it&rsquo;s closed. I don&rsquo;t need to see everything; I need to trust what I&rsquo;m being shown.",
    snapshot: [
      ["Scope", "Accountable for a portfolio of roughly ten to thirty models, spread across Finance and Treasury."],
      ["Cadence", "Mostly bursty around executions and reporting cycles. Today, breach awareness mostly arrives verbally, through a deputy, at a regular team meeting &mdash; days after the fact."],
      ["Also carries", "May also hold Fix or Report duties elsewhere in the portfolio &mdash; the same senior person often wears more than one hat."]
    ],
    behaviours: {
      intro: "Senior and time-poor &mdash; what earns their trust matters as much as what they see:",
      items: [
        "Delegates implementation almost by default &mdash; their own involvement is being told who&rsquo;s fixing something and by when, and being told again when it&rsquo;s closed.",
        "Works in an evidence-first culture: a committee won&rsquo;t accept &ldquo;the model is fine&rdquo; without a paper trail behind it.",
        "Accountable against external regulatory expectations for model risk management, so any status shown to them has to be defensible, not just a green light.",
        "Treats a workaround or manual override to a model&rsquo;s output as an admission that something is underperforming, not a neutral fix.",
        "Today, mostly only hears about the breaches that don&rsquo;t get resolved quickly and quietly &mdash; a fast, clean fix may never reach them at all."
      ]
    },
    goals: [
      "Get breach notifications pitched at the right altitude &mdash; which KPI, how material, who&rsquo;s on it, by when &mdash; not a wall of technical detail.",
      "See remediation progress passively, glanceable between meetings, instead of having to ask for an update.",
      "See breaches weighed against the upcoming run or reporting calendar, so priority reflects what&rsquo;s genuinely at risk.",
      "Pull a ready-made, defensible evidence pack for a model on demand &mdash; status, history, what changed, what was decided, who signed off.",
      "Have the platform treat &ldquo;who&rsquo;s accountable&rdquo; and &ldquo;who&rsquo;s fixing it&rdquo; as two distinct things, since in practice they&rsquo;re often different people.",
      "See what was fixed quietly since they last looked, not just what&rsquo;s still open."
    ],
    questions: [
      "Which of my models needs my attention right now, and is it being fixed?",
      "Who&rsquo;s on it, and by when &mdash; has anything slipped?",
      "Is this an amber that&rsquo;s already been accepted and signed off, or a live problem?",
      "What&rsquo;s been fixed quietly since I last looked?",
      "Can I trust this status? How was it actually worked out?",
      "What can I show a committee or reviewer right now as evidence?"
    ],
    pains: [
      "Breach awareness typically arrives late and informally &mdash; a verbal update relayed at a meeting, not a timely, recorded signal.",
      "A single colour status with no visible reasoning behind it is trusted by no one, least of all the person accountable for it.",
      "Approvals and sign-off often live in email threads, which makes a poor audit trail.",
      "No passive way to check progress between meetings &mdash; checking in means asking someone.",
      "Being handed a table of every model and every KPI when only a handful genuinely need their attention."
    ]
  },

  /* ---------------------------------------------------------- */
  {
    id: "model-risk-owner",
    name: "Model Risk Owner (MRO)",
    line: "Senior Manager Function &middot; accountable for the whole model lifecycle",
    duty: "Report",
    dutyFamily: "oversight",
    tier: "hypothesis",
    initials: "RO",
    colour: "#a88336",
    summary: "The senior individual whose name goes on the attestation that the model portfolio is being run within risk appetite.",
    goals: [
      "See a consolidated view of risk across the whole model portfolio, not just individual models in isolation.",
      "Have confidence that model use aligns with the bank&rsquo;s risk appetite and with regulatory expectations for model risk management.",
      "Have a defensible basis for attestation &mdash; statuses that come with their reasoning, not bare colours, and a record that would hold up if questioned."
    ],
    questions: [
      "Is the portfolio operating within risk appetite?",
      "If this model degrades, where else would the trouble show up?",
      "Is remediation on track across the portfolio &mdash; not just on the models I hear about?"
    ],
    pains: [
      "No single consolidated view of risk across the portfolio exists today.",
      "An aggregate &ldquo;all green&rdquo; status with no clear rule behind it isn&rsquo;t something they could stand behind if challenged."
    ]
  },

  /* ---------------------------------------------------------- */
  {
    id: "mrm-governance",
    name: "MRM Governance",
    line: "2nd line of defence &middot; independent of day-to-day execution",
    duty: "Report &amp; challenge",
    dutyFamily: "oversight",
    tier: "hypothesis",
    initials: "MG",
    colour: "#8a6c25",
    summary: "The independent function that checks the checks &mdash; challenges RAG status, tracks remediation, and watches for risk building up across the portfolio.",
    goals: [
      "Consistent, auditable oversight of monitoring outcomes across the portfolio.",
      "Ability to challenge a status when the reasoning behind it doesn&rsquo;t hold up.",
      "Visibility of systemic or concentrated risk &mdash; including trouble that could spread along a chain of dependent models."
    ],
    questions: [
      "Are RAG outcomes consistent and defensible across models?",
      "Where is risk building up across the portfolio, or concentrated in a few dependencies?",
      "What&rsquo;s been fixed quietly, and is remediation genuinely on track?"
    ],
    pains: [
      "A lot of governance ritual sits on top of a thin record of what actually happened day to day &mdash; quick, quiet fixes may never reach them.",
      "Limited visibility into remediation in progress weakens their ability to challenge with confidence."
    ]
  },

  /* ---------------------------------------------------------- */
  {
    id: "exec",
    name: "Finance &amp; Treasury Executive",
    line: "Executive consumer",
    duty: "Report",
    dutyFamily: "oversight",
    tier: "hypothesis",
    initials: "CS",
    colour: "#c9a35a",
    summary: "Wants the headline, not the detail: how healthy is our model risk, and how do divisions compare.",
    goals: [
      "A summarised, trustworthy read on model-risk health across the organisation.",
      "Ability to compare how Treasury is doing against Finance."
    ],
    questions: [
      "How are we doing as an organisation?",
      "How is Treasury doing compared with Finance?"
    ],
    pains: [
      "No organisation-level summary exists today, distinct from the detailed, model-by-model views built for practitioners.",
      "A single unexplained &ldquo;all green&rdquo; headline wouldn&rsquo;t survive being challenged &mdash; it needs to be backed by something underneath."
    ]
  }
];
