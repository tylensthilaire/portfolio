/* ============================================================
   MPMP personas — renderer
   Single scrolling page: a quick-nav index, then one full section
   per persona, each carrying a real id (#model-developer etc.) so
   other prototype pages can deep-link straight to it.
   ============================================================ */
(function () {
  "use strict";

  var view = document.getElementById("view");
  var personas = window.PERSONAS || [];

  var DUTY_LABEL = {
    "Fix": "Fix",
    "Review": "Review",
    "Report": "Report",
    "Report &amp; challenge": "Report &amp; challenge"
  };

  function list(items) {
    return "<ul>" + items.map(function (i) { return "<li>" + i + "</li>"; }).join("") + "</ul>";
  }

  function avatar(p, big) {
    return '<span class="avatar' + (big ? " avatar--lg" : "") + '" aria-hidden="true" style="background:' +
      p.colour + '">' + p.initials + "</span>";
  }

  function dutyChip(p) {
    return '<span class="chip chip--duty chip--' + p.dutyFamily + '">' + p.duty + " duty</span>";
  }

  function tierChip(p) {
    return p.tier === "full"
      ? '<span class="tag tag--full">Full persona</span>'
      : '<span class="tag tag--draft">Working hypothesis</span>';
  }

  /* ---- quick-nav index card ---- */
  function navCard(p) {
    return '<a class="pcard" href="#' + p.id + '">' +
      '<div class="pcard__top">' + avatar(p) + tierChip(p) + "</div>" +
      "<h2>" + p.name + "</h2>" +
      '<p class="pcard__desc">' + p.summary + "</p>" +
      '<div class="pcard__meta">' +
        dutyChip(p) +
        '<span class="pcard__go">Jump to <span aria-hidden="true">&darr;</span></span>' +
      "</div>" +
    "</a>";
  }

  /* ---- full section ---- */
  function section(p) {
    var hypBanner = p.tier === "hypothesis"
      ? '<div class="hyp-banner"><span aria-hidden="true">&#9998;</span><div><strong>Working hypothesis &mdash; not yet validated with this audience.</strong> ' +
        "Built from the design brief and what the two evidenced personas imply about oversight needs, not from a conversation with someone who holds this duty. Treat the goals and questions below as a starting point to test, not a finding.</div></div>"
      : "";

    var quote = p.quote
      ? '<blockquote class="quote">&ldquo;' + p.quote + "&rdquo;</blockquote>"
      : "";

    var callout = p.callout
      ? '<div class="callout"><span aria-hidden="true">&#128172;</span><div>' + p.callout + "</div></div>"
      : "";

    var snapshot = p.snapshot
      ? '<div class="panel snapshot"><h3><span class="ic" aria-hidden="true">&#129517;</span>Snapshot</h3><dl>' +
        p.snapshot.map(function (r) { return "<dt>" + r[0] + "</dt><dd>" + r[1] + "</dd>"; }).join("") +
        "</dl></div>"
      : "";

    var behaviours = p.behaviours
      ? '<div class="panel"><h3><span class="ic" aria-hidden="true">&#128736;&#65039;</span>Behaviours &amp; working context</h3>' +
        "<p>" + p.behaviours.intro + "</p>" + list(p.behaviours.items) + "</div>"
      : "";

    var goalsQ =
      '<div class="cols">' +
        '<div class="panel"><h3><span class="ic" aria-hidden="true">&#127919;</span>Goals</h3>' + list(p.goals) + "</div>" +
        '<div class="panel panel--q"><h3><span class="ic" aria-hidden="true">&#10067;</span>Questions &amp; needs</h3>' + list(p.questions) + "</div>" +
      "</div>";

    var pains =
      '<div class="panel panel--pain"><h3><span class="ic" aria-hidden="true">&#9888;&#65039;</span>Key frustrations</h3>' + list(p.pains) + "</div>";

    return '<section id="' + p.id + '" class="persona persona--' + p.tier + '" aria-labelledby="' + p.id + '-h">' +
      '<div class="detail-hero">' + avatar(p, true) +
        '<div class="detail-hero__body">' +
          '<h2 id="' + p.id + '-h">' + p.name + "</h2>" +
          '<p class="line">' + p.line + "</p>" +
          '<div class="chips">' + dutyChip(p) + tierChip(p) + "</div>" +
          "<p class=\"summary\">" + p.summary + "</p>" +
          quote +
        "</div>" +
      "</div>" +
      hypBanner + callout + snapshot + behaviours + goalsQ + pains +
    "</section>";
  }

  function render() {
    var full = personas.filter(function (p) { return p.tier === "full"; });
    var hyp = personas.filter(function (p) { return p.tier === "hypothesis"; });

    var html =
      '<nav class="crumbs" aria-label="Breadcrumb">' +
        '<a href="../index.html">&larr; Back to hub</a>' +
      "</nav>" +
      '<div class="masthead">' +
        '<span class="mark" aria-hidden="true">M</span>' +
        "<div><h1>Personas</h1>" +
        "<p>Model Performance Monitoring Platform &mdash; role-based archetypes</p></div>" +
      "</div>" +
      '<p class="lede">Five archetypes for who comes to MPMP, organised by the <strong>duty</strong> they hold rather than a fixed job title &mdash; ' +
      "one person can carry more than one. Model Developer and Model Owner are built up in detail from focused research with those two roles; " +
      "Model Risk Owner, MRM Governance and the Finance &amp; Treasury executive are lighter, working hypotheses, flagged as such below.</p>" +

      '<div class="duty-legend">' +
        '<p class="section-label">The duty model</p>' +
        '<div class="duty-legend__row">' +
          '<div class="duty-legend__item"><span class="chip chip--duty chip--op">Fix duty</span><p>Investigates a breach and does the hands-on remediation.</p></div>' +
          '<div class="duty-legend__item"><span class="chip chip--duty chip--op">Review duty</span><p>Accountable for the model; approves and signs off remediation.</p></div>' +
          '<div class="duty-legend__item"><span class="chip chip--duty chip--oversight">Report duty</span><p>Needs a trustworthy summary to escalate, attest or compare &mdash; without running the platform day to day.</p></div>' +
        "</div>" +
      "</div>" +

      '<p class="section-label">Jump to a persona</p>' +
      '<div class="grid">' + personas.map(navCard).join("") + "</div>" +

      '<p class="section-label">Grounded in detail</p>' +
      full.map(section).join("") +
      '<p class="section-label">Working hypotheses &mdash; to validate</p>' +
      hyp.map(section).join("");

    view.innerHTML = html;
  }

  render();
})();
