/* ============================================================
   MPMP — data-access seam (window.API)
   The ONLY module that touches the store. Scoped to the current
   user: you only ever see the models you're authorised for, so scope
   is implicit (no mine/all toggle). One work item per breach, moved
   forward-only through its states. In production each method becomes a
   REST call whose resources mirror these shapes; swapping fixture →
   fetch is a one-module change and the views never know.
   ============================================================ */
(function () {
  'use strict';

  var DATA = window.DATA;
  var MODELS = DATA.models;
  var TICKETS = DATA.tickets;   // mutated in memory — nothing persists
  var META = DATA.meta;
  var USERS = DATA.users;
  var seq = 2042;
  var currentUserId = USERS[0].id;   // default demo identity

  // ---------------- identity / scope ----------------
  function users() { return USERS; }
  function currentUser() {
    for (var i = 0; i < USERS.length; i++) if (USERS[i].id === currentUserId) return USERS[i];
    return USERS[0];
  }
  function setUser(id) { currentUserId = id; }
  function inScope(id) { return currentUser().models.indexOf(id) >= 0; }

  // ---------------- reads ----------------
  // Estate lists are scoped to the current user; lookups by id resolve ANY
  // model/ticket, so upstream chains and deep links still work.
  function models() { return MODELS.filter(function (m) { return inScope(m.id); }); }
  function allModels() { return MODELS; }
  function model(id) { for (var i = 0; i < MODELS.length; i++) if (MODELS[i].id === id) return MODELS[i]; return null; }
  function tickets() { return TICKETS.filter(function (t) { return inScope(t.modelId); }); }
  function ticket(ref) { for (var i = 0; i < TICKETS.length; i++) if (TICKETS[i].ref === ref) return TICKETS[i]; return null; }
  function ticketsForModel(id) { return TICKETS.filter(function (t) { return t.modelId === id; }); }
  function subtasksOf(ref) { return TICKETS.filter(function (t) { return t.parentRef === ref; }); }
  function isTerminal(t) { return window.ENGINE.WORK_TERMINAL.indexOf(t.state) >= 0; }
  function openTicketForModel(id) {
    for (var i = 0; i < TICKETS.length; i++) if (TICKETS[i].modelId === id && !TICKETS[i].parentRef && !isTerminal(TICKETS[i])) return TICKETS[i];
    return null;
  }
  function kpiByCode(m, code) { for (var i = 0; i < m.kpis.length; i++) if (m.kpis[i].code === code) return m.kpis[i]; return null; }
  function signals() { return DATA.signals; }
  function meta() { return META; }
  function owners() {
    var seen = {}, out = [];
    models().forEach(function (m) { if (!seen[m.accountableOwner]) { seen[m.accountableOwner] = 1; out.push(m.accountableOwner); } });
    return out.sort();
  }

  // ---------------- triage mutations ----------------
  function nextRef() { return 'PROTO-' + (seq++); }

  function acknowledgeBreach(modelId, rationale) {
    var m = model(modelId), k = window.ENGINE.drivingKpi(m);
    if (k) k.acknowledged = { rationale: rationale, who: m.delegate + ' (Fix)', at: META.today, rag: window.ENGINE.kst(k) };
    m.triage = { action: 'Acknowledged', rationale: rationale };
    return m;
  }
  function dismissBreach(modelId, rationale) { model(modelId).triage = { action: 'Dismissed', rationale: rationale }; return model(modelId); }
  function attributeUpstream(modelId, rationale) { model(modelId).triage = { action: 'Inherited', rationale: rationale }; return model(modelId); }

  function escalateBreach(modelId, opts) {
    var m = model(modelId), k = window.ENGINE.drivingKpi(m);
    // one root cause never fragments: a further breach on the model joins its open work item
    var existing = openTicketForModel(modelId);
    if (existing) {
      existing.eventLog.push({ at: META.today, who: m.delegate + ' (Fix)', what: 'Further breach joined this work item — ' + (k ? k.code + ' ' + window.ENGINE.kst(k) : 'exception') + '. Rationale: “' + opts.rationale + '”.' });
      m.triage = { action: 'Escalated', ref: existing.ref };
      return existing.ref;
    }
    var ref = nextRef();
    TICKETS.unshift({
      ref: ref, modelId: modelId, kpiCode: k ? k.code : null,
      title: (k ? k.code + ' ' + k.name : 'Exception') + ' — investigate & fix',
      assignee: m.developer, byWhen: window.U.addDays(META.today, 7), state: 'Open', openedAt: META.today,
      eventLog: [
        { at: m.breach ? m.breach.openedAt : META.today, who: 'System', what: 'Breach opened — ' + (k ? k.code + ' ' + window.ENGINE.kst(k) : 'exception raised') + '.' },
        { at: META.today, who: m.delegate + ' (Fix)', what: 'Triaged: severity ' + opts.severity + ', materiality ' + opts.materiality + '. Rationale: “' + opts.rationale + '”. Escalated → work item opened.' }
      ]
    });
    m.triage = { action: 'Escalated', ref: ref };
    return ref;
  }

  // ---------------- work-item mutations (one ticket, forward-only) ----------------
  function synthReading(k) { return k.dir === 'lt' ? +(k.green * 0.7).toFixed(2) : +(k.green + Math.abs(k.green - k.amber) * 0.3).toFixed(2); }
  function setConclusion(t, o) { t.category = o.category; t.conclusion = o.conclusion; t.action = o.action; t.impact = o.impact; if (o.byWhen) t.byWhen = o.byWhen; }

  function concludeInvestigation(ref, opts) {  // Investigating → Awaiting approval (a material fix needs sign-off)
    var t = ticket(ref);
    setConclusion(t, opts);
    t.state = 'Awaiting approval';
    t.eventLog.push({ at: META.today, who: t.assignee + ' (Fix)', what: 'Investigation concluded: “' + opts.conclusion + '” (impact ' + opts.impact + ', ' + opts.category + '). Fix recommended: ' + opts.action + '. Filed for approval.' });
    return t;
  }
  function fixInWindow(ref, opts) {  // Investigating → Validating: fixed in-window, the clean re-run is the sign-off
    var t = ticket(ref), m = model(t.modelId), k = kpiByCode(m, t.kpiCode) || window.ENGINE.drivingKpi(m);
    setConclusion(t, opts);
    t.validation = { kpi: k.code, before: k.latest, after: synthReading(k) };
    t.state = 'Validating';
    t.eventLog.push({ at: META.today, who: t.assignee + ' (Fix)', what: 'Fixed in-window: “' + opts.conclusion + '” — ' + opts.action + '. Validation re-run ' + k.code + ' ' + k.latest + ' → ' + t.validation.after + ' ' + k.unit + ' (green). The clean re-run is the proof.' });
    return t;
  }
  function decideTicket(ref, decision, note) {  // Awaiting approval → In progress | Won't do
    var t = ticket(ref), m = model(t.modelId), owner = m.accountableOwner + ' (Review)';
    if (decision === 'approve') {
      t.state = 'In progress';
      t.eventLog.push({ at: META.today, who: owner, what: 'Approved with audit note: “' + note + '”. Moved to In progress.' });
    } else if (decision === 'wontdo') {
      t.state = "Won't do"; t.closedAt = META.today;
      t.closureEvidence = 'Closed without a fix: “' + note + '”.';
      t.eventLog.push({ at: META.today, who: owner, what: 'Marked Won’t do: “' + note + '”.' });
      if (m.triage) delete m.triage;
    }
    return t;
  }
  function validateTicket(ref) {  // In progress → Validating
    var t = ticket(ref), m = model(t.modelId), k = kpiByCode(m, t.kpiCode) || window.ENGINE.drivingKpi(m);
    t.validation = { kpi: k.code, before: k.latest, after: synthReading(k) };
    t.state = 'Validating';
    t.eventLog.push({ at: META.today, who: t.assignee + ' (Fix)', what: 'Implemented; validation re-run executed — ' + k.code + ' ' + k.latest + ' → ' + t.validation.after + ' ' + k.unit + ' (green).' });
    return t;
  }
  function resolveTicket(ref) {  // Validating → Resolved (a clean re-run)
    var t = ticket(ref), m = model(t.modelId), k = kpiByCode(m, t.kpiCode) || window.ENGINE.drivingKpi(m);
    if (t.validation) { k.history.push(t.validation.after); k.history.shift(); k.latest = t.validation.after; k.previous = k.history[k.history.length - 2]; }
    t.state = 'Resolved'; t.closedAt = META.today;
    var rag = window.ENGINE.modelStatus(m).rag;
    t.closureEvidence = 'Post-implementation reading ' + k.code + ' = ' + k.latest + ' ' + k.unit + ' (green). Model status recomputed ' + window.U.titleCase(rag) + ' on ' + window.U.fmtD(META.today) + '.';
    t.eventLog.push({ at: META.today, who: 'System', what: 'Resolved — closure evidence attached; model status recomputed ' + window.U.titleCase(rag) + '.' });
    if (m.triage) delete m.triage;
    return t;
  }
  function addSubtask(ref, rationale) {  // failed re-run: parent parks in Validating, a subtask runs the loop
    var t = ticket(ref), sub = nextRef();
    TICKETS.unshift({
      ref: sub, parentRef: ref, modelId: t.modelId, kpiCode: t.kpiCode,
      title: 'Subtask of ' + ref + ' — ' + (t.action || 'further work'),
      assignee: t.assignee, byWhen: window.U.addDays(META.today, 7), state: 'Open', openedAt: META.today,
      eventLog: [{ at: META.today, who: t.assignee + ' (Fix)', what: 'Raised from ' + ref + ' after the re-run didn’t clear it: “' + rationale + '”.' }]
    });
    t.eventLog.push({ at: META.today, who: t.assignee + ' (Fix)', what: 'Re-run didn’t clear it — parked in Validating; subtask ' + sub + ' raised to work it (the ticket doesn’t move backward).' });
    return sub;
  }

  window.API = {
    users: users, currentUser: currentUser, setUser: setUser,
    models: models, allModels: allModels, model: model,
    tickets: tickets, ticket: ticket, ticketsForModel: ticketsForModel, subtasksOf: subtasksOf,
    openTicketForModel: openTicketForModel, isTerminal: isTerminal,
    kpiByCode: kpiByCode, signals: signals, meta: meta, owners: owners,
    nextRef: nextRef,
    acknowledgeBreach: acknowledgeBreach, dismissBreach: dismissBreach,
    attributeUpstream: attributeUpstream, escalateBreach: escalateBreach,
    concludeInvestigation: concludeInvestigation, fixInWindow: fixInWindow,
    decideTicket: decideTicket, validateTicket: validateTicket,
    resolveTicket: resolveTicket, addSubtask: addSubtask
  };
})();
