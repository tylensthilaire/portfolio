/* ============================================================
   MPMP — router, event delegation, boot (window.APP)
   Wires the shell to the views. Reads form drafts from STATE,
   calls API for every data mutation, re-renders from scratch.
   Routes mirror the sitemap URLs: /  /triage  /work  /work/{ref}
   /models  /models/{id}  /portfolio
   ============================================================ */
(function () {
  'use strict';

  var API = window.API, UI = window.UI, STATE = window.STATE, VIEWS = window.VIEWS || {};

  function $(s) { return document.querySelector(s); }

  // route → view key ('work'/'models' split on whether a param is present)
  function viewKey(r) {
    if (r.route === 'work') return r.param ? 'ticket' : 'work';
    if (r.route === 'models') return r.param ? 'model' : 'models';
    if (['triage', 'portfolio', 'home'].indexOf(r.route) >= 0) return r.route;
    return 'home';
  }

  function renderHeader(r) {
    document.querySelectorAll('.lens-btn').forEach(function (b) {
      var on = b.getAttribute('data-lens') === STATE.lens;
      b.classList.toggle('active', on);
      b.setAttribute('aria-pressed', String(on));
    });
    var us = $('#user-switch'), cu = API.currentUser();
    if (us) {
      if (!us.options.length) us.innerHTML = API.users().map(function (u) { return '<option value="' + u.id + '">' + u.name + '</option>'; }).join('');
      us.value = cu.id;
    }
    var uh = $('#user-hint');
    if (uh) uh.textContent = 'Holds ' + cu.holds.map(function (d) { return UI.LENS[d].label; }).join(' + ') + ' · ' + cu.models.length + ' models';
    var navKey = { ticket: 'work', model: 'models' }[viewKey(r)] || r.route;
    var emph = UI.LENS[STATE.lens].nav;
    document.querySelectorAll('.mainnav a').forEach(function (a) {
      var n = a.getAttribute('data-nav');
      a.classList.toggle('active', n === navKey);
      a.classList.toggle('emph', n === emph);
    });
    $('#bell').setAttribute('aria-pressed', String(!STATE.signalsDismissed));
    $('#bell-count').textContent = API.signals().length;
  }

  function renderSignals() {
    var el = $('#signals');
    if (STATE.signalsDismissed) { el.innerHTML = ''; return; }
    var U = window.U;
    el.innerHTML = '<div class="signals"><div class="signals-inner">' +
      '<span class="signals-title">Pushed to you</span>' +
      API.signals().map(function (s) {
        return '<a class="signal" href="' + U.esc(s.route) + '"><span class="ch">' + U.esc(s.channel) + '</span> ' + U.esc(s.text) + ' <span class="ago">' + U.esc(s.ago) + '</span></a>';
      }).join('') +
      '<button type="button" class="btn btn-ghost btn-sm dismiss" data-action="dismiss-signals">Dismiss</button>' +
      '</div></div>';
  }

  function placeholder(r) {
    return '<div class="wrap"><div class="card"><h1>' + window.U.titleCase(r.route) + '</h1>' +
      '<p class="muted">This surface is being built.</p></div></div>';
  }

  function render() {
    var r = UI.parseHash();
    renderHeader(r);
    renderSignals();
    var v = VIEWS[viewKey(r)];
    $('#app').innerHTML = v ? v(r) : placeholder(r);
    if (STATE._focusQ) { // keep the search field focused across the re-render
      var q = $('#filter-q');
      if (q) { q.focus(); var n = q.value.length; try { q.setSelectionRange(n, n); } catch (e) {} }
      STATE._focusQ = false;
    }
  }

  // ---------------- action handlers ----------------
  function doTriage(act, mid) {
    var rat = (STATE.drafts['rat-' + mid] || '').trim();
    if (!rat) { STATE.flash['q-' + mid] = 'A rationale is mandatory on every triage decision.'; render(); return; }
    delete STATE.flash['q-' + mid];
    if (act === 'ack') API.acknowledgeBreach(mid, rat);
    else if (act === 'esc') API.escalateBreach(mid, { severity: UI.draft('sev-' + mid, 'Medium'), materiality: UI.draft('mat-' + mid, API.model(mid).materiality), rationale: rat });
    else if (act === 'dismiss') API.dismissBreach(mid, rat);
    else if (act === 'inherit') API.attributeUpstream(mid, rat);
    STATE.open['q-' + mid] = false;
    delete STATE.drafts['rat-' + mid];
    render();
  }

  function doTicket(act, ref) {
    if (['approve', 'wontdo'].indexOf(act) >= 0) {
      var note = (STATE.drafts['note-' + ref] || '').trim();
      if (!note) { STATE.flash['tk-' + ref] = 'An audit note is mandatory on the decision.'; render(); return; }
      delete STATE.flash['tk-' + ref];
      API.decideTicket(ref, act, note);
    } else if (act === 'validate') API.validateTicket(ref);
    else if (act === 'resolve') API.resolveTicket(ref);
    else if (act === 'subtask') {
      var why = (STATE.drafts['sub-' + ref] || '').trim();
      if (!why) { STATE.flash['sub-' + ref] = 'Say what the re-run didn’t clear.'; render(); return; }
      delete STATE.flash['sub-' + ref]; delete STATE.drafts['sub-' + ref];
      API.addSubtask(ref, why);
    }
    render();
  }

  // Conclude an investigation: file for approval, or record a fixed-in-window fix (→ Validating).
  function doConclude(act, ref) {
    var conc = (STATE.drafts['conc-' + ref] || '').trim(), action = (STATE.drafts['act-' + ref] || '').trim();
    if (!conc || !action) { STATE.flash['inv-' + ref] = 'A conclusion and a recommended action are both required — the system assembles, you conclude.'; render(); return; }
    delete STATE.flash['inv-' + ref];
    var opts = {
      conclusion: conc, action: action,
      category: UI.draft('cat-' + ref, API.ticket(ref).category || 'Model'),
      impact: UI.draft('imp-' + ref, 'Medium'),
      byWhen: UI.draft('tl-' + ref, window.U.addDays(API.meta().today, 14))
    };
    if (act === 'now') API.fixInWindow(ref, opts); else API.concludeInvestigation(ref, opts);
    render();
  }

  // ---------------- events ----------------
  document.addEventListener('click', function (e) {
    var el = e.target.closest('[data-action]');
    if (!el) return;
    var a = el.getAttribute('data-action');
    if (a === 'lens') { STATE.lens = el.getAttribute('data-lens'); render(); }
    else if (a === 'toggle-signals') { STATE.signalsDismissed = !STATE.signalsDismissed; render(); }
    else if (a === 'dismiss-signals') { STATE.signalsDismissed = true; render(); }
    else if (a === 'expand') {
      var key = el.getAttribute('data-key');
      if (el.getAttribute('data-def') && STATE.open[key] === undefined) STATE.open[key] = false;
      else STATE.open[key] = !STATE.open[key];
      render();
    }
    else if (a === 'filter') { UI.setQuery(defObj(el.getAttribute('data-key'), el.getAttribute('data-val'))); }
    else if (a === 'filter-clear') { UI.setQuery({ fn: '', tier: '', rag: '', owner: '', q: '' }); }
    else if (a === 'triage') { doTriage(el.getAttribute('data-act'), el.getAttribute('data-model')); }
    else if (a === 'tk') { doTicket(el.getAttribute('data-act'), el.getAttribute('data-ref')); }
    else if (a === 'conclude') { doConclude(el.getAttribute('data-act'), el.getAttribute('data-ref')); }
    else if (a === 'pack') { var mid = el.getAttribute('data-model'); STATE.packOpen[mid] = !STATE.packOpen[mid]; render(); }
  });
  function defObj(k, v) { var o = {}; o[k] = v; return o; }

  // filter <select> (owner) fires change, not click
  document.addEventListener('change', function (e) {
    var el = e.target;
    if (el.id === 'user-switch') { API.setUser(el.value); STATE.lens = API.currentUser().duty; location.hash = '#/'; render(); return; }
    if (el.getAttribute && el.getAttribute('data-action') === 'filter') { UI.setQuery(defObj(el.getAttribute('data-key'), el.value)); return; }
    if (el.id && el.closest('[data-form]')) STATE.drafts[el.id] = el.value;
  });

  // form drafts survive re-render; live search updates the URL query
  document.addEventListener('input', function (e) {
    var el = e.target;
    if (el.id === 'filter-q') { STATE._focusQ = true; UI.setQuery({ q: el.value }); return; }
    if (el.id && el.closest('[data-form]')) STATE.drafts[el.id] = el.value;
  });

  window.addEventListener('hashchange', render);
  if (!location.hash) location.hash = '#/';
  render();

  window.APP = { render: render };
})();
