/* ============================================================
   MPMP — computation engine (window.ENGINE) + utils (window.U)
   PRODUCTION NOTE: in the real system the backstage computes and
   publishes model RAG; the API returns derivedRag + its derivation.
   Here we compute it client-side so triage/resolve recompute live
   in the demo. Keep this the ONLY place the aggregation rule lives.
   ============================================================ */
(function () {
  'use strict';

  var META = window.DATA.meta;

  // ---------------- utils (window.U) ----------------
  var U = {
    esc: function (s) {
      return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) {
        return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
      });
    },
    parseD: function (s) { return new Date(String(s).replace(' ', 'T')); },
    fmtD: function (s) {
      var d = U.parseD(s), mo = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
      return d.getDate() + ' ' + mo[d.getMonth()] + ' ' + d.getFullYear();
    },
    daysUntil: function (s) { return Math.round((U.parseD(s) - U.parseD(META.today)) / 864e5); },
    ageOf: function (s) {
      var hrs = Math.round((U.parseD(META.now) - U.parseD(s)) / 36e5);
      return hrs < 24 ? hrs + 'h' : Math.round(hrs / 24) + 'd';
    },
    addDays: function (s, n) { var d = U.parseD(s); d.setDate(d.getDate() + n); return d.toISOString().slice(0, 10); },
    pct: function (x) { return Math.round(x * 100) + '%'; },
    names: function (list) { return list.map(function (k) { return k.code; }).join(', '); },
    titleCase: function (s) { return s.charAt(0).toUpperCase() + s.slice(1); }
  };

  // ============================================================
  // STATUS ENGINE — aggregation rule "Key-KPI dominance with a
  // materiality floor" (provisional; always shown with derivation)
  //   1. any Key KPI red → model Red
  //   2. any unacknowledged Key KPI amber → model Amber
  //   3. else ≥30% of non-Key KPIs amber-or-red, or ≥15% red → Amber
  //   4. else Green — acknowledged ambers show as Acknowledged Amber
  // ============================================================
  function ragOf(k, v) {
    if (k.dir === 'lt') return v < k.green ? 'green' : v <= k.amber ? 'amber' : 'red';
    return v >= k.green ? 'green' : v >= k.amber ? 'amber' : 'red';
  }
  function kst(k, i) { var h = k.history; return ragOf(k, i == null ? h[h.length - 1] : h[i]); }
  var RRANK = { green: 0, amber: 1, red: 2 };
  // An acknowledged position is only active while it hasn't worsened beyond the
  // level it was accepted at — if it worsens, the acknowledgement lapses and the
  // KPI resurfaces into the live status (it comes back if it gets worse).
  function ackOf(m, k) {
    var a = k.acknowledged;
    if (!a) return null;
    if (a.rag && RRANK[kst(k)] > RRANK[a.rag]) return null;
    return a;
  }

  function modelStatus(m, i) {
    var key = [], nonKey = [], acked = [];
    m.kpis.forEach(function (k) {
      if (ackOf(m, k)) { acked.push(k); return; }
      (k.isKey ? key : nonKey).push(k);
    });
    var keyRed = key.filter(function (k) { return kst(k, i) === 'red'; });
    var keyAmber = key.filter(function (k) { return kst(k, i) === 'amber'; });
    var nkBad = nonKey.filter(function (k) { return kst(k, i) !== 'green'; });
    var nkRed = nonKey.filter(function (k) { return kst(k, i) === 'red'; });
    var badShare = nonKey.length ? nkBad.length / nonKey.length : 0;
    var redShare = nonKey.length ? nkRed.length / nonKey.length : 0;
    var r = { key: key, nonKey: nonKey, acked: acked, keyRed: keyRed, keyAmber: keyAmber, nkBad: nkBad, badShare: badShare, redShare: redShare, ackedOnly: false };
    if (keyRed.length) { r.rag = 'red'; r.branch = 'A key KPI is red (' + U.names(keyRed) + '), so the model is Red.'; }
    else if (keyAmber.length) { r.rag = 'amber'; r.branch = 'A key KPI is amber (' + U.names(keyAmber) + '), so the model is Amber.'; }
    else if (badShare >= 0.3 || redShare >= 0.15) { r.rag = 'amber'; r.branch = U.pct(badShare) + ' of non-key KPIs are amber-or-red (above the 30% floor), so the model is Amber.'; }
    else if (acked.some(function (k) { return kst(k, i) !== 'green'; })) { r.rag = 'amber'; r.ackedOnly = true; r.branch = 'No live key-KPI breach; ' + U.names(acked) + ' is amber but acknowledged (excluded from the rule), so it shows as Acknowledged Amber.'; }
    else { r.rag = 'green'; r.branch = 'No key-KPI breach and non-key amber-or-red share (' + U.pct(badShare) + ') is below the 30% floor, so the model is Green.'; }
    r.hasAck = acked.length > 0;
    return r;
  }

  function drivingKpi(m) {
    var s = modelStatus(m);
    return s.keyRed[0] || s.keyAmber[0] || s.nonKey.filter(function (k) { return kst(k) === 'red'; })[0] || s.nkBad[0] || s.acked[0] || null;
  }
  function ackInfo(m) {
    for (var i = 0; i < m.kpis.length; i++) {
      var a = ackOf(m, m.kpis[i]);
      if (a && kst(m.kpis[i]) !== 'green') return { kpi: m.kpis[i], ack: a };
    }
    return null;
  }
  function dispStatusAt(m, i) { var s = modelStatus(m, i); return s.ackedOnly ? 'ack' : s.rag; }
  function dispStatus(m) { return dispStatusAt(m); }

  // ---------------- runs — derived from the KPI histories ----------------
  // A run is the model as of one monthly execution. We derive 12 from the
  // 12-run histories so "runs" and the trend are the same underlying thing.
  var CAL = ['08', '09', '10', '11', '12', '01', '02', '03', '04', '05', '06', '07'];
  function runYear(i) { return i <= 4 ? 2025 : 2026; }
  function monthYear(i) { return META.months[i] + ' ' + runYear(i); }
  function runsOf(m) {
    var recent = m.runs, out = [], i, meta;
    for (i = 0; i < 12; i++) {
      meta = (i >= 12 - recent.length) ? recent[11 - i] : null; // map the 3 detailed recent runs onto the newest indices
      out.push({
        id: m.id + '-' + i, modelId: m.id, index: i,
        period: monthYear(i),
        executedAt: meta ? meta.executedAt : (runYear(i) + '-' + CAL[i] + '-15'),
        runtime: meta ? meta.runtime : recent[recent.length - 1].runtime,
        codeVersion: meta ? meta.codeVersion : recent[recent.length - 1].codeVersion,
        trigger: meta ? meta.trigger : recent[0].trigger,
        outcome: meta ? meta.status : 'Succeeded',
        aggregatedRag: modelStatus(m, i).rag
      });
    }
    return out.reverse(); // newest first
  }
  function runById(m, id) { var rs = runsOf(m); for (var i = 0; i < rs.length; i++) if (rs[i].id === id) return rs[i]; return rs[0]; }

  // ---------------- ranking: materiality × execution proximity ----------------
  var MATW = { 'Very High': 4, 'High': 3, 'Medium': 2, 'Low': 1 };
  function score(m) { var d = U.daysUntil(m.nextExecution); return MATW[m.materiality] * (d <= 7 ? (8 - d) : 1); }
  function rankDriver(m) { var d = U.daysUntil(m.nextExecution); return m.materiality + ' materiality × executes ' + (d <= 0 ? 'today' : 'in ' + d + 'd'); }

  // ---------------- collections ----------------
  function exceptions(models) {
    return models.filter(function (m) {
      if (m.triage && (m.triage.action === 'Dismissed' || m.triage.action === 'Inherited')) return false;
      var s = modelStatus(m);
      return s.rag !== 'green' && !s.ackedOnly;
    });
  }
  function acknowledgedModels(models) { return models.filter(function (m) { return modelStatus(m).ackedOnly; }); }
  function kpiDowngrades(m) {
    var rank = { green: 0, amber: 1, red: 2 };
    return m.kpis.filter(function (k) { return rank[kst(k)] > rank[ragOf(k, k.previous)]; });
  }

  // ============================================================
  // STATE MACHINES — explicit, so the UI is driven by them
  // ============================================================
  // Breach: from the moment it lands in triage to how it's disposed of.
  var BREACH_STATES = {
    untriaged:    { label: 'Untriaged',   meaning: 'Awaiting a triage decision.' },
    acknowledged: { label: 'Acknowledged', meaning: 'Real but accepted; shown everywhere; resurfaces if it worsens.' },
    escalated:    { label: 'Escalated',   meaning: 'Opened or joined the model’s work item.' },
    dismissed:    { label: 'Dismissed',   meaning: 'Not a genuine breach (a false red).' },
    inherited:    { label: 'Inherited',   meaning: 'Attributed to an upstream source; resurfaces if it persists after the source resolves.' }
  };
  function breachState(m) {
    var a = m.triage && m.triage.action;
    if (a === 'Acknowledged') return 'acknowledged';
    if (a === 'Escalated') return 'escalated';
    if (a === 'Dismissed') return 'dismissed';
    if (a === 'Inherited') return 'inherited';
    return 'untriaged';
  }

  // One work item per breach cluster, forward-only. "Investigation" and
  // "remediation" are phases of the SAME ticket, not separate records.
  // Rework never moves a ticket backward: it parks in Validating and a
  // subtask runs the loop (a clean re-run is the proof the cause was found).
  var WORK_STATES = {
    'Open':              { meaning: 'Escalated — not yet picked up.' },
    'Investigating':     { meaning: 'Assembling evidence and concluding a root cause.' },
    'Awaiting approval': { meaning: 'A fix is recommended; the owner decides.' },
    'In progress':       { meaning: 'Approved; the fix is being implemented.' },
    'Validating':        { meaning: 'A re-run is verifying the fix.' },
    'Resolved':          { meaning: 'Closed — a clean re-run confirmed the fix (re-opens if it recurs).' },
    "Won't do":          { meaning: 'Closed without a fix — declined or accepted as-is.' }
  };
  var WORK_ORDER = ['Awaiting approval', 'Open', 'Investigating', 'In progress', 'Validating', 'Resolved', "Won't do"];
  var WORK_TERMINAL = ['Resolved', "Won't do"];
  var WORK_TRANSITIONS = {
    'Open':              ['Investigating', 'Awaiting approval'],
    'Investigating':     ['Awaiting approval', 'Validating'], // Validating = fixed in-window; the re-run is the sign-off
    'Awaiting approval': ['In progress', "Won't do"],
    'In progress':       ['Validating'],
    'Validating':        ['Resolved'],                        // a failed re-run parks here + spawns a subtask
    'Resolved':          [],
    "Won't do":          []
  };

  window.U = U;
  window.ENGINE = {
    ragOf: ragOf, kst: kst, ackOf: ackOf, modelStatus: modelStatus,
    drivingKpi: drivingKpi, ackInfo: ackInfo, dispStatus: dispStatus, dispStatusAt: dispStatusAt,
    score: score, rankDriver: rankDriver, runsOf: runsOf, runById: runById, monthYear: monthYear,
    exceptions: exceptions, acknowledgedModels: acknowledgedModels, kpiDowngrades: kpiDowngrades,
    BREACH_STATES: BREACH_STATES, breachState: breachState,
    WORK_STATES: WORK_STATES, WORK_ORDER: WORK_ORDER, WORK_TERMINAL: WORK_TERMINAL, WORK_TRANSITIONS: WORK_TRANSITIONS
  };
})();
