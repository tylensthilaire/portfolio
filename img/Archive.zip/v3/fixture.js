/* ============================================================
   MPMP — fixture payload (window.DATA)
   Fabricated data. This is the shape the REST API returns in production;
   here it is a static JSON literal the browser loads directly (no build,
   no fetch). api.js is the seam over it — swap this file for fetched
   responses and the app is unchanged.
   ============================================================ */
window.DATA = {
  "meta": {
    "today": "2026-07-23",
    "now": "2026-07-23 09:00",
    "lastVisit": "2026-07-14",
    "lastVisitAgo": "9 days ago",
    "ingest": "4 min ago",
    "estateTotal": 150,
    "months": [
      "Aug",
      "Sep",
      "Oct",
      "Nov",
      "Dec",
      "Jan",
      "Feb",
      "Mar",
      "Apr",
      "May",
      "Jun",
      "Jul"
    ]
  },
  "models": [
    {
      "id": "m01",
      "name": "Macro Scenario Feed",
      "kind": "Upstream data publisher",
      "function": "Finance",
      "businessArea": "Group Economics",
      "materiality": "High",
      "riskTier": "H",
      "accountableOwner": "Sarah McAllister",
      "delegate": "Tom Ferris",
      "developer": "Ana Kovač",
      "version": "v3.2",
      "environment": "On-prem",
      "nextExecution": "2026-07-24",
      "upstream": [],
      "breach": {
        "openedAt": "2026-07-13",
        "slaDays": 5,
        "suggestedSeverity": "High",
        "classification": "Data",
        "stage": "Ingestion — vendor macro file"
      },
      "notes": "Vendor delivery on 10 Jul arrived truncated: two scenario blocks (adverse, severely adverse) missing whole variable sets.",
      "linksOut": [
        {
          "kind": "S3",
          "label": "Daily ingest check-pack (S3)"
        },
        {
          "kind": "Confluence",
          "label": "Feed runbook — vendor escalation path"
        }
      ],
      "runs": [
        {
          "executedAt": "2026-07-22 06:10",
          "runtime": "14m",
          "status": "Succeeded with warnings",
          "codeVersion": "v3.2.0",
          "trigger": "Scheduled (daily)"
        },
        {
          "executedAt": "2026-07-21 06:09",
          "runtime": "13m",
          "status": "Succeeded with warnings",
          "codeVersion": "v3.2.0",
          "trigger": "Scheduled (daily)"
        },
        {
          "executedAt": "2026-07-20 06:11",
          "runtime": "15m",
          "status": "Succeeded",
          "codeVersion": "v3.2.0",
          "trigger": "Scheduled (daily)"
        }
      ],
      "kpis": [
        {
          "code": "MSF-DQ1",
          "name": "Feed completeness",
          "isKey": true,
          "metricType": "dq",
          "unit": "%",
          "dir": "gt",
          "green": 99.5,
          "amber": 98,
          "thresholdRule": "≥ 99.5 → green; ≥ 98 → amber; else red",
          "history": [
            99.9,
            99.8,
            99.9,
            99.7,
            99.8,
            99.6,
            99.7,
            99.6,
            99.6,
            99.1,
            98.4,
            96.4
          ],
          "acknowledged": null,
          "latest": 96.4,
          "previous": 98.4,
          "group": "Data quality",
          "subGroup": "Data feed"
        },
        {
          "code": "MSF-DQ2",
          "name": "Delivery timeliness",
          "isKey": true,
          "metricType": "dq",
          "unit": "hrs late",
          "dir": "lt",
          "green": 2,
          "amber": 6,
          "thresholdRule": "< 2 → green; ≤ 6 → amber; else red",
          "history": [
            1,
            1.4,
            0.6,
            1,
            1.4,
            1,
            0.6,
            1.4,
            1,
            0.6,
            1,
            1
          ],
          "acknowledged": null,
          "latest": 1,
          "previous": 1,
          "group": "Data quality",
          "subGroup": "Data feed"
        },
        {
          "code": "MSF-DQ3",
          "name": "Schema conformance",
          "isKey": false,
          "metricType": "dq",
          "unit": "%",
          "dir": "gt",
          "green": 99,
          "amber": 97,
          "thresholdRule": "≥ 99 → green; ≥ 97 → amber; else red",
          "history": [
            99.9,
            99.95,
            99.85,
            99.9,
            99.95,
            99.9,
            99.85,
            99.95,
            99.9,
            99.85,
            99.9,
            99.9
          ],
          "acknowledged": null,
          "latest": 99.9,
          "previous": 99.9,
          "group": "Data quality",
          "subGroup": "Data feed"
        },
        {
          "code": "MSF-DQ4",
          "name": "Outlier rate",
          "isKey": false,
          "metricType": "dq",
          "unit": "%",
          "dir": "lt",
          "green": 1,
          "amber": 2.5,
          "thresholdRule": "< 1 → green; ≤ 2.5 → amber; else red",
          "history": [
            0.6,
            0.7,
            0.5,
            0.8,
            0.7,
            0.6,
            0.9,
            0.8,
            0.7,
            0.8,
            0.9,
            1.8
          ],
          "acknowledged": null,
          "latest": 1.8,
          "previous": 0.9,
          "group": "Data quality",
          "subGroup": "Data feed"
        },
        {
          "code": "MSF-DQ5",
          "name": "Scenario coverage",
          "isKey": false,
          "metricType": "dq",
          "unit": "scenarios",
          "dir": "gt",
          "green": 9,
          "amber": 7,
          "thresholdRule": "≥ 9 → green; ≥ 7 → amber; else red",
          "history": [
            12,
            12,
            12,
            12,
            12,
            12,
            12,
            12,
            12,
            12,
            12,
            12
          ],
          "acknowledged": null,
          "latest": 12,
          "previous": 12,
          "group": "Data quality",
          "subGroup": "Data feed"
        },
        {
          "code": "MSF-DQ6",
          "name": "Variable dictionary conformance",
          "isKey": false,
          "metricType": "dq",
          "unit": "%",
          "dir": "gt",
          "green": 99,
          "amber": 97,
          "thresholdRule": "≥ 99 → green; ≥ 97 → amber; else red",
          "history": [
            99.8,
            99.85,
            99.75,
            99.8,
            99.85,
            99.8,
            99.75,
            99.85,
            99.8,
            99.75,
            99.8,
            99.8
          ],
          "acknowledged": null,
          "latest": 99.8,
          "previous": 99.8,
          "group": "Data quality",
          "subGroup": "Data feed"
        }
      ],
      "modelType": "Data feed",
      "lastRun": {
        "executedAt": "2026-07-22 06:10",
        "runtime": "14m",
        "status": "Succeeded with warnings",
        "codeVersion": "v3.2.0",
        "trigger": "Scheduled (daily)"
      }
    },
    {
      "id": "m02",
      "name": "Climate Transition Plan Forecast",
      "kind": "Model",
      "function": "Finance",
      "businessArea": "Climate Hub",
      "materiality": "Medium",
      "riskTier": "M",
      "accountableOwner": "Sarah McAllister",
      "delegate": "Tom Ferris",
      "developer": "Nadia Rahman",
      "version": "v1.4",
      "environment": "SageMaker",
      "nextExecution": "2026-08-12",
      "upstream": [
        "m09"
      ],
      "breach": {
        "openedAt": "2026-07-06",
        "slaDays": 10,
        "suggestedSeverity": "Medium",
        "classification": "Data",
        "stage": "Input assembly — vendor coverage"
      },
      "notes": "Vendor climate dataset has a persistent coverage gap on Scope 3 emissions factors for mid-cap counterparties.",
      "linksOut": [
        {
          "kind": "Tableau",
          "label": "Climate pathways workbook"
        },
        {
          "kind": "Confluence",
          "label": "Vendor data-gap tracker"
        }
      ],
      "runs": [
        {
          "executedAt": "2026-07-12 21:40",
          "runtime": "1h 52m",
          "status": "Succeeded",
          "codeVersion": "v1.4.2",
          "trigger": "Scheduled (monthly)"
        },
        {
          "executedAt": "2026-06-12 21:35",
          "runtime": "1h 49m",
          "status": "Succeeded",
          "codeVersion": "v1.4.2",
          "trigger": "Scheduled (monthly)"
        },
        {
          "executedAt": "2026-05-12 21:38",
          "runtime": "1h 55m",
          "status": "Succeeded",
          "codeVersion": "v1.4.1",
          "trigger": "Scheduled (monthly)"
        }
      ],
      "kpis": [
        {
          "code": "CTP-DQ1",
          "name": "Vendor data coverage",
          "isKey": true,
          "metricType": "dq",
          "unit": "%",
          "dir": "gt",
          "green": 95,
          "amber": 88,
          "thresholdRule": "≥ 95 → green; ≥ 88 → amber; else red",
          "history": [
            96.1,
            95.8,
            95.2,
            94.9,
            94.1,
            93.6,
            93.2,
            92.8,
            92.6,
            92.5,
            92.4,
            92.1
          ],
          "acknowledged": {
            "rationale": "Climate vendor data gap — accepted, out of the team’s control",
            "who": "Tom Ferris (Fix)",
            "at": "2026-07-08",
            "rag": "amber"
          },
          "latest": 92.1,
          "previous": 92.4,
          "group": "Data quality",
          "subGroup": "Climate"
        },
        {
          "code": "CTP-PM1",
          "name": "Scenario RMSE",
          "isKey": true,
          "metricType": "perf",
          "unit": "index",
          "dir": "lt",
          "green": 0.15,
          "amber": 0.25,
          "thresholdRule": "< 0.15 → green; ≤ 0.25 → amber; else red",
          "history": [
            0.11,
            0.12,
            0.1,
            0.11,
            0.12,
            0.11,
            0.1,
            0.12,
            0.11,
            0.1,
            0.11,
            0.11
          ],
          "acknowledged": null,
          "latest": 0.11,
          "previous": 0.11,
          "group": "Performance",
          "subGroup": "Climate"
        },
        {
          "code": "CTP-PM2",
          "name": "Pathway back-test error",
          "isKey": false,
          "metricType": "perf",
          "unit": "%",
          "dir": "lt",
          "green": 8,
          "amber": 12,
          "thresholdRule": "< 8 → green; ≤ 12 → amber; else red",
          "history": [
            6.4,
            6.9,
            5.9,
            6.4,
            6.9,
            6.4,
            5.9,
            6.9,
            6.4,
            5.9,
            6.4,
            6.4
          ],
          "acknowledged": null,
          "latest": 6.4,
          "previous": 6.4,
          "group": "Performance",
          "subGroup": "Climate"
        },
        {
          "code": "CTP-DQ2",
          "name": "Emissions factor freshness",
          "isKey": false,
          "metricType": "dq",
          "unit": "days",
          "dir": "lt",
          "green": 45,
          "amber": 90,
          "thresholdRule": "< 45 → green; ≤ 90 → amber; else red",
          "history": [
            30,
            34,
            26,
            30,
            34,
            30,
            26,
            34,
            30,
            26,
            30,
            30
          ],
          "acknowledged": null,
          "latest": 30,
          "previous": 30,
          "group": "Data quality",
          "subGroup": "Climate"
        },
        {
          "code": "CTP-OP1",
          "name": "Run success rate",
          "isKey": false,
          "metricType": "ops",
          "unit": "%",
          "dir": "gt",
          "green": 98,
          "amber": 95,
          "thresholdRule": "≥ 98 → green; ≥ 95 → amber; else red",
          "history": [
            100,
            100,
            100,
            100,
            100,
            100,
            100,
            100,
            100,
            100,
            100,
            100
          ],
          "acknowledged": null,
          "latest": 100,
          "previous": 100,
          "group": "Operational",
          "subGroup": "Climate"
        }
      ],
      "modelType": "Climate",
      "lastRun": {
        "executedAt": "2026-07-12 21:40",
        "runtime": "1h 52m",
        "status": "Succeeded",
        "codeVersion": "v1.4.2",
        "trigger": "Scheduled (monthly)"
      }
    },
    {
      "id": "m03",
      "name": "Retail PD Model",
      "kind": "Model",
      "function": "Finance",
      "businessArea": "Retail Credit Risk",
      "materiality": "Very High",
      "riskTier": "VH",
      "accountableOwner": "James Okonkwo",
      "delegate": "Meera Shah",
      "developer": "Callum Reid",
      "version": "v5.1",
      "environment": "SageMaker",
      "nextExecution": "2026-08-03",
      "upstream": [],
      "linksOut": [
        {
          "kind": "Tableau",
          "label": "PD monitoring workbook"
        },
        {
          "kind": "S3",
          "label": "Monthly check-pack (S3)"
        }
      ],
      "runs": [
        {
          "executedAt": "2026-07-03 02:15",
          "runtime": "38m",
          "status": "Succeeded",
          "codeVersion": "v5.1.3",
          "trigger": "Scheduled (monthly)"
        },
        {
          "executedAt": "2026-06-03 02:14",
          "runtime": "37m",
          "status": "Succeeded",
          "codeVersion": "v5.1.3",
          "trigger": "Scheduled (monthly)"
        },
        {
          "executedAt": "2026-05-28 11:02",
          "runtime": "39m",
          "status": "Succeeded",
          "codeVersion": "v5.1.3",
          "trigger": "Manual (post-recalibration validation)"
        }
      ],
      "kpis": [
        {
          "code": "RPD-PM1",
          "name": "Gini coefficient",
          "isKey": true,
          "metricType": "perf",
          "unit": "ratio",
          "dir": "gt",
          "green": 0.55,
          "amber": 0.48,
          "thresholdRule": "≥ 0.55 → green; ≥ 0.48 → amber; else red",
          "history": [
            0.62,
            0.63,
            0.61,
            0.62,
            0.63,
            0.62,
            0.61,
            0.63,
            0.62,
            0.61,
            0.62,
            0.62
          ],
          "acknowledged": null,
          "latest": 0.62,
          "previous": 0.62,
          "group": "Performance",
          "subGroup": "PD"
        },
        {
          "code": "RPD-PM2",
          "name": "Population stability index",
          "isKey": true,
          "metricType": "perf",
          "unit": "index",
          "dir": "lt",
          "green": 0.1,
          "amber": 0.25,
          "thresholdRule": "< 0.1 → green; ≤ 0.25 → amber; else red",
          "history": [
            0.06,
            0.07,
            0.09,
            0.12,
            0.18,
            0.27,
            0.24,
            0.11,
            0.07,
            0.06,
            0.06,
            0.06
          ],
          "acknowledged": null,
          "latest": 0.06,
          "previous": 0.06,
          "group": "Performance",
          "subGroup": "PD"
        },
        {
          "code": "RPD-CAL1",
          "name": "Calibration error",
          "isKey": false,
          "metricType": "perf",
          "unit": "%",
          "dir": "lt",
          "green": 5,
          "amber": 10,
          "thresholdRule": "< 5 → green; ≤ 10 → amber; else red",
          "history": [
            3.1,
            3.4,
            2.8,
            3.1,
            3.4,
            3.1,
            2.8,
            3.4,
            3.1,
            2.8,
            3.1,
            3.1
          ],
          "acknowledged": null,
          "latest": 3.1,
          "previous": 3.1,
          "group": "Performance",
          "subGroup": "PD"
        },
        {
          "code": "RPD-DQ1",
          "name": "Missing-field rate",
          "isKey": false,
          "metricType": "dq",
          "unit": "%",
          "dir": "lt",
          "green": 2,
          "amber": 5,
          "thresholdRule": "< 2 → green; ≤ 5 → amber; else red",
          "history": [
            1.4,
            1.6,
            1.5,
            1.8,
            1.7,
            1.9,
            2.1,
            2.2,
            2.4,
            2.3,
            2.5,
            2.6
          ],
          "acknowledged": null,
          "latest": 2.6,
          "previous": 2.5,
          "group": "Data quality",
          "subGroup": "PD"
        },
        {
          "code": "RPD-DQ2",
          "name": "Bureau feed completeness",
          "isKey": false,
          "metricType": "dq",
          "unit": "%",
          "dir": "gt",
          "green": 99,
          "amber": 97,
          "thresholdRule": "≥ 99 → green; ≥ 97 → amber; else red",
          "history": [
            99.7,
            99.8,
            99.6,
            99.7,
            99.8,
            99.7,
            99.6,
            99.8,
            99.7,
            99.6,
            99.7,
            99.7
          ],
          "acknowledged": null,
          "latest": 99.7,
          "previous": 99.7,
          "group": "Data quality",
          "subGroup": "PD"
        },
        {
          "code": "RPD-OP1",
          "name": "Run success rate",
          "isKey": false,
          "metricType": "ops",
          "unit": "%",
          "dir": "gt",
          "green": 98,
          "amber": 95,
          "thresholdRule": "≥ 98 → green; ≥ 95 → amber; else red",
          "history": [
            100,
            100,
            100,
            100,
            100,
            100,
            100,
            100,
            100,
            100,
            100,
            100
          ],
          "acknowledged": null,
          "latest": 100,
          "previous": 100,
          "group": "Operational",
          "subGroup": "PD"
        }
      ],
      "modelType": "PD",
      "lastRun": {
        "executedAt": "2026-07-03 02:15",
        "runtime": "38m",
        "status": "Succeeded",
        "codeVersion": "v5.1.3",
        "trigger": "Scheduled (monthly)"
      }
    },
    {
      "id": "m04",
      "name": "IFRS9 Impairment Engine",
      "kind": "Model",
      "function": "Finance",
      "businessArea": "Finance — Impairment",
      "materiality": "Very High",
      "riskTier": "VH",
      "accountableOwner": "Sarah McAllister",
      "delegate": "Tom Ferris",
      "developer": "Ana Kovač",
      "version": "v4.0",
      "environment": "On-prem",
      "nextExecution": "2026-07-27",
      "upstream": [
        "m01",
        "m03"
      ],
      "symptomOf": "m01",
      "breach": {
        "openedAt": "2026-07-14",
        "slaDays": 10,
        "suggestedSeverity": "Medium",
        "classification": "Data (inherited)",
        "stage": "Input assembly — macro scenarios"
      },
      "linksOut": [
        {
          "kind": "Tableau",
          "label": "ECL movement workbook"
        },
        {
          "kind": "Confluence",
          "label": "Impairment run governance page"
        }
      ],
      "runs": [
        {
          "executedAt": "2026-07-14 23:05",
          "runtime": "3h 41m",
          "status": "Succeeded with warnings",
          "codeVersion": "v4.0.1",
          "trigger": "Scheduled (monthly)"
        },
        {
          "executedAt": "2026-06-14 23:02",
          "runtime": "3h 38m",
          "status": "Succeeded",
          "codeVersion": "v4.0.1",
          "trigger": "Scheduled (monthly)"
        },
        {
          "executedAt": "2026-05-14 23:04",
          "runtime": "3h 44m",
          "status": "Succeeded",
          "codeVersion": "v4.0.0",
          "trigger": "Scheduled (monthly)"
        }
      ],
      "kpis": [
        {
          "code": "IFRS-DQ1",
          "name": "Macro input completeness",
          "isKey": true,
          "metricType": "dq",
          "unit": "%",
          "dir": "gt",
          "green": 99,
          "amber": 95,
          "thresholdRule": "≥ 99 → green; ≥ 95 → amber; else red",
          "history": [
            99.8,
            99.7,
            99.8,
            99.6,
            99.7,
            99.5,
            99.6,
            99.4,
            99.5,
            99.3,
            99.2,
            95.8
          ],
          "acknowledged": null,
          "latest": 95.8,
          "previous": 99.2,
          "group": "Data quality",
          "subGroup": "Impairment"
        },
        {
          "code": "IFRS-PM1",
          "name": "ECL coverage variance",
          "isKey": true,
          "metricType": "perf",
          "unit": "%",
          "dir": "lt",
          "green": 5,
          "amber": 9,
          "thresholdRule": "< 5 → green; ≤ 9 → amber; else red",
          "history": [
            4.2,
            4.5,
            3.9,
            4.2,
            4.5,
            4.2,
            3.9,
            4.5,
            4.2,
            3.9,
            4.2,
            4.2
          ],
          "acknowledged": null,
          "latest": 4.2,
          "previous": 4.2,
          "group": "Performance",
          "subGroup": "Impairment"
        },
        {
          "code": "IFRS-PM2",
          "name": "Stage-2 migration stability",
          "isKey": false,
          "metricType": "perf",
          "unit": "index",
          "dir": "lt",
          "green": 0.12,
          "amber": 0.2,
          "thresholdRule": "< 0.12 → green; ≤ 0.2 → amber; else red",
          "history": [
            0.09,
            0.1,
            0.08,
            0.09,
            0.1,
            0.09,
            0.08,
            0.1,
            0.09,
            0.08,
            0.09,
            0.09
          ],
          "acknowledged": null,
          "latest": 0.09,
          "previous": 0.09,
          "group": "Performance",
          "subGroup": "Impairment"
        },
        {
          "code": "IFRS-DQ2",
          "name": "Account reconciliation breaks",
          "isKey": false,
          "metricType": "dq",
          "unit": "accounts",
          "dir": "lt",
          "green": 50,
          "amber": 200,
          "thresholdRule": "< 50 → green; ≤ 200 → amber; else red",
          "history": [
            12,
            16,
            8,
            12,
            16,
            12,
            8,
            16,
            12,
            8,
            12,
            12
          ],
          "acknowledged": null,
          "latest": 12,
          "previous": 12,
          "group": "Data quality",
          "subGroup": "Impairment"
        },
        {
          "code": "IFRS-OP1",
          "name": "Runtime vs baseline",
          "isKey": false,
          "metricType": "ops",
          "unit": "%",
          "dir": "lt",
          "green": 120,
          "amber": 150,
          "thresholdRule": "< 120 → green; ≤ 150 → amber; else red",
          "history": [
            104,
            107,
            101,
            104,
            107,
            104,
            101,
            107,
            104,
            101,
            104,
            104
          ],
          "acknowledged": null,
          "latest": 104,
          "previous": 104,
          "group": "Operational",
          "subGroup": "Impairment"
        },
        {
          "code": "IFRS-PM3",
          "name": "Overlay proportion of ECL",
          "isKey": false,
          "metricType": "perf",
          "unit": "%",
          "dir": "lt",
          "green": 10,
          "amber": 18,
          "thresholdRule": "< 10 → green; ≤ 18 → amber; else red",
          "history": [
            8.9,
            9.3,
            8.5,
            8.9,
            9.3,
            8.9,
            8.5,
            9.3,
            8.9,
            8.5,
            8.9,
            8.9
          ],
          "acknowledged": null,
          "latest": 8.9,
          "previous": 8.9,
          "group": "Performance",
          "subGroup": "Impairment"
        }
      ],
      "modelType": "Impairment",
      "lastRun": {
        "executedAt": "2026-07-14 23:05",
        "runtime": "3h 41m",
        "status": "Succeeded with warnings",
        "codeVersion": "v4.0.1",
        "trigger": "Scheduled (monthly)"
      }
    },
    {
      "id": "m05",
      "name": "Wholesale LGD Model",
      "kind": "Model",
      "function": "Finance",
      "businessArea": "Commercial Credit Risk",
      "materiality": "High",
      "riskTier": "H",
      "accountableOwner": "James Okonkwo",
      "delegate": "Meera Shah",
      "developer": "Callum Reid",
      "version": "v2.7",
      "environment": "On-prem",
      "nextExecution": "2026-08-10",
      "upstream": [],
      "linksOut": [
        {
          "kind": "Tableau",
          "label": "LGD back-testing workbook"
        }
      ],
      "runs": [
        {
          "executedAt": "2026-07-10 03:30",
          "runtime": "52m",
          "status": "Succeeded",
          "codeVersion": "v2.7.0",
          "trigger": "Scheduled (monthly)"
        },
        {
          "executedAt": "2026-06-10 03:28",
          "runtime": "51m",
          "status": "Succeeded",
          "codeVersion": "v2.7.0",
          "trigger": "Scheduled (monthly)"
        },
        {
          "executedAt": "2026-05-10 03:31",
          "runtime": "54m",
          "status": "Succeeded",
          "codeVersion": "v2.7.0",
          "trigger": "Scheduled (monthly)"
        }
      ],
      "kpis": [
        {
          "code": "WLG-PM1",
          "name": "LGD back-test error",
          "isKey": true,
          "metricType": "perf",
          "unit": "%",
          "dir": "lt",
          "green": 6,
          "amber": 10,
          "thresholdRule": "< 6 → green; ≤ 10 → amber; else red",
          "history": [
            4.8,
            5.1,
            4.5,
            4.8,
            5.1,
            4.8,
            4.5,
            5.1,
            4.8,
            4.5,
            4.8,
            4.8
          ],
          "acknowledged": null,
          "latest": 4.8,
          "previous": 4.8,
          "group": "Performance",
          "subGroup": "LGD"
        },
        {
          "code": "WLG-PM2",
          "name": "Rank ordering (Somers’ D)",
          "isKey": true,
          "metricType": "perf",
          "unit": "ratio",
          "dir": "gt",
          "green": 0.5,
          "amber": 0.4,
          "thresholdRule": "≥ 0.5 → green; ≥ 0.4 → amber; else red",
          "history": [
            0.57,
            0.58,
            0.56,
            0.57,
            0.58,
            0.57,
            0.56,
            0.58,
            0.57,
            0.56,
            0.57,
            0.57
          ],
          "acknowledged": null,
          "latest": 0.57,
          "previous": 0.57,
          "group": "Performance",
          "subGroup": "LGD"
        },
        {
          "code": "WLG-DQ1",
          "name": "Collateral data completeness",
          "isKey": false,
          "metricType": "dq",
          "unit": "%",
          "dir": "gt",
          "green": 97,
          "amber": 94,
          "thresholdRule": "≥ 97 → green; ≥ 94 → amber; else red",
          "history": [
            98.8,
            99,
            98.6,
            98.8,
            99,
            98.8,
            98.6,
            99,
            98.8,
            98.6,
            98.8,
            98.8
          ],
          "acknowledged": null,
          "latest": 98.8,
          "previous": 98.8,
          "group": "Data quality",
          "subGroup": "LGD"
        },
        {
          "code": "WLG-PM3",
          "name": "Downturn floor headroom",
          "isKey": false,
          "metricType": "perf",
          "unit": "%",
          "dir": "gt",
          "green": 5,
          "amber": 2,
          "thresholdRule": "≥ 5 → green; ≥ 2 → amber; else red",
          "history": [
            7.2,
            7,
            6.8,
            6.9,
            6.6,
            6.4,
            6.1,
            5.8,
            4.9,
            6.8,
            7.1,
            7.5
          ],
          "acknowledged": null,
          "latest": 7.5,
          "previous": 7.1,
          "group": "Performance",
          "subGroup": "LGD"
        },
        {
          "code": "WLG-OP1",
          "name": "Run success rate",
          "isKey": false,
          "metricType": "ops",
          "unit": "%",
          "dir": "gt",
          "green": 98,
          "amber": 95,
          "thresholdRule": "≥ 98 → green; ≥ 95 → amber; else red",
          "history": [
            100,
            100,
            100,
            100,
            100,
            100,
            100,
            100,
            100,
            100,
            100,
            100
          ],
          "acknowledged": null,
          "latest": 100,
          "previous": 100,
          "group": "Operational",
          "subGroup": "LGD"
        }
      ],
      "modelType": "LGD",
      "lastRun": {
        "executedAt": "2026-07-10 03:30",
        "runtime": "52m",
        "status": "Succeeded",
        "codeVersion": "v2.7.0",
        "trigger": "Scheduled (monthly)"
      }
    },
    {
      "id": "m06",
      "name": "Behavioural Deposit Model",
      "kind": "Model",
      "function": "Treasury",
      "businessArea": "Treasury ALM",
      "materiality": "High",
      "riskTier": "H",
      "accountableOwner": "Fiona Drummond",
      "delegate": "David Lam",
      "developer": "Priya Nair",
      "version": "v2.5",
      "environment": "SageMaker",
      "nextExecution": "2026-07-29",
      "upstream": [],
      "breach": {
        "openedAt": "2026-07-11",
        "slaDays": 10,
        "suggestedSeverity": "High",
        "classification": "Model",
        "stage": "Scoring — population drift"
      },
      "notes": "Instant-access segment behaviour shifted after the June rate change; PSI climb is sustained across six runs — drift, not blip.",
      "linksOut": [
        {
          "kind": "Tableau",
          "label": "Deposit behaviour workbook"
        },
        {
          "kind": "S3",
          "label": "Monthly check-pack (S3)"
        },
        {
          "kind": "Confluence",
          "label": "Local monitoring runbook"
        }
      ],
      "runs": [
        {
          "executedAt": "2026-07-10 04:20",
          "runtime": "47m",
          "status": "Succeeded",
          "codeVersion": "v2.5.0",
          "trigger": "Scheduled (monthly)"
        },
        {
          "executedAt": "2026-06-10 04:19",
          "runtime": "46m",
          "status": "Succeeded",
          "codeVersion": "v2.5.0",
          "trigger": "Scheduled (monthly)"
        },
        {
          "executedAt": "2026-05-10 04:22",
          "runtime": "48m",
          "status": "Succeeded",
          "codeVersion": "v2.5.0",
          "trigger": "Scheduled (monthly)"
        }
      ],
      "kpis": [
        {
          "code": "BDM-PM1",
          "name": "Population stability index",
          "isKey": true,
          "metricType": "perf",
          "unit": "index",
          "dir": "lt",
          "green": 0.1,
          "amber": 0.25,
          "thresholdRule": "< 0.1 → green; ≤ 0.25 → amber; else red",
          "history": [
            0.05,
            0.06,
            0.07,
            0.08,
            0.09,
            0.11,
            0.13,
            0.15,
            0.17,
            0.19,
            0.22,
            0.31
          ],
          "acknowledged": null,
          "latest": 0.31,
          "previous": 0.22,
          "group": "Performance",
          "subGroup": "Behavioural"
        },
        {
          "code": "BDM-PM2",
          "name": "Decay-rate back-test error",
          "isKey": true,
          "metricType": "perf",
          "unit": "%",
          "dir": "lt",
          "green": 5,
          "amber": 8,
          "thresholdRule": "< 5 → green; ≤ 8 → amber; else red",
          "history": [
            4.1,
            4.4,
            3.8,
            4.1,
            4.4,
            4.1,
            3.8,
            4.4,
            4.1,
            3.8,
            4.1,
            4.1
          ],
          "acknowledged": null,
          "latest": 4.1,
          "previous": 4.1,
          "group": "Performance",
          "subGroup": "Behavioural"
        },
        {
          "code": "BDM-DQ1",
          "name": "Balance reconciliation breaks",
          "isKey": false,
          "metricType": "dq",
          "unit": "accounts",
          "dir": "lt",
          "green": 20,
          "amber": 80,
          "thresholdRule": "< 20 → green; ≤ 80 → amber; else red",
          "history": [
            18,
            22,
            25,
            28,
            24,
            30,
            26,
            32,
            29,
            31,
            33,
            34
          ],
          "acknowledged": null,
          "latest": 34,
          "previous": 33,
          "group": "Data quality",
          "subGroup": "Behavioural"
        },
        {
          "code": "BDM-PM3",
          "name": "Segment coverage",
          "isKey": false,
          "metricType": "perf",
          "unit": "%",
          "dir": "gt",
          "green": 95,
          "amber": 90,
          "thresholdRule": "≥ 95 → green; ≥ 90 → amber; else red",
          "history": [
            99,
            99.3,
            98.7,
            99,
            99.3,
            99,
            98.7,
            99.3,
            99,
            98.7,
            99,
            99
          ],
          "acknowledged": null,
          "latest": 99,
          "previous": 99,
          "group": "Performance",
          "subGroup": "Behavioural"
        },
        {
          "code": "BDM-OP1",
          "name": "Run success rate",
          "isKey": false,
          "metricType": "ops",
          "unit": "%",
          "dir": "gt",
          "green": 98,
          "amber": 95,
          "thresholdRule": "≥ 98 → green; ≥ 95 → amber; else red",
          "history": [
            100,
            100,
            100,
            100,
            100,
            100,
            100,
            100,
            100,
            100,
            100,
            100
          ],
          "acknowledged": null,
          "latest": 100,
          "previous": 100,
          "group": "Operational",
          "subGroup": "Behavioural"
        },
        {
          "code": "BDM-DQ2",
          "name": "Source feed timeliness",
          "isKey": false,
          "metricType": "dq",
          "unit": "hrs",
          "dir": "lt",
          "green": 4,
          "amber": 12,
          "thresholdRule": "< 4 → green; ≤ 12 → amber; else red",
          "history": [
            2,
            2.5,
            1.5,
            2,
            2.5,
            2,
            1.5,
            2.5,
            2,
            1.5,
            2,
            2
          ],
          "acknowledged": null,
          "latest": 2,
          "previous": 2,
          "group": "Data quality",
          "subGroup": "Behavioural"
        }
      ],
      "modelType": "Behavioural",
      "lastRun": {
        "executedAt": "2026-07-10 04:20",
        "runtime": "47m",
        "status": "Succeeded",
        "codeVersion": "v2.5.0",
        "trigger": "Scheduled (monthly)"
      }
    },
    {
      "id": "m07",
      "name": "Capital Forecast Model",
      "kind": "Model",
      "function": "Finance",
      "businessArea": "Capital Management",
      "materiality": "Very High",
      "riskTier": "VH",
      "accountableOwner": "Sarah McAllister",
      "delegate": "Tom Ferris",
      "developer": "Ana Kovač",
      "version": "v1.9",
      "environment": "Excel",
      "nextExecution": "2026-08-05",
      "upstream": [
        "m04"
      ],
      "symptomOf": "m01",
      "breach": {
        "openedAt": "2026-07-15",
        "slaDays": 10,
        "suggestedSeverity": "Medium",
        "classification": "Data (inherited)",
        "stage": "Input freshness"
      },
      "linksOut": [
        {
          "kind": "Confluence",
          "label": "Capital plan assumptions log"
        }
      ],
      "runs": [
        {
          "executedAt": "2026-07-15 17:50",
          "runtime": "22m",
          "status": "Succeeded",
          "codeVersion": "v1.9.4",
          "trigger": "Scheduled (monthly)"
        },
        {
          "executedAt": "2026-06-15 17:45",
          "runtime": "21m",
          "status": "Succeeded",
          "codeVersion": "v1.9.4",
          "trigger": "Scheduled (monthly)"
        },
        {
          "executedAt": "2026-05-15 17:52",
          "runtime": "23m",
          "status": "Succeeded",
          "codeVersion": "v1.9.3",
          "trigger": "Scheduled (monthly)"
        }
      ],
      "kpis": [
        {
          "code": "CFM-DQ1",
          "name": "Upstream input freshness",
          "isKey": true,
          "metricType": "dq",
          "unit": "days stale",
          "dir": "lt",
          "green": 2,
          "amber": 5,
          "thresholdRule": "< 2 → green; ≤ 5 → amber; else red",
          "history": [
            1,
            1,
            2,
            1,
            1,
            2,
            1,
            1,
            2,
            1,
            1,
            4
          ],
          "acknowledged": null,
          "latest": 4,
          "previous": 1,
          "group": "Data quality",
          "subGroup": "Capital"
        },
        {
          "code": "CFM-PM1",
          "name": "Forecast back-test error",
          "isKey": true,
          "metricType": "perf",
          "unit": "%",
          "dir": "lt",
          "green": 8,
          "amber": 15,
          "thresholdRule": "< 8 → green; ≤ 15 → amber; else red",
          "history": [
            6.2,
            6.6,
            5.8,
            6.2,
            6.6,
            6.2,
            5.8,
            6.6,
            6.2,
            5.8,
            6.2,
            6.2
          ],
          "acknowledged": null,
          "latest": 6.2,
          "previous": 6.2,
          "group": "Performance",
          "subGroup": "Capital"
        },
        {
          "code": "CFM-DQ2",
          "name": "Input reconciliation breaks",
          "isKey": false,
          "metricType": "dq",
          "unit": "lines",
          "dir": "lt",
          "green": 10,
          "amber": 40,
          "thresholdRule": "< 10 → green; ≤ 40 → amber; else red",
          "history": [
            3,
            4,
            2,
            3,
            4,
            3,
            2,
            4,
            3,
            2,
            3,
            3
          ],
          "acknowledged": null,
          "latest": 3,
          "previous": 3,
          "group": "Data quality",
          "subGroup": "Capital"
        },
        {
          "code": "CFM-PM2",
          "name": "Buffer headroom sensitivity",
          "isKey": false,
          "metricType": "perf",
          "unit": "%",
          "dir": "lt",
          "green": 25,
          "amber": 40,
          "thresholdRule": "< 25 → green; ≤ 40 → amber; else red",
          "history": [
            18,
            19,
            17,
            18,
            19,
            18,
            17,
            19,
            18,
            17,
            18,
            18
          ],
          "acknowledged": null,
          "latest": 18,
          "previous": 18,
          "group": "Performance",
          "subGroup": "Capital"
        },
        {
          "code": "CFM-OP1",
          "name": "Workbook control checks passed",
          "isKey": false,
          "metricType": "ops",
          "unit": "%",
          "dir": "gt",
          "green": 99,
          "amber": 95,
          "thresholdRule": "≥ 99 → green; ≥ 95 → amber; else red",
          "history": [
            100,
            100,
            100,
            100,
            100,
            100,
            100,
            100,
            100,
            100,
            100,
            100
          ],
          "acknowledged": null,
          "latest": 100,
          "previous": 100,
          "group": "Operational",
          "subGroup": "Capital"
        }
      ],
      "modelType": "Capital",
      "lastRun": {
        "executedAt": "2026-07-15 17:50",
        "runtime": "22m",
        "status": "Succeeded",
        "codeVersion": "v1.9.4",
        "trigger": "Scheduled (monthly)"
      }
    },
    {
      "id": "m08",
      "name": "Liquidity Stress Overlay",
      "kind": "Model",
      "function": "Treasury",
      "businessArea": "Liquidity Risk",
      "materiality": "Very High",
      "riskTier": "VH",
      "accountableOwner": "Fiona Drummond",
      "delegate": "David Lam",
      "developer": "Priya Nair",
      "version": "v3.0",
      "environment": "On-prem",
      "nextExecution": "2026-07-25",
      "upstream": [],
      "breach": {
        "openedAt": "2026-07-23 07:02",
        "slaDays": 5,
        "suggestedSeverity": "High",
        "classification": "Model",
        "stage": "Stress assumptions — outflow calibration"
      },
      "notes": "Fresh breach this morning: LCR back-test variance jumped 2.6 → 4.8 on the overnight run.",
      "linksOut": [
        {
          "kind": "Tableau",
          "label": "Liquidity stress workbook"
        },
        {
          "kind": "S3",
          "label": "Overnight check-pack (S3)"
        }
      ],
      "runs": [
        {
          "executedAt": "2026-07-23 05:55",
          "runtime": "1h 05m",
          "status": "Succeeded",
          "codeVersion": "v3.0.2",
          "trigger": "Scheduled (weekly)"
        },
        {
          "executedAt": "2026-07-16 05:52",
          "runtime": "1h 03m",
          "status": "Succeeded",
          "codeVersion": "v3.0.2",
          "trigger": "Scheduled (weekly)"
        },
        {
          "executedAt": "2026-07-09 05:58",
          "runtime": "1h 07m",
          "status": "Succeeded",
          "codeVersion": "v3.0.2",
          "trigger": "Scheduled (weekly)"
        }
      ],
      "kpis": [
        {
          "code": "LSO-PM1",
          "name": "LCR back-test variance",
          "isKey": true,
          "metricType": "perf",
          "unit": "%",
          "dir": "lt",
          "green": 3,
          "amber": 6,
          "thresholdRule": "< 3 → green; ≤ 6 → amber; else red",
          "history": [
            1.8,
            2.1,
            1.9,
            2.4,
            2.2,
            2.5,
            2.3,
            2.6,
            2.4,
            2.5,
            2.6,
            4.8
          ],
          "acknowledged": null,
          "latest": 4.8,
          "previous": 2.6,
          "group": "Performance",
          "subGroup": "Liquidity"
        },
        {
          "code": "LSO-PM2",
          "name": "Outflow assumption error",
          "isKey": true,
          "metricType": "perf",
          "unit": "%",
          "dir": "lt",
          "green": 5,
          "amber": 9,
          "thresholdRule": "< 5 → green; ≤ 9 → amber; else red",
          "history": [
            3.9,
            4.2,
            3.6,
            3.9,
            4.2,
            3.9,
            3.6,
            4.2,
            3.9,
            3.6,
            3.9,
            3.9
          ],
          "acknowledged": null,
          "latest": 3.9,
          "previous": 3.9,
          "group": "Performance",
          "subGroup": "Liquidity"
        },
        {
          "code": "LSO-DQ1",
          "name": "Position feed completeness",
          "isKey": false,
          "metricType": "dq",
          "unit": "%",
          "dir": "gt",
          "green": 99,
          "amber": 97,
          "thresholdRule": "≥ 99 → green; ≥ 97 → amber; else red",
          "history": [
            99.9,
            99.95,
            99.85,
            99.9,
            99.95,
            99.9,
            99.85,
            99.95,
            99.9,
            99.85,
            99.9,
            99.9
          ],
          "acknowledged": null,
          "latest": 99.9,
          "previous": 99.9,
          "group": "Data quality",
          "subGroup": "Liquidity"
        },
        {
          "code": "LSO-PM3",
          "name": "Survival horizon headroom",
          "isKey": false,
          "metricType": "perf",
          "unit": "days",
          "dir": "gt",
          "green": 10,
          "amber": 5,
          "thresholdRule": "≥ 10 → green; ≥ 5 → amber; else red",
          "history": [
            16,
            17,
            15,
            16,
            17,
            16,
            15,
            17,
            16,
            15,
            16,
            16
          ],
          "acknowledged": null,
          "latest": 16,
          "previous": 16,
          "group": "Performance",
          "subGroup": "Liquidity"
        },
        {
          "code": "LSO-OP1",
          "name": "Run success rate",
          "isKey": false,
          "metricType": "ops",
          "unit": "%",
          "dir": "gt",
          "green": 98,
          "amber": 95,
          "thresholdRule": "≥ 98 → green; ≥ 95 → amber; else red",
          "history": [
            100,
            100,
            100,
            100,
            100,
            100,
            100,
            100,
            100,
            100,
            100,
            100
          ],
          "acknowledged": null,
          "latest": 100,
          "previous": 100,
          "group": "Operational",
          "subGroup": "Liquidity"
        }
      ],
      "modelType": "Liquidity",
      "lastRun": {
        "executedAt": "2026-07-23 05:55",
        "runtime": "1h 05m",
        "status": "Succeeded",
        "codeVersion": "v3.0.2",
        "trigger": "Scheduled (weekly)"
      }
    },
    {
      "id": "m09",
      "name": "Climate Vendor Data Feed",
      "kind": "Upstream data publisher",
      "function": "Finance",
      "businessArea": "Climate Hub",
      "materiality": "Low",
      "riskTier": "L",
      "accountableOwner": "Elena Marchetti",
      "delegate": "Chris Duffy",
      "developer": "Nadia Rahman",
      "version": "v2.2",
      "environment": "On-prem",
      "nextExecution": "2026-07-26",
      "upstream": [],
      "notes": "Vendor coverage on Scope 3 factors remains below target — known gap, tracked with the vendor; downstream m02 carries the acknowledged amber.",
      "linksOut": [
        {
          "kind": "S3",
          "label": "Vendor file drop audit (S3)"
        }
      ],
      "runs": [
        {
          "executedAt": "2026-07-19 07:15",
          "runtime": "9m",
          "status": "Succeeded",
          "codeVersion": "v2.2.1",
          "trigger": "Scheduled (weekly)"
        },
        {
          "executedAt": "2026-07-12 07:14",
          "runtime": "9m",
          "status": "Succeeded",
          "codeVersion": "v2.2.1",
          "trigger": "Scheduled (weekly)"
        },
        {
          "executedAt": "2026-07-05 07:16",
          "runtime": "10m",
          "status": "Succeeded",
          "codeVersion": "v2.2.1",
          "trigger": "Scheduled (weekly)"
        }
      ],
      "kpis": [
        {
          "code": "CVF-DQ1",
          "name": "File delivery success",
          "isKey": true,
          "metricType": "dq",
          "unit": "%",
          "dir": "gt",
          "green": 99,
          "amber": 97,
          "thresholdRule": "≥ 99 → green; ≥ 97 → amber; else red",
          "history": [
            100,
            100,
            100,
            100,
            100,
            100,
            100,
            100,
            100,
            100,
            100,
            100
          ],
          "acknowledged": null,
          "latest": 100,
          "previous": 100,
          "group": "Data quality",
          "subGroup": "Data feed"
        },
        {
          "code": "CVF-DQ2",
          "name": "Field coverage",
          "isKey": false,
          "metricType": "dq",
          "unit": "%",
          "dir": "gt",
          "green": 92,
          "amber": 85,
          "thresholdRule": "≥ 92 → green; ≥ 85 → amber; else red",
          "history": [
            93.5,
            93.1,
            92.8,
            92.4,
            91.9,
            91.2,
            90.6,
            90.1,
            89.8,
            89.4,
            89.1,
            88.9
          ],
          "acknowledged": null,
          "latest": 88.9,
          "previous": 89.1,
          "group": "Data quality",
          "subGroup": "Data feed"
        },
        {
          "code": "CVF-DQ3",
          "name": "Schema conformance",
          "isKey": false,
          "metricType": "dq",
          "unit": "%",
          "dir": "gt",
          "green": 99,
          "amber": 97,
          "thresholdRule": "≥ 99 → green; ≥ 97 → amber; else red",
          "history": [
            100,
            100,
            100,
            100,
            100,
            100,
            100,
            100,
            100,
            100,
            100,
            100
          ],
          "acknowledged": null,
          "latest": 100,
          "previous": 100,
          "group": "Data quality",
          "subGroup": "Data feed"
        },
        {
          "code": "CVF-DQ4",
          "name": "Delivery timeliness",
          "isKey": false,
          "metricType": "dq",
          "unit": "hrs",
          "dir": "lt",
          "green": 24,
          "amber": 48,
          "thresholdRule": "< 24 → green; ≤ 48 → amber; else red",
          "history": [
            6,
            8,
            4,
            6,
            8,
            6,
            4,
            8,
            6,
            4,
            6,
            6
          ],
          "acknowledged": null,
          "latest": 6,
          "previous": 6,
          "group": "Data quality",
          "subGroup": "Data feed"
        },
        {
          "code": "CVF-OP1",
          "name": "Vendor SLA adherence",
          "isKey": false,
          "metricType": "ops",
          "unit": "%",
          "dir": "gt",
          "green": 95,
          "amber": 90,
          "thresholdRule": "≥ 95 → green; ≥ 90 → amber; else red",
          "history": [
            97,
            97.5,
            96.5,
            97,
            97.5,
            97,
            96.5,
            97.5,
            97,
            96.5,
            97,
            97
          ],
          "acknowledged": null,
          "latest": 97,
          "previous": 97,
          "group": "Operational",
          "subGroup": "Data feed"
        }
      ],
      "modelType": "Data feed",
      "lastRun": {
        "executedAt": "2026-07-19 07:15",
        "runtime": "9m",
        "status": "Succeeded",
        "codeVersion": "v2.2.1",
        "trigger": "Scheduled (weekly)"
      }
    },
    {
      "id": "m10",
      "name": "Intraday Liquidity Model",
      "kind": "Model",
      "function": "Treasury",
      "businessArea": "Liquidity Risk",
      "materiality": "Medium",
      "riskTier": "M",
      "accountableOwner": "Rob Whitfield",
      "delegate": "Sofia Petrov",
      "developer": "Ewan Baxter",
      "version": "v1.6",
      "environment": "SageMaker",
      "nextExecution": "2026-08-01",
      "upstream": [],
      "linksOut": [
        {
          "kind": "Tableau",
          "label": "Intraday usage workbook"
        }
      ],
      "runs": [
        {
          "executedAt": "2026-07-20 06:40",
          "runtime": "26m",
          "status": "Succeeded",
          "codeVersion": "v1.6.0",
          "trigger": "Scheduled (weekly)"
        },
        {
          "executedAt": "2026-07-13 06:38",
          "runtime": "25m",
          "status": "Succeeded",
          "codeVersion": "v1.6.0",
          "trigger": "Scheduled (weekly)"
        },
        {
          "executedAt": "2026-07-06 06:41",
          "runtime": "27m",
          "status": "Succeeded",
          "codeVersion": "v1.6.0",
          "trigger": "Scheduled (weekly)"
        }
      ],
      "kpis": [
        {
          "code": "ILM-PM1",
          "name": "Throughput forecast error",
          "isKey": true,
          "metricType": "perf",
          "unit": "%",
          "dir": "lt",
          "green": 10,
          "amber": 15,
          "thresholdRule": "< 10 → green; ≤ 15 → amber; else red",
          "history": [
            7,
            7.5,
            6.5,
            7,
            7.5,
            7,
            6.5,
            7.5,
            7,
            6.5,
            7,
            7
          ],
          "acknowledged": null,
          "latest": 7,
          "previous": 7,
          "group": "Performance",
          "subGroup": "Liquidity"
        },
        {
          "code": "ILM-PM2",
          "name": "Peak usage back-test error",
          "isKey": true,
          "metricType": "perf",
          "unit": "%",
          "dir": "lt",
          "green": 8,
          "amber": 12,
          "thresholdRule": "< 8 → green; ≤ 12 → amber; else red",
          "history": [
            5.5,
            5.9,
            5.1,
            5.5,
            5.9,
            5.5,
            5.1,
            5.9,
            5.5,
            5.1,
            5.5,
            5.5
          ],
          "acknowledged": null,
          "latest": 5.5,
          "previous": 5.5,
          "group": "Performance",
          "subGroup": "Liquidity"
        },
        {
          "code": "ILM-DQ1",
          "name": "Payment feed completeness",
          "isKey": false,
          "metricType": "dq",
          "unit": "%",
          "dir": "gt",
          "green": 99.5,
          "amber": 98,
          "thresholdRule": "≥ 99.5 → green; ≥ 98 → amber; else red",
          "history": [
            99.9,
            99.93,
            99.87,
            99.9,
            99.93,
            99.9,
            99.87,
            99.93,
            99.9,
            99.87,
            99.9,
            99.9
          ],
          "acknowledged": null,
          "latest": 99.9,
          "previous": 99.9,
          "group": "Data quality",
          "subGroup": "Liquidity"
        },
        {
          "code": "ILM-OP1",
          "name": "Run success rate",
          "isKey": false,
          "metricType": "ops",
          "unit": "%",
          "dir": "gt",
          "green": 98,
          "amber": 95,
          "thresholdRule": "≥ 98 → green; ≥ 95 → amber; else red",
          "history": [
            100,
            100,
            100,
            100,
            100,
            100,
            100,
            100,
            100,
            100,
            100,
            100
          ],
          "acknowledged": null,
          "latest": 100,
          "previous": 100,
          "group": "Operational",
          "subGroup": "Liquidity"
        },
        {
          "code": "ILM-PM3",
          "name": "Stress buffer coverage",
          "isKey": false,
          "metricType": "perf",
          "unit": "ratio",
          "dir": "gt",
          "green": 1.2,
          "amber": 1,
          "thresholdRule": "≥ 1.2 → green; ≥ 1 → amber; else red",
          "history": [
            1.5,
            1.55,
            1.45,
            1.5,
            1.55,
            1.5,
            1.45,
            1.55,
            1.5,
            1.45,
            1.5,
            1.5
          ],
          "acknowledged": null,
          "latest": 1.5,
          "previous": 1.5,
          "group": "Performance",
          "subGroup": "Liquidity"
        }
      ],
      "modelType": "Liquidity",
      "lastRun": {
        "executedAt": "2026-07-20 06:40",
        "runtime": "26m",
        "status": "Succeeded",
        "codeVersion": "v1.6.0",
        "trigger": "Scheduled (weekly)"
      }
    },
    {
      "id": "m11",
      "name": "FX Options Valuation (vendor)",
      "kind": "Vendor model",
      "function": "Treasury",
      "businessArea": "Markets Treasury",
      "materiality": "High",
      "riskTier": "H",
      "accountableOwner": "Rob Whitfield",
      "delegate": "Sofia Petrov",
      "developer": "Ewan Baxter",
      "version": "v4.7.1 (vendor)",
      "environment": "On-prem",
      "nextExecution": "2026-08-14",
      "upstream": [],
      "notes": "Vendor confirmed the vol-surface staleness is an interpolation defect; patch 4.7.2 scheduled — remediation PROTO-2033 in progress.",
      "linksOut": [
        {
          "kind": "Confluence",
          "label": "Vendor model due-diligence pack"
        },
        {
          "kind": "Tableau",
          "label": "IPV variance workbook"
        }
      ],
      "runs": [
        {
          "executedAt": "2026-07-21 19:30",
          "runtime": "33m",
          "status": "Succeeded",
          "codeVersion": "v4.7.1",
          "trigger": "Scheduled (weekly)"
        },
        {
          "executedAt": "2026-07-14 19:28",
          "runtime": "32m",
          "status": "Succeeded",
          "codeVersion": "v4.7.1",
          "trigger": "Scheduled (weekly)"
        },
        {
          "executedAt": "2026-07-07 19:31",
          "runtime": "34m",
          "status": "Succeeded",
          "codeVersion": "v4.7.0",
          "trigger": "Scheduled (weekly)"
        }
      ],
      "kpis": [
        {
          "code": "FXV-PM1",
          "name": "IPV variance",
          "isKey": true,
          "metricType": "perf",
          "unit": "bps",
          "dir": "lt",
          "green": 5,
          "amber": 10,
          "thresholdRule": "< 5 → green; ≤ 10 → amber; else red",
          "history": [
            3.2,
            3.5,
            2.9,
            3.2,
            3.5,
            3.2,
            2.9,
            3.5,
            3.2,
            2.9,
            3.2,
            3.2
          ],
          "acknowledged": null,
          "latest": 3.2,
          "previous": 3.2,
          "group": "Performance",
          "subGroup": "Valuation"
        },
        {
          "code": "FXV-PM2",
          "name": "Greeks stability index",
          "isKey": true,
          "metricType": "perf",
          "unit": "index",
          "dir": "lt",
          "green": 0.1,
          "amber": 0.2,
          "thresholdRule": "< 0.1 → green; ≤ 0.2 → amber; else red",
          "history": [
            0.06,
            0.07,
            0.05,
            0.06,
            0.07,
            0.06,
            0.05,
            0.07,
            0.06,
            0.05,
            0.06,
            0.06
          ],
          "acknowledged": null,
          "latest": 0.06,
          "previous": 0.06,
          "group": "Performance",
          "subGroup": "Valuation"
        },
        {
          "code": "FXV-DQ1",
          "name": "Vol surface staleness",
          "isKey": false,
          "metricType": "dq",
          "unit": "hrs",
          "dir": "lt",
          "green": 24,
          "amber": 72,
          "thresholdRule": "< 24 → green; ≤ 72 → amber; else red",
          "history": [
            8,
            10,
            9,
            12,
            11,
            10,
            14,
            12,
            16,
            20,
            26,
            30
          ],
          "acknowledged": null,
          "latest": 30,
          "previous": 26,
          "group": "Data quality",
          "subGroup": "Valuation"
        },
        {
          "code": "FXV-DQ2",
          "name": "Market data completeness",
          "isKey": false,
          "metricType": "dq",
          "unit": "%",
          "dir": "gt",
          "green": 99,
          "amber": 97,
          "thresholdRule": "≥ 99 → green; ≥ 97 → amber; else red",
          "history": [
            99.7,
            99.8,
            99.6,
            99.7,
            99.8,
            99.7,
            99.6,
            99.8,
            99.7,
            99.6,
            99.7,
            99.7
          ],
          "acknowledged": null,
          "latest": 99.7,
          "previous": 99.7,
          "group": "Data quality",
          "subGroup": "Valuation"
        },
        {
          "code": "FXV-OP1",
          "name": "Vendor batch success",
          "isKey": false,
          "metricType": "ops",
          "unit": "%",
          "dir": "gt",
          "green": 98,
          "amber": 95,
          "thresholdRule": "≥ 98 → green; ≥ 95 → amber; else red",
          "history": [
            99,
            99.3,
            98.7,
            99,
            99.3,
            99,
            98.7,
            99.3,
            99,
            98.7,
            99,
            99
          ],
          "acknowledged": null,
          "latest": 99,
          "previous": 99,
          "group": "Operational",
          "subGroup": "Valuation"
        },
        {
          "code": "FXV-PM3",
          "name": "P&L explain ratio",
          "isKey": false,
          "metricType": "perf",
          "unit": "%",
          "dir": "gt",
          "green": 95,
          "amber": 90,
          "thresholdRule": "≥ 95 → green; ≥ 90 → amber; else red",
          "history": [
            97,
            97.4,
            96.6,
            97,
            97.4,
            97,
            96.6,
            97.4,
            97,
            96.6,
            97,
            97
          ],
          "acknowledged": null,
          "latest": 97,
          "previous": 97,
          "group": "Performance",
          "subGroup": "Valuation"
        }
      ],
      "modelType": "Valuation",
      "lastRun": {
        "executedAt": "2026-07-21 19:30",
        "runtime": "33m",
        "status": "Succeeded",
        "codeVersion": "v4.7.1",
        "trigger": "Scheduled (weekly)"
      }
    },
    {
      "id": "m12",
      "name": "IRRBB Sensitivity Model",
      "kind": "Model",
      "function": "Treasury",
      "businessArea": "Treasury ALM",
      "materiality": "Medium",
      "riskTier": "M",
      "accountableOwner": "Fiona Drummond",
      "delegate": "David Lam",
      "developer": "Ewan Baxter",
      "version": "v2.1",
      "environment": "Excel",
      "nextExecution": "2026-08-20",
      "upstream": [],
      "linksOut": [
        {
          "kind": "Confluence",
          "label": "IRRBB workbook control checklist"
        }
      ],
      "runs": [
        {
          "executedAt": "2026-07-18 15:10",
          "runtime": "18m",
          "status": "Succeeded",
          "codeVersion": "v2.1.1",
          "trigger": "Scheduled (monthly)"
        },
        {
          "executedAt": "2026-06-18 15:08",
          "runtime": "18m",
          "status": "Succeeded",
          "codeVersion": "v2.1.1",
          "trigger": "Scheduled (monthly)"
        },
        {
          "executedAt": "2026-06-11 09:30",
          "runtime": "19m",
          "status": "Succeeded",
          "codeVersion": "v2.1.1",
          "trigger": "Manual (post-fix validation — PROTO-2018)"
        }
      ],
      "kpis": [
        {
          "code": "IRB-PM1",
          "name": "EVE sensitivity back-test",
          "isKey": true,
          "metricType": "perf",
          "unit": "%",
          "dir": "lt",
          "green": 10,
          "amber": 15,
          "thresholdRule": "< 10 → green; ≤ 15 → amber; else red",
          "history": [
            6.8,
            7.2,
            6.4,
            6.8,
            7.2,
            6.8,
            6.4,
            7.2,
            6.8,
            6.4,
            6.8,
            6.8
          ],
          "acknowledged": null,
          "latest": 6.8,
          "previous": 6.8,
          "group": "Performance",
          "subGroup": "IRRBB"
        },
        {
          "code": "IRB-PM2",
          "name": "NII forecast error",
          "isKey": true,
          "metricType": "perf",
          "unit": "%",
          "dir": "lt",
          "green": 8,
          "amber": 12,
          "thresholdRule": "< 8 → green; ≤ 12 → amber; else red",
          "history": [
            5.2,
            5.5,
            4.9,
            5.2,
            5.5,
            5.2,
            4.9,
            5.5,
            5.2,
            4.9,
            5.2,
            5.2
          ],
          "acknowledged": null,
          "latest": 5.2,
          "previous": 5.2,
          "group": "Performance",
          "subGroup": "IRRBB"
        },
        {
          "code": "IRB-DQ1",
          "name": "Position completeness",
          "isKey": false,
          "metricType": "dq",
          "unit": "%",
          "dir": "gt",
          "green": 99,
          "amber": 97,
          "thresholdRule": "≥ 99 → green; ≥ 97 → amber; else red",
          "history": [
            99.8,
            99.85,
            99.75,
            99.8,
            99.85,
            99.8,
            99.75,
            99.85,
            99.8,
            99.75,
            99.8,
            99.8
          ],
          "acknowledged": null,
          "latest": 99.8,
          "previous": 99.8,
          "group": "Data quality",
          "subGroup": "IRRBB"
        },
        {
          "code": "IRB-OP1",
          "name": "Workbook checks passed",
          "isKey": false,
          "metricType": "ops",
          "unit": "%",
          "dir": "gt",
          "green": 99,
          "amber": 95,
          "thresholdRule": "≥ 99 → green; ≥ 95 → amber; else red",
          "history": [
            100,
            100,
            100,
            100,
            100,
            100,
            100,
            100,
            100,
            100,
            100,
            100
          ],
          "acknowledged": null,
          "latest": 100,
          "previous": 100,
          "group": "Operational",
          "subGroup": "IRRBB"
        },
        {
          "code": "IRB-PM3",
          "name": "Bucketing reconciliation breaks",
          "isKey": false,
          "metricType": "dq",
          "unit": "lines",
          "dir": "lt",
          "green": 5,
          "amber": 20,
          "thresholdRule": "< 5 → green; ≤ 20 → amber; else red",
          "history": [
            12,
            13,
            14,
            11,
            13,
            14,
            12,
            10,
            2,
            1,
            0,
            0
          ],
          "acknowledged": null,
          "latest": 0,
          "previous": 0,
          "group": "Data quality",
          "subGroup": "IRRBB"
        }
      ],
      "modelType": "IRRBB",
      "lastRun": {
        "executedAt": "2026-07-18 15:10",
        "runtime": "18m",
        "status": "Succeeded",
        "codeVersion": "v2.1.1",
        "trigger": "Scheduled (monthly)"
      }
    }
  ],
  "tickets": [
    {
      "ref": "PROTO-2041",
      "modelId": "m06",
      "kpiCode": "BDM-PM1",
      "title": "PSI drift on Behavioural Deposit Model",
      "assignee": "Priya Nair",
      "byWhen": "2026-07-28",
      "state": "Investigating",
      "openedAt": "2026-07-14",
      "eventLog": [
        {
          "at": "2026-07-11",
          "who": "System",
          "what": "Breach opened — BDM-PM1 PSI crossed amber on run 2026-06-10; red on 2026-07-10 (0.31 vs < 0.10 green)."
        },
        {
          "at": "2026-07-14",
          "who": "David Lam (Fix)",
          "what": "Triaged: severity High, materiality High. Rationale: “Sustained six-run PSI climb — drift, not blip.” Escalated → ticket created."
        },
        {
          "at": "2026-07-15",
          "who": "Priya Nair (Fix)",
          "what": "Evidence lenses assembled; upstream check clean — source, not symptom."
        },
        {
          "at": "2026-07-20",
          "who": "Priya Nair (Fix)",
          "what": "Segment analysis in local Tableau workbook: instant-access segment shifted after June rate change."
        }
      ]
    },
    {
      "ref": "PROTO-2036",
      "modelId": "m01",
      "kpiCode": "MSF-DQ1",
      "category": "Data",
      "title": "MSF-DQ1 Feed completeness — investigate & fix",
      "assignee": "Ana Kovač",
      "byWhen": "2026-07-31",
      "state": "Investigating",
      "openedAt": "2026-07-16",
      "eventLog": [
        {
          "at": "2026-07-13",
          "who": "System",
          "what": "Breach opened — MSF-DQ1 feed completeness below amber floor (98.4%)."
        },
        {
          "at": "2026-07-14",
          "who": "Tom Ferris (Fix)",
          "what": "Triaged: severity High. Rationale: “Vendor file truncated — two scenario blocks missing.” Escalated → work item opened."
        },
        {
          "at": "2026-07-16",
          "who": "Ana Kovač (Fix)",
          "what": "Investigating — evidence assembled across data / model / process; root cause not yet concluded."
        }
      ]
    },
    {
      "ref": "PROTO-2033",
      "modelId": "m11",
      "kpiCode": "FXV-DQ1",
      "category": "Model",
      "title": "Apply vendor patch 4.7.2 — stale vol-surface interpolation",
      "assignee": "Ewan Baxter",
      "byWhen": "2026-08-08",
      "state": "In progress",
      "openedAt": "2026-07-06",
      "eventLog": [
        {
          "at": "2026-07-03",
          "who": "Sofia Petrov (Fix)",
          "what": "Investigation concluded: model factor — vendor interpolation defect confirmed by vendor. Remediation recommended: patch 4.7.2."
        },
        {
          "at": "2026-07-06",
          "who": "System",
          "what": "Moved to Awaiting approval."
        },
        {
          "at": "2026-07-09",
          "who": "Rob Whitfield (Review)",
          "what": "Approved with audit note: “Vendor patch is the right fix; interim manual refresh of the surface each morning until deployed.”"
        },
        {
          "at": "2026-07-15",
          "who": "Ewan Baxter (Fix)",
          "what": "Patch received from vendor; deployment scheduled into the weekly release window."
        }
      ]
    },
    {
      "ref": "PROTO-2029",
      "modelId": "m03",
      "kpiCode": "RPD-PM2",
      "category": "Model",
      "title": "Recalibrate scorecard weights after Q2 population shift",
      "assignee": "Callum Reid",
      "byWhen": "2026-07-01",
      "state": "Resolved",
      "openedAt": "2026-06-05",
      "closedAt": "2026-07-02",
      "closureEvidence": "Post-fix PSI 0.07 → 0.06 (green) across two consecutive validation runs; model status recomputed Green on 2026-07-02.",
      "eventLog": [
        {
          "at": "2026-05-12",
          "who": "System",
          "what": "Breach opened — RPD-PM2 PSI red (0.27)."
        },
        {
          "at": "2026-05-13",
          "who": "Meera Shah (Fix)",
          "what": "Triaged: severity High. Escalated — investigation confirmed genuine population shift in Q2 originations."
        },
        {
          "at": "2026-06-05",
          "who": "James Okonkwo (Review)",
          "what": "Approved with audit note: “Recalibration within existing model scope; no redevelopment trigger.”"
        },
        {
          "at": "2026-06-28",
          "who": "Callum Reid (Fix)",
          "what": "Recalibrated weights deployed (v5.1.3); validation re-run requested."
        },
        {
          "at": "2026-07-02",
          "who": "System",
          "what": "Validation re-run: PSI 0.06 (green). Resolved — closure evidence attached; status recomputed."
        }
      ]
    },
    {
      "ref": "PROTO-2025",
      "modelId": "m05",
      "kpiCode": "WLG-PM3",
      "title": "Suspected downturn-floor breach",
      "assignee": "Callum Reid",
      "byWhen": "2026-06-20",
      "state": "Won't do",
      "openedAt": "2026-06-12",
      "eventLog": [
        {
          "at": "2026-06-10",
          "who": "System",
          "what": "WLG-PM3 downturn floor headroom dipped to 4.9% (amber) on the April run."
        },
        {
          "at": "2026-06-12",
          "who": "Meera Shah (Fix)",
          "what": "Escalated for a look — headroom trend had been narrowing for three runs."
        },
        {
          "at": "2026-06-18",
          "who": "James Okonkwo (Review)",
          "what": "Rejected with audit note: “Single-run dip caused by collateral feed lag — reverted next run. No model issue.”"
        }
      ]
    },
    {
      "ref": "PROTO-2018",
      "modelId": "m12",
      "kpiCode": "IRB-PM3",
      "category": "Process",
      "title": "Fix duplicated cashflow bucketing in workbook",
      "assignee": "David Lam",
      "byWhen": "2026-06-15",
      "state": "Resolved",
      "openedAt": "2026-05-20",
      "closedAt": "2026-06-11",
      "closureEvidence": "Bucketing reconciliation breaks 14 → 0 post-fix; a workbook control check was added to the run checklist. Fixed within the run window — no committee needed.",
      "eventLog": [
        {
          "at": "2026-05-18",
          "who": "David Lam (Fix)",
          "what": "Investigation concluded: process factor — a copied formula range double-counted the 3–6m bucket."
        },
        {
          "at": "2026-05-20",
          "who": "Fiona Drummond (Review)",
          "what": "Approved with audit note: “Workbook fix plus a control check — proportionate.”"
        },
        {
          "at": "2026-06-11",
          "who": "System",
          "what": "Validation re-run: breaks 0 (green). Resolved — closure evidence attached; status recomputed."
        }
      ]
    }
  ],
  "signals": [
    {
      "id": "s1",
      "channel": "Teams",
      "text": "Breach opened on Liquidity Stress Overlay — LCR back-test variance amber",
      "ago": "2h ago",
      "route": "#/models/m08"
    },
    {
      "id": "s2",
      "channel": "Email",
      "text": "Execution window opens Mon 27 Jul — IFRS9 Impairment Engine",
      "ago": "3h ago",
      "route": "#/models/m04"
    },
    {
      "id": "s3",
      "channel": "Jira",
      "text": "PROTO-2036 opened — investigating the Macro Scenario Feed feed-completeness breach",
      "ago": "1d ago",
      "route": "#/work/PROTO-2036"
    },
    {
      "id": "s4",
      "channel": "Teams",
      "text": "PSI drift red on Behavioural Deposit Model — investigation PROTO-2041 analysing",
      "ago": "2d ago",
      "route": "#/work/PROTO-2041"
    }
  ],
  "users": [
    {
      "id": "tom",
      "name": "Tom Ferris",
      "duty": "fix",
      "holds": [
        "fix"
      ],
      "models": [
        "m01",
        "m02",
        "m04",
        "m06",
        "m07"
      ]
    },
    {
      "id": "sarah",
      "name": "Sarah McAllister",
      "duty": "review",
      "holds": [
        "review"
      ],
      "models": [
        "m01",
        "m02",
        "m04",
        "m07"
      ]
    },
    {
      "id": "david",
      "name": "David Lam",
      "duty": "fix",
      "holds": [
        "fix"
      ],
      "models": [
        "m06",
        "m08",
        "m12"
      ]
    }
  ]
};
