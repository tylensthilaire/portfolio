/* ============================================================
   MPMP — shared UI layer (window.STATE, window.UI)
   Client-side session state + the render primitives every view
   composes from. Filter / scope / sort live in the URL query so a
   view can be shared, bookmarked and deep-linked. Duty lens is a
   session mode. Render functions are pure: data in → HTML string out.
   ============================================================ */
(function () {
  'use strict';

  var API = window.API, ENGINE = window.ENGINE, U = window.U;

  // ---------------- session state (not persisted) ----------------
  var STATE = {
    lens: 'fix',              // duty lens: fix | review | report
    signalsDismissed: false,
    open: {},                 // expandable panels (derivation, triage, lenses…)
    drafts: {},               // form values surviving re-renders
    flash: {},                // inline validation messages
    packOpen: {}              // modelId → evidence pack visible
  };

  var LENS = {
    fix:    { label: 'Fix',    persona: 'model-developer', nav: 'triage',    verb: 'triage & fix' },
    review: { label: 'Review', persona: 'model-owner',     nav: 'work',      verb: 'approve & assure' },
    report: { label: 'Report', persona: 'model-risk-owner', nav: 'portfolio', verb: 'oversee' }
  };

  // ---------------- URL contract: #/route/param?fn=…&tier=…&scope=… ----------------
  function parseHash(hash) {
    hash = (hash || location.hash || '#/').replace(/^#\/?/, '');
    var qi = hash.indexOf('?'), qs = '';
    if (qi >= 0) { qs = hash.slice(qi + 1); hash = hash.slice(0, qi); }
    var seg = hash.split('/').filter(Boolean);
    var query = {};
    qs.split('&').forEach(function (p) { if (!p) return; var kv = p.split('='); query[decodeURIComponent(kv[0])] = decodeURIComponent(kv[1] || ''); });
    return { route: seg[0] || 'home', param: seg[1] || null, query: query };
  }
  function buildHash(route, param, query) {
    var h = '#/' + route + (param ? '/' + param : '');
    var qs = Object.keys(query || {}).filter(function (k) { return query[k] != null && query[k] !== ''; })
      .map(function (k) { return encodeURIComponent(k) + '=' + encodeURIComponent(query[k]); }).join('&');
    return h + (qs ? '?' + qs : '');
  }
  function currentQuery() { return parseHash().query; }
  function setQuery(patch) {
    var cur = parseHash(), q = cur.query;
    Object.keys(patch).forEach(function (k) { if (patch[k] == null || patch[k] === '' || patch[k] === 'all') delete q[k]; else q[k] = patch[k]; });
    location.hash = buildHash(cur.route, cur.param, q);
  }

  // ---------------- filter + scope + sort over a model list ----------------
  function filterModels(list, q) {
    return list.filter(function (m) {
      if (q.fn && m.function !== q.fn) return false;
      if (q.tier && m.riskTier !== q.tier) return false;
      if (q.owner && m.accountableOwner !== q.owner) return false;
      if (q.rag) { var st = (q.asOf != null && q.asOf !== '') ? ENGINE.dispStatusAt(m, +q.asOf) : ENGINE.dispStatus(m); if (st !== (q.rag === 'ack' ? 'ack' : q.rag)) return false; }
      if (q.q) {
        var t = (m.name + ' ' + m.id + ' ' + m.businessArea).toLowerCase();
        if (t.indexOf(q.q.toLowerCase()) < 0) return false;
      }
      return true;
    });
  }

  // ---------------- render primitives ----------------
  function chip(rag, label, title) {
    return '<span class="chip rag-' + rag + '"' + (title ? ' title="' + U.esc(title) + '"' : '') +
      '><span class="dot" aria-hidden="true"></span>' + U.esc(label) + '</span>';
  }
  function statusChip(m, i) {
    var s = ENGINE.modelStatus(m, i);
    var label = s.ackedOnly ? 'Amber' : U.titleCase(s.rag);
    return chip(s.rag, label, 'Computed from the KPIs — open Derivation for how.');
  }
  function ackBadge(m) {
    var a = ENGINE.ackInfo(m);
    if (!a) return '';
    return '<span class="ack-badge" title="' + U.esc(a.kpi.code + ' — ' + a.ack.who + ', ' + U.fmtD(a.ack.at)) + '">✓ Acknowledged — ' + U.esc(a.ack.rationale) + '</span>';
  }
  function symptomTag(m) {
    if (!m.symptomOf) return '';
    var up = API.model(m.symptomOf);
    return '<span class="symptom-tag">symptom of ↑ ' + U.esc(up.name) + '</span>';
  }
  function moveArrow(prevRag, lastRag, detail) {
    var rank = { green: 0, amber: 1, red: 2 };
    if (rank[lastRag] > rank[prevRag]) return '<span class="move-up" title="' + U.esc(detail || '') + '">▲ worsened</span>';
    if (rank[lastRag] < rank[prevRag]) return '<span class="move-down" title="' + U.esc(detail || '') + '">▼ improved</span>';
    return '<span class="move-flat">– unchanged</span>';
  }
  function kpiMove(k) { return moveArrow(ENGINE.ragOf(k, k.previous), ENGINE.kst(k), k.previous + ' → ' + k.latest + ' ' + k.unit); }
  function spark(k, hi) {
    var h = k.history, min = Math.min.apply(null, h), max = Math.max.apply(null, h), span = (max - min) || 1;
    var pts = h.map(function (v, i) { return (4 + i * 7) + ',' + (17 - ((v - min) / span) * 13); }).join(' ');
    var idx = (hi == null ? h.length - 1 : hi);
    var hx = 4 + idx * 7, hy = 17 - ((h[idx] - min) / span) * 13;
    var col = { red: 'var(--rag-red-solid)', amber: 'var(--rag-amber-solid)', green: 'var(--rag-green-solid)' }[ENGINE.kst(k, hi)];
    return '<svg class="sparkline" width="88" height="20" viewBox="0 0 88 20" role="img" aria-label="12-run history for ' + U.esc(k.code) + '">' +
      '<polyline points="' + pts + '" fill="none" stroke="var(--ink-300)" stroke-width="1.5"/>' +
      '<circle cx="' + hx + '" cy="' + hy + '" r="2.5" fill="' + col + '"/></svg>';
  }
  function keytag(k) { return k.isKey ? '<span class="keytag">KEY</span>' : ''; }
  function expander(key, label, expanded) {
    return '<button type="button" class="btn btn-ghost btn-sm" data-action="expand" data-key="' + U.esc(key) + '" aria-expanded="' + (!!expanded) + '">' + U.esc(label) + (expanded ? ' ▴' : ' ▾') + '</button>';
  }
  function derivation(m, i) {
    var s = ENGINE.modelStatus(m, i);
    var kpiLines = m.kpis.map(function (k) {
      var a = ENGINE.ackOf(m, k);
      return k.code + ' ' + (k.isKey ? '[KEY] ' : '') + ENGINE.kst(k, i) + (a ? ' — acknowledged, excluded' : '');
    }).join(' · ');
    var chain = m.symptomOf ? '<dt>Chain attribution</dt><dd>Likely a symptom of ' + U.esc(API.model(m.symptomOf).name) + ' — check the upstream strip before investigating locally.</dd>' : '';
    return '<div class="deriv" id="deriv-' + m.id + '"><dl style="margin:0">' +
      '<dt>Rule</dt><dd>Key-KPI dominance with a materiality floor — any key KPI red → Red; any unacknowledged key KPI amber → Amber; else ≥30% of non-key KPIs amber-or-red → Amber; else Green.</dd>' +
      '<dt>KPIs evaluated</dt><dd>' + s.key.length + ' key + ' + s.nonKey.length + ' non-key' + (s.acked.length ? '; ' + s.acked.length + ' acknowledged (excluded)' : '') + '. ' + U.esc(kpiLines) + '</dd>' +
      '<dt>Why this colour</dt><dd>' + U.esc(s.branch) + '</dd>' + chain +
      '</dl><p class="caveat">Aggregation rule under review — the status always travels with how it was derived.</p></div>';
  }
  function statusBlock(m, i) {
    var open = STATE.open['deriv-' + m.id];
    return statusChip(m, i) + ' ' + expander('deriv-' + m.id, 'Derivation', open) + ' ' + ackBadge(m) + (open ? derivation(m, i) : '');
  }
  function stateChip(st) {
    var cls = { 'Awaiting approval': 'st-awaiting', 'Investigating': 'st-progress', 'In progress': 'st-progress', 'Validating': 'st-validating', 'Resolved': 'st-resolved', "Won't do": 'st-rejected' }[st] || '';
    return '<span class="state-chip ' + cls + '">' + U.esc(st) + '</span>';
  }
  function breachChip(m) {
    var bs = ENGINE.breachState(m);
    if (bs === 'untriaged') return '';
    var cls = { acknowledged: 'st-awaiting', escalated: 'st-progress', dismissed: 'st-rejected', inherited: 'st-progress' }[bs] || '';
    return '<span class="state-chip ' + cls + '">' + U.esc(ENGINE.BREACH_STATES[bs].label) + '</span>';
  }
  function lastVisitLine() {
    var META = API.meta();
    return '<p class="lastvisit">Last visit: ' + U.fmtD(META.lastVisit) + ' — ' + META.lastVisitAgo + '. Here’s what changed.</p>';
  }
  function flashMsg(key) { return STATE.flash[key] ? '<p class="flash" role="alert">' + U.esc(STATE.flash[key]) + '</p>' : ''; }
  function draft(id, fallback) { return STATE.drafts[id] !== undefined ? STATE.drafts[id] : (fallback || ''); }

  // "new since last visit" (a breach opened) vs "changed" (a KPI moved run-on-run)
  function changeTag(m) {
    if (m.breach && U.parseD(m.breach.openedAt) > U.parseD(API.meta().lastVisit)) return '<span class="pill-new">NEW</span>';
    var moved = m.kpis.some(function (k) { return ENGINE.kst(k) !== ENGINE.ragOf(k, k.previous); });
    return moved ? '<span class="pill-changed">CHANGED</span>' : '';
  }

  // ---------------- filter bar ----------------
  // active: array of controls to show, e.g. ['scope','fn','tier','rag','owner','q']
  function seg(key, val, cur, label) {
    var on = cur === val || (!cur && val === 'all');
    return '<button type="button" class="fseg' + (on ? ' active' : '') + '" data-action="filter" data-key="' + key + '" data-val="' + val + '" aria-pressed="' + on + '">' + U.esc(label) + '</button>';
  }
  function group(label, key, opts, cur) {
    return '<div class="fgroup"><span class="flabel">' + label + '</span>' + opts.map(function (o) { return seg(key, o[0], cur, o[1]); }).join('') + '</div>';
  }
  function filterBar(active, q) {
    var parts = [];
    if (active.indexOf('fn') >= 0) parts.push(group('Function', 'fn', [['all', 'All'], ['Finance', 'Finance'], ['Treasury', 'Treasury']], q.fn));
    if (active.indexOf('tier') >= 0) parts.push(group('Risk tier', 'tier', [['all', 'All'], ['VH', 'VH'], ['H', 'H'], ['M', 'M'], ['L', 'L']], q.tier));
    if (active.indexOf('rag') >= 0) parts.push(group('RAG', 'rag', [['all', 'All'], ['red', 'Red'], ['amber', 'Amber'], ['green', 'Green'], ['ack', 'Ack’d']], q.rag));
    if (active.indexOf('owner') >= 0) {
      parts.push('<div class="fgroup"><span class="flabel">Owner</span><select class="fselect" data-action="filter" data-key="owner" aria-label="Filter by owner"><option value="all">All owners</option>' +
        API.owners().map(function (o) { return '<option value="' + U.esc(o) + '"' + (q.owner === o ? ' selected' : '') + '>' + U.esc(o) + '</option>'; }).join('') + '</select></div>');
    }
    if (active.indexOf('q') >= 0) {
      parts.push('<div class="fgroup fgrow"><span class="flabel">Search</span><input type="text" id="filter-q" class="fsearch" aria-label="Search models by name or id" placeholder="Model name or id…" value="' + U.esc(q.q || '') + '"></div>');
    }
    var anyOn = ['fn', 'tier', 'rag', 'owner', 'q'].some(function (k) { return q[k]; });
    if (anyOn) parts.push('<button type="button" class="linklike fclear" data-action="filter-clear">Clear all</button>');
    return '<div class="filter-bar" data-form>' + parts.join('') + '</div>';
  }
  function reconcile(shown, total, extra) {
    return '<p class="reconcile">Showing <b>' + shown + '</b> of ' + total + ' models' + (extra ? ' — ' + extra : '') + '.</p>';
  }

  window.STATE = STATE;
  window.UI = {
    LENS: LENS,
    parseHash: parseHash, buildHash: buildHash, currentQuery: currentQuery, setQuery: setQuery,
    filterModels: filterModels,
    chip: chip, statusChip: statusChip, ackBadge: ackBadge, symptomTag: symptomTag, changeTag: changeTag,
    moveArrow: moveArrow, kpiMove: kpiMove, spark: spark, keytag: keytag, expander: expander,
    derivation: derivation, statusBlock: statusBlock, stateChip: stateChip, breachChip: breachChip,
    lastVisitLine: lastVisitLine, flashMsg: flashMsg, draft: draft,
    filterBar: filterBar, reconcile: reconcile
  };
})();
