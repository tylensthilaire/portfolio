/* Model room — a run-paginated view. The page frames the model across runs
   (identity, the run timeline, work, links, evidence); within it you view one
   run's snapshot at a time (default: latest) — status, upstream, KPI readings,
   metadata — all AS OF the selected run. A run is addressable (?run=) but not
   its own page: it's the lens the model page is viewed through.
   Data via API, status via ENGINE, markup via UI. */
(function () {
  'use strict';
  var V = window.VIEWS = window.VIEWS || {};
  var API = window.API, ENGINE = window.ENGINE, UI = window.UI, U = window.U;

  // ---- run navigator: the RAG timeline; each point selects that run ----
  function timeline(m, sel) {
    var months = API.meta().months, W = 560, H = 150, padL = 44, padTop = 12, padBot = 26;
    var band = { green: padTop + (H - padTop - padBot) * 0.15, amber: padTop + (H - padTop - padBot) * 0.5, red: padTop + (H - padTop - padBot) * 0.85 };
    var x = function (i) { return padL + i * ((W - padL - 12) / 11); };
    var mpts = [], dots = '', i, rg;
    for (i = 0; i < 12; i++) {
      rg = ENGINE.modelStatus(m, i).rag;
      mpts.push(x(i) + ',' + band[rg]);
      var on = i === sel.index;
      dots += '<a href="#/models/' + U.esc(m.id) + '?run=' + U.esc(m.id + '-' + i) + '" aria-label="' + U.esc(months[i] + ' run — ' + U.titleCase(rg)) + '">' +
        '<circle cx="' + x(i) + '" cy="' + band[rg] + '" r="' + (on ? 6 : 3.5) + '" fill="var(--rag-' + rg + '-solid)"' + (on ? ' stroke="var(--brand-purple-800)" stroke-width="2"' : '') +
        '><title>' + U.esc(months[i] + ': ' + U.titleCase(rg)) + '</title></circle></a>';
    }
    var yl = ['green', 'amber', 'red'].map(function (r2) { return '<text x="6" y="' + (band[r2] + 4) + '" font-size="10" fill="var(--ink-500)">' + U.titleCase(r2) + '</text>'; }).join('');
    var xl = months.map(function (mo, k) { return '<text x="' + x(k) + '" y="' + (H - 8) + '" font-size="9" fill="' + (k === sel.index ? 'var(--brand-purple-800)' : 'var(--ink-400)') + '" font-weight="' + (k === sel.index ? '700' : '400') + '" text-anchor="middle">' + U.esc(mo) + '</text>'; }).join('');
    return '<svg width="100%" viewBox="0 0 ' + W + ' ' + H + '" role="img" aria-label="Run timeline — RAG across the last 12 runs; select a run">' +
      '<polyline points="' + mpts.join(' ') + '" fill="none" stroke="var(--brand-purple-600)" stroke-width="2.5"/>' + dots + yl + xl + '</svg>';
  }

  function runNav(m, runs, sel) {
    var pos = 0; for (var j = 0; j < runs.length; j++) if (runs[j].id === sel.id) pos = j;
    var older = runs[pos + 1], newer = runs[pos - 1];
    function step(run, label) {
      return run ? '<a class="btn btn-ghost btn-sm" href="#/models/' + U.esc(m.id) + '?run=' + U.esc(run.id) + '">' + label + '</a>'
        : '<span class="btn btn-ghost btn-sm" style="opacity:.35">' + label + '</span>';
    }
    return '<div class="run-nav">' + step(older, '← Older') + step(newer, 'Newer →') +
      (pos !== 0 ? '<a class="linklike" href="#/models/' + U.esc(m.id) + '">Back to latest</a>' : '') + '</div>';
  }

  // ---- snapshot pieces (all AS OF run index i) ----
  function upstreamAt(m, i) {
    var ups = m.upstream || [];
    if (!ups.length) return '<span class="muted small">No upstream dependencies declared.</span>';
    return '<div class="upstream-strip">' + ups.map(function (uid) {
      var u = API.model(uid); if (!u) return '';
      var us = ENGINE.modelStatus(u, i);
      return '<a class="up-chip" href="#/models/' + U.esc(uid) + '">' + U.esc(u.name) + ' ' +
        UI.chip(us.rag, U.titleCase(us.rag), 'Open its model room') + (us.hasAck ? ' <span class="ack-badge">✓ ack</span>' : '') + '</a>';
    }).join('') + '</div>';
  }
  function kpiRowAt(m, k, i) {
    var st = ENGINE.kst(k, i), a = ENGINE.ackOf(m, k);
    var move = i > 0 ? UI.moveArrow(ENGINE.kst(k, i - 1), st, k.history[i - 1] + ' → ' + k.history[i] + ' ' + k.unit) : '<span class="move-flat">– first run</span>';
    return '<tr class="kpi-' + st + '"><td class="mono">' + U.esc(k.code) + '</td><td>' + U.esc(k.name) + '</td>' +
      '<td>' + (k.isKey ? UI.keytag(k) : '<span class="tiny">non-key</span>') + '</td>' +
      '<td>' + k.history[i] + ' ' + U.esc(k.unit) + '</td>' +
      '<td class="mono">' + U.esc(k.thresholdRule) + '</td>' +
      '<td>' + UI.chip(st, U.titleCase(st), k.thresholdRule) +
      (a ? '<br><span class="ack-badge" title="' + U.esc(a.who + ' · ' + U.fmtD(a.at)) + '">✓ Acknowledged — ' + U.esc(a.rationale) + '</span>' : '') + '</td>' +
      '<td>' + UI.spark(k, i) + '</td><td>' + move + '</td></tr>';
  }
  function kpiTableAt(m, i) {
    var rank = { red: 0, amber: 1, green: 2 };
    var kpis = m.kpis.slice().sort(function (a, b) { return rank[ENGINE.kst(a, i)] - rank[ENGINE.kst(b, i)] || (b.isKey - a.isKey); });
    return '<table><thead><tr><th>Code</th><th>Name</th><th>Tier</th><th>Reading</th><th>Threshold rule</th><th>Status</th><th>History</th><th>Movement</th></tr></thead><tbody>' +
      kpis.map(function (k) { return kpiRowAt(m, k, i); }).join('') + '</tbody></table>';
  }

  // ---- frame pieces (across runs) ----
  function workTable(m) {
    var tks = API.ticketsForModel(m.id);
    if (!tks.length) return '<p class="muted small">No tickets on this model.</p>';
    return '<table><thead><tr><th>Ref</th><th>Title</th><th>Assignee</th><th>By when</th><th>State</th></tr></thead><tbody>' +
      tks.map(function (t) {
        return '<tr><td><a href="#/work/' + U.esc(t.ref) + '" class="mono">' + U.esc(t.ref) + '</a></td>' +
          '<td>' + U.esc(t.title) + '</td><td>' + U.esc(t.assignee) + '</td><td>' + U.fmtD(t.byWhen) + '</td><td>' + UI.stateChip(t.state) + '</td></tr>';
      }).join('') + '</tbody></table>';
  }
  function linksOut(m) {
    var links = m.linksOut || [];
    if (!links.length) return '<p class="muted small">No links declared for this model.</p>';
    return links.map(function (l) { return '<span class="linklike" title="Opens in the team’s own tool">↗ ' + U.esc(l.kind) + ' — ' + U.esc(l.label) + '</span>'; }).join('');
  }
  function decisionsLog(m) {
    var decisions = [];
    m.kpis.forEach(function (k) { var a = ENGINE.ackOf(m, k); if (a) decisions.push(U.fmtD(a.at) + ' — ' + a.who + ' acknowledged ' + k.code + ': “' + a.rationale + '”'); });
    API.ticketsForModel(m.id).forEach(function (t) {
      t.eventLog.forEach(function (e) { if (/approved|won.?t do|acknowledged|resolved/i.test(e.what)) decisions.push(U.fmtD(e.at) + ' — ' + e.who + ' (' + t.ref + '): ' + e.what); });
    });
    return decisions;
  }
  function evidencePack(m) {
    var tks = API.ticketsForModel(m.id), months = API.meta().months, decisions = decisionsLog(m);
    return '<div class="card evidence-pack">' +
      '<h3>Evidence pack — ' + U.esc(m.name) + '</h3>' +
      '<p class="tiny">Assembled on demand — print-ready. Generated ' + U.esc(API.meta().now) + '.</p>' +
      '<h3>Status &amp; derivation (latest run)</h3><p class="small">' + UI.statusChip(m) + ' ' + UI.ackBadge(m) + '</p>' + UI.derivation(m) +
      '<h3>KPI history (12 runs)</h3><table><thead><tr><th>KPI</th><th>Rule</th>' +
      months.map(function (mo) { return '<th class="tiny">' + U.esc(mo) + '</th>'; }).join('') + '</tr></thead><tbody>' +
      m.kpis.map(function (k) {
        return '<tr><td class="mono">' + U.esc(k.code) + (k.isKey ? ' ' + UI.keytag(k) : '') + '</td><td class="mono tiny">' + U.esc(k.thresholdRule) + '</td>' +
          k.history.map(function (v, i) { return '<td class="tiny" title="' + ENGINE.kst(k, i) + '">' + v + '</td>'; }).join('') + '</tr>';
      }).join('') + '</tbody></table>' +
      '<h3>Work — open &amp; closed</h3>' +
      (tks.length ? '<ul>' + tks.map(function (t) { return '<li class="small">' + U.esc(t.ref) + ' · ' + U.esc(t.title) + ' — ' + U.esc(t.state) + (t.closureEvidence ? '. Closure evidence: ' + U.esc(t.closureEvidence) : '') + '</li>'; }).join('') + '</ul>' : '<p class="muted small">None.</p>') +
      '<h3>Decisions log</h3>' +
      (decisions.length ? '<ul>' + decisions.map(function (d) { return '<li class="small">' + U.esc(d) + '</li>'; }).join('') + '</ul>' : '<p class="muted small">No recorded decisions.</p>') +
      '</div>';
  }

  V.model = function (r) {
    var STATE = window.STATE;
    var m = API.model(r.param);
    if (!m) return '<div class="wrap"><div class="card"><h1>Model</h1><p class="muted">Model not found.</p></div></div>';
    var runs = ENGINE.runsOf(m);
    var sel = r.query && r.query.run ? ENGINE.runById(m, r.query.run) : runs[0];
    var i = sel.index, isLatest = (sel.id === runs[0].id);

    var h = '<div class="wrap">';

    // FRAME — identity + the selected run's status, stamped with which run you're viewing
    h += '<div class="card"><div class="room-head"><div style="flex:1">' +
      '<h1>' + U.esc(m.name) + '</h1>' +
      '<div class="facts">' +
      '<span>Function <b>' + U.esc(m.function) + '</b></span>' +
      '<span>Area <b>' + U.esc(m.businessArea) + '</b></span>' +
      '<span>Type <b>' + U.esc(m.modelType) + '</b></span>' +
      '<span>Materiality <b>' + U.esc(m.materiality) + '</b> (tier ' + U.esc(m.riskTier) + ')</span>' +
      '<span>Next execution <b>' + U.fmtD(m.nextExecution) + '</b> (' + U.daysUntil(m.nextExecution) + 'd)</span>' +
      '<span>Owner <b>' + U.esc(m.accountableOwner) + '</b> · delegate ' + U.esc(m.delegate) + ' · developer ' + U.esc(m.developer) + '</span>' +
      '<span>' + U.esc(m.environment) + '</span>' +
      '</div></div>' +
      '<div style="text-align:right">' +
      '<div class="run-stamp">' + (isLatest ? '<span class="pill-new">LATEST RUN</span>' : '<span class="pill-changed">HISTORICAL</span>') + ' ' + U.esc(sel.period) + '</div>' +
      UI.statusBlock(m, i) + ' ' + (isLatest ? UI.breachChip(m) : '') +
      '</div></div></div>';

    // FRAME — run timeline / navigator + the selected run's metadata
    h += '<section class="card"><h2>Runs</h2>' +
      '<p class="section-note">The model’s RAG across its last 12 runs — select a point to view the model as of that run.</p>' +
      runNav(m, runs, sel) + timeline(m, sel) +
      '<p class="small">' + U.esc(sel.period) + ': ' + U.esc(sel.outcome) + ' · executed ' + U.esc(sel.executedAt) + ' · runtime ' + U.esc(sel.runtime) + ' · ' + U.esc(sel.codeVersion) + ' · ' + U.esc(sel.trigger) + '</p>' +
      (isLatest && m.breach ? '<p class="small"><b>Breach context:</b> ' + U.esc(m.breach.classification) + ' · implicated stage: ' + U.esc(m.breach.stage) + ' · opened ' + U.fmtD(m.breach.openedAt) + '</p>' : '') +
      '</section>';

    // SNAPSHOT — upstream as of the selected run
    h += '<section class="card"><h2>Upstream <span class="tiny muted">as of ' + U.esc(sel.period) + '</span></h2>' +
      '<p class="section-note">Was this a symptom or the source, at this run?</p>' +
      upstreamAt(m, i) + (m.symptomOf ? ' ' + UI.symptomTag(m, true) : '') + '</section>';

    // SNAPSHOT — KPI readings as of the selected run
    h += '<section class="card"><h2>KPIs <span class="tiny muted">as of ' + U.esc(sel.period) + '</span></h2>' +
      '<p class="section-note">Each KPI’s reading at this run — threshold as text, history with this run marked, movement from the run before.</p>' +
      kpiTableAt(m, i) + '</section>';

    // FRAME — work (spans runs)
    h += '<section class="card"><h2>Work</h2>' +
      '<p class="section-note">Tickets span runs — the model’s remediation workflow, not a single execution.</p>' + workTable(m) + '</section>';

    // FRAME — links out
    h += '<section class="card links-out"><h2>Links out</h2>' +
      '<p class="section-note">MPMP surfaces KPI status; detailed monitoring stays in the team’s own tools.</p>' + linksOut(m) + '</section>';

    // FRAME — evidence pack
    var packOpen = !!STATE.packOpen[m.id];
    h += '<section class="card"><h2>Evidence pack</h2>' +
      '<p class="section-note">Assembled on demand — print-ready.</p>' +
      '<button type="button" class="btn" data-action="pack" data-model="' + U.esc(m.id) + '">' + (packOpen ? 'Hide evidence pack' : 'Assemble evidence pack') + '</button>' +
      (packOpen ? evidencePack(m) : '') + '</section>';

    return h + '</div>';
  };
})();
