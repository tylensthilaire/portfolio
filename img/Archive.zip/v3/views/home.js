/* Home — "since you were last here", composed per duty lens.
   Reference view: data via API, status via ENGINE, markup via UI.
   Same data in every lens — the lens changes framing and actions. */
(function () {
  'use strict';
  var V = window.VIEWS = window.VIEWS || {};
  var API = window.API, ENGINE = window.ENGINE, UI = window.UI, U = window.U;

  function ranked() { return ENGINE.exceptions(API.models()).sort(function (a, b) { return ENGINE.score(b) - ENGINE.score(a); }); }

  function exceptionRow(m, ownerAltitude) {
    var k = ENGINE.drivingKpi(m), t = API.openTicketForModel(m.id);
    var driver = k ? '<span class="mono">' + U.esc(k.code) + '</span> ' + UI.keytag(k) + ' ' + UI.chip(ENGINE.kst(k), U.titleCase(ENGINE.kst(k)), k.thresholdRule) : '—';
    var right = ownerAltitude
      ? '<td>' + U.esc(t ? t.assignee + ' · ' + t.ref : m.delegate + ' — to triage') + '</td><td>' + U.esc(t ? U.fmtD(t.byWhen) : (m.breach ? 'SLA ' + m.breach.slaDays + 'd' : '—')) + '</td>'
      : '<td>' + (k ? UI.kpiMove(k) : '') + '</td><td class="tiny">' + U.esc(ENGINE.rankDriver(m)) + '</td>';
    return '<tr><td><a href="#/models/' + m.id + '">' + U.esc(m.name) + '</a> ' + UI.changeTag(m) + ' ' + UI.symptomTag(m) + '</td>' +
      '<td>' + driver + '</td><td>' + U.esc(m.materiality) + '</td>' + right + '</tr>';
  }

  function recentEvents(n) {
    var evts = [];
    API.tickets().forEach(function (t) { t.eventLog.forEach(function (e) { evts.push({ t: t, e: e }); }); });
    evts.sort(function (a, b) { return U.parseD(b.e.at) - U.parseD(a.e.at); });
    var last = API.meta().lastVisit;
    return evts.slice(0, n).map(function (x) {
      var since = U.parseD(x.e.at) >= U.parseD(last);
      return '<li>' + (since ? '<span class="pill-new">SINCE LAST VISIT</span> ' : '') +
        '<span class="t-at">' + U.fmtD(x.e.at) + ' · <a href="#/work/' + U.esc(x.t.ref) + '" class="mono">' + U.esc(x.t.ref) + '</a></span>' +
        '<span class="t-who">' + U.esc(x.e.who) + '</span> — ' + U.esc(x.e.what) + '</li>';
    }).join('');
  }

  function fix() {
    var exs = ranked().slice(0, 4);
    var mine = API.tickets().filter(function (t) { return !API.isTerminal(t); });
    return '<div class="grid-2">' +
      '<section class="card"><h2>Needs triage — top of the queue</h2>' +
      '<p class="section-note">Ranked by materiality × execution proximity. The chain-grouped full list is in <a href="#/triage">Triage</a>.</p>' +
      '<table><thead><tr><th>Model</th><th>Driving KPI</th><th>Materiality</th><th>Movement</th><th>Rank driver</th></tr></thead><tbody>' +
      (exs.length ? exs.map(function (m) { return exceptionRow(m, false); }).join('') : '<tr><td colspan="5" class="muted">Nothing awaiting triage.</td></tr>') + '</tbody></table></section>' +
      '<section class="card"><h2>Open tickets</h2>' +
      '<table><thead><tr><th>Ref</th><th>Model</th><th>State</th><th>By when</th></tr></thead><tbody>' +
      mine.map(function (t) {
        return '<tr><td><a href="#/work/' + U.esc(t.ref) + '" class="mono">' + U.esc(t.ref) + '</a></td><td>' + U.esc(API.model(t.modelId).name) + '</td><td>' + UI.stateChip(t.state) + '</td><td>' + U.fmtD(t.byWhen) + '</td></tr>';
      }).join('') + '</tbody></table></section></div>';
  }

  function review() {
    var exs = ranked();
    var awaiting = API.tickets().filter(function (t) { return t.state === 'Awaiting approval'; });
    var acked = ENGINE.acknowledgedModels(API.models());
    return '<section class="card"><h2>Decisions waiting on you</h2>' +
      (awaiting.length ? '<table><thead><tr><th>Ref</th><th>Model</th><th>Recommendation</th><th>By when</th><th aria-label="Actions"></th></tr></thead><tbody>' +
        awaiting.map(function (t) {
          return '<tr><td class="mono">' + U.esc(t.ref) + '</td><td>' + U.esc(API.model(t.modelId).name) + '</td><td>' + U.esc(t.title) + '</td><td>' + U.fmtD(t.byWhen) + '</td><td><a class="btn btn-gold btn-sm" href="#/work/' + U.esc(t.ref) + '">Decide</a></td></tr>';
        }).join('') + '</tbody></table>' : '<p class="muted">Nothing awaiting approval.</p>') + '</section>' +
      '<div class="grid-2">' +
      '<section class="card"><h2>Models needing attention</h2>' +
      '<p class="section-note">Which need a decision — who’s on it, by when.</p>' +
      '<table><thead><tr><th>Model</th><th>Driving KPI</th><th>Materiality</th><th>Who’s on it</th><th>By when</th></tr></thead><tbody>' +
      (exs.length ? exs.map(function (m) { return exceptionRow(m, true); }).join('') : '<tr><td colspan="5" class="muted">All clear.</td></tr>') + '</tbody></table>' +
      acked.map(function (m) { return '<p class="small"><a href="#/models/' + m.id + '">' + U.esc(m.name) + '</a> ' + UI.ackBadge(m) + '</p>'; }).join('') + '</section>' +
      '<section class="card"><h2>Remediation movement</h2>' +
      '<p class="section-note">Assignee, due date and state for every remediation in flight.</p>' +
      '<ul class="timeline">' + recentEvents(8) + '</ul></section></div>';
  }

  function report() {
    var deltas = API.models().filter(function (m) { return ENGINE.kpiDowngrades(m).length; });
    var awaiting = API.tickets().filter(function (t) { return t.state === 'Awaiting approval'; });
    var acks = ENGINE.acknowledgedModels(API.models());
    return '<div class="grid-2">' +
      '<section class="card"><h2>Portfolio deltas</h2>' +
      '<p class="section-note">Models whose KPIs downgraded run-on-run. The full picture is in the <a href="#/portfolio">Portfolio</a>.</p>' +
      '<table><thead><tr><th>Model</th><th>Status</th><th>Downgraded KPIs</th></tr></thead><tbody>' +
      (deltas.length ? deltas.map(function (m) {
        return '<tr><td><a href="#/models/' + m.id + '">' + U.esc(m.name) + '</a></td><td>' + UI.statusChip(m) + ' ' + UI.ackBadge(m) + '</td><td>' +
          ENGINE.kpiDowngrades(m).map(function (k) { return '<span class="mono">' + U.esc(k.code) + '</span> ' + UI.chip(ENGINE.ragOf(k, k.previous), U.titleCase(ENGINE.ragOf(k, k.previous))) + ' → ' + UI.chip(ENGINE.kst(k), U.titleCase(ENGINE.kst(k)), k.thresholdRule) + ' <span class="tiny">' + U.esc(k.group + ' · ' + k.subGroup) + '</span>'; }).join('<br>') + '</td></tr>';
      }).join('') : '<tr><td colspan="3" class="muted">No run-on-run downgrades.</td></tr>') + '</tbody></table></section>' +
      '<section class="card"><h2>Awaiting challenge</h2>' +
      '<p class="section-note">Owner decisions pending, plus acknowledged risk positions to review.</p>' +
      (awaiting.map(function (t) {
        return '<p class="small"><a href="#/work/' + U.esc(t.ref) + '" class="mono">' + U.esc(t.ref) + '</a> — ' + U.esc(t.title) + ' ' + UI.stateChip(t.state) + '</p>';
      }).join('') || '<p class="muted">No approvals pending.</p>') +
      acks.map(function (m) { return '<p class="small"><a href="#/models/' + m.id + '">' + U.esc(m.name) + '</a> ' + UI.ackBadge(m) + '</p>'; }).join('') + '</section></div>';
  }

  V.home = function () {
    var STATE = window.STATE;
    var body = STATE.lens === 'review' ? review() : STATE.lens === 'report' ? report() : fix();
    return '<div class="wrap"><h1>Since you were last here</h1>' + UI.lastVisitLine() + body + '</div>';
  };
})();
