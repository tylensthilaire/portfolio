/* Triage — the exceptions-only worklist: chain-aware grouping, inline
   triage (severity, materiality, mandatory rationale), and the
   Acknowledged / Disposed record. Reference view: data via API,
   status via ENGINE, markup via UI. */
(function () {
  'use strict';
  var V = window.VIEWS = window.VIEWS || {};
  var API = window.API, ENGINE = window.ENGINE, UI = window.UI, U = window.U;
  var STATE; // bound from window.STATE when V.triage runs; helpers close over it

  // ---------------- chain-aware grouping ----------------
  function buildGroups(list) {
    var byId = {}; list.forEach(function (m) { byId[m.id] = m; });
    var attached = {};
    list.forEach(function (m) { if (m.symptomOf && byId[m.symptomOf]) attached[m.id] = m.symptomOf; });
    var groups = [];
    list.forEach(function (m) {
      if (attached[m.id]) return;
      groups.push({ source: m, symptoms: list.filter(function (x) { return attached[x.id] === m.id; }) });
    });
    groups.sort(function (a, b) { return ENGINE.score(b.source) - ENGINE.score(a.source); });
    return groups;
  }

  // ---------------- inline triage panel (Fix lens only) ----------------
  function upstreamCheckLine(m) {
    var ups = (m.upstream || []).map(function (id) {
      var u = API.model(id);
      if (!u) return '';
      var us = ENGINE.modelStatus(u);
      return U.esc(u.name) + ' ' + UI.chip(us.rag, U.titleCase(us.rag), 'Open its model room');
    }).filter(Boolean).join(' · ');
    var flag = m.symptomOf
      ? ' ' + UI.symptomTag(m, true) + ' — likely explains this exception; attribute upstream rather than investigating locally.'
      : ' No upstream exception is flagged — treat this as the source.';
    return '<p class="small"><b>Upstream check</b> — ' + (ups || 'No upstream dependencies declared.') + flag + '</p>';
  }

  function triagePanel(m) {
    if (STATE.lens !== 'fix') {
      return '<div class="triage"><p class="muted small">Triage sits with the Fix duty — switch the lens to act.</p></div>';
    }
    var sevOpts = ['Low', 'Medium', 'High', 'Critical'].map(function (o) {
      var sel = UI.draft('sev-' + m.id, m.breach ? m.breach.suggestedSeverity : 'Medium') === o;
      return '<option' + (sel ? ' selected' : '') + '>' + o + '</option>';
    }).join('');
    var matOpts = ['Low', 'Medium', 'High', 'Very High'].map(function (o) {
      var sel = UI.draft('mat-' + m.id, m.materiality) === o;
      return '<option' + (sel ? ' selected' : '') + '>' + o + '</option>';
    }).join('');
    var inheritBtn = m.symptomOf
      ? '<button type="button" class="btn" data-action="triage" data-act="inherit" data-model="' + m.id + '">Attribute upstream</button>'
      : '';
    return '<div class="triage" data-form>' +
      upstreamCheckLine(m) +
      (m.breach ? '<p class="small"><b>Breach context</b> — ' + U.esc(m.breach.classification) + ' · stage: ' + U.esc(m.breach.stage) + '</p>' : '') +
      '<div class="triage-grid">' +
      '<div><label for="sev-' + m.id + '">Severity</label><select id="sev-' + m.id + '">' + sevOpts + '</select></div>' +
      '<div><label for="mat-' + m.id + '">Materiality</label><select id="mat-' + m.id + '">' + matOpts + '</select></div>' +
      '<div><label for="rat-' + m.id + '">Rationale (mandatory on every decision)</label>' +
      '<textarea id="rat-' + m.id + '" placeholder="Why this classification and decision…">' + U.esc(UI.draft('rat-' + m.id)) + '</textarea></div>' +
      '</div>' +
      UI.flashMsg('q-' + m.id) +
      '<div class="triage-actions">' +
      inheritBtn +
      '<button type="button" class="btn" data-action="triage" data-act="ack" data-model="' + m.id + '">Acknowledge</button>' +
      '<button type="button" class="btn btn-gold" data-action="triage" data-act="esc" data-model="' + m.id + '">Escalate</button>' +
      '<button type="button" class="btn btn-danger" data-action="triage" data-act="dismiss" data-model="' + m.id + '">Dismiss</button>' +
      '<span class="tiny">' + (m.symptomOf
        ? 'Attribute upstream is the recommended call for an inherited breach — it resurfaces if the symptom persists once the source is resolved.'
        : 'Escalating opens a ticket with an assignee. Dismissing records this as not a genuine breach.') + '</span>' +
      '</div></div>';
  }

  // ---------------- worklist row ----------------
  function queueRow(m, isSymptom) {
    var k = ENGINE.drivingKpi(m);
    var qOpen = STATE.open['q-' + m.id];
    var derivOpen = STATE.open['deriv-' + m.id];
    var age = m.breach ? U.ageOf(m.breach.openedAt) : '—';
    var overdue = m.breach && (U.parseD(API.meta().now) - U.parseD(m.breach.openedAt)) / 864e5 > m.breach.slaDays;
    var driver = k
      ? '<span class="mono">' + U.esc(k.code) + '</span> ' + U.esc(k.name) + ' ' + UI.keytag(k) + ' — ' + k.latest + ' ' + U.esc(k.unit) +
        ' vs rule <span class="mono" title="' + U.esc(k.thresholdRule) + '">' + U.esc(k.thresholdRule) + '</span>'
      : '—';
    var doneNote = (m.triage && m.triage.action === 'Escalated')
      ? ' <span class="done-note">Escalated → <a href="#/work/' + U.esc(m.triage.ref) + '">' + U.esc(m.triage.ref) + '</a></span>'
      : '';
    var h = '<div class="q-row' + (isSymptom ? ' symptom' : '') + '">' +
      '<div class="q-head">' +
      (isSymptom ? UI.symptomTag(m, true) + ' ' : '') +
      '<span class="name"><a href="#/models/' + m.id + '">' + U.esc(m.name) + '</a></span> ' + UI.changeTag(m) + ' ' +
      UI.statusChip(m) + ' ' + UI.expander('deriv-' + m.id, 'Why', derivOpen) + doneNote +
      '<span class="q-expand">' + UI.expander('q-' + m.id, qOpen ? 'Close triage' : 'Triage', qOpen) + '</span>' +
      '</div>' +
      (derivOpen ? UI.derivation(m) : '') +
      '<p class="q-why">' + driver + '</p>' +
      '<div class="q-meta">' +
      '<span' + (overdue ? ' class="overdue"' : '') + '>Age ' + age + ' · SLA ' + (m.breach ? m.breach.slaDays + 'd' + (overdue ? ' — overdue' : '') : '—') + '</span>' +
      '<span>Movement: ' + (k ? UI.kpiMove(k) : '—') + '</span>' +
      '<span>' + U.esc(ENGINE.rankDriver(m)) + '</span>' +
      '</div>';
    if (qOpen) h += triagePanel(m);
    return h + '</div>';
  }

  // ---------------- below-the-queue records ----------------
  function ackedSection() {
    var acked = ENGINE.acknowledgedModels(API.models());
    if (!acked.length) return '<p class="muted small">No acknowledged exceptions right now.</p>';
    return acked.map(function (m) {
      return '<div class="q-row"><div class="q-head"><span class="name"><a href="#/models/' + m.id + '">' + U.esc(m.name) + '</a></span> ' +
        UI.statusChip(m) + ' ' + UI.ackBadge(m) + '</div></div>';
    }).join('');
  }

  function disposedSection() {
    var disposed = API.models().filter(function (m) {
      var bs = ENGINE.breachState(m);
      return bs === 'dismissed' || bs === 'inherited';
    });
    if (!disposed.length) return '<p class="muted small">Nothing dismissed or attributed upstream yet this session.</p>';
    return disposed.map(function (m) {
      return '<div class="q-row"><div class="q-head"><span class="name"><a href="#/models/' + m.id + '">' + U.esc(m.name) + '</a></span> ' +
        UI.breachChip(m) + '</div><p class="small muted">“' + U.esc(m.triage.rationale) + '”</p></div>';
    }).join('');
  }

  V.triage = function (r) {
    STATE = window.STATE;
    var q = r.query || {};
    var allExceptions = ENGINE.exceptions(API.models());
    var shown = UI.filterModels(allExceptions, q);
    var groups = buildGroups(shown);

    var h = '<div class="wrap"><h1>Triage</h1>' +
      '<p class="section-note">Exceptions only, ranked by materiality and how soon each model next runs. A source breach carries its downstream symptoms with it — dispose of each with a recorded reason.</p>' +
      UI.filterBar(['fn', 'tier', 'rag', 'owner'], q) +
      UI.reconcile(shown.length, allExceptions.length, 'in the triage queue');

    if (!allExceptions.length) {
      h += '<p class="card muted">No open exceptions — the estate is clear or everything has already been triaged.</p>';
    } else if (!groups.length) {
      h += '<p class="card muted">No exceptions match these filters.</p>';
    } else {
      groups.forEach(function (g) {
        h += '<div class="q-group">' + queueRow(g.source, false) +
          g.symptoms.map(function (m) { return queueRow(m, true); }).join('') + '</div>';
      });
    }

    h += '<h2>Acknowledged</h2><p class="section-note">Accepted risk positions stay visible here, not hidden from the queue.</p>' + ackedSection();
    h += '<h2>Disposed this session</h2><p class="section-note">Breaches dismissed as false reds, or attributed to an upstream source — each with a recorded reason.</p>' + disposedSection();

    return h + '</div>';
  };
})();
