/* Model catalogue — the browsable index of the estate. Read-only: where you
   open a model from, not act on one. Supports an "as of a month" mode (?asOf=)
   reached from the portfolio trend: it shows each model's status that month
   and links each card to the run behind it.
   Data via API, status via ENGINE, markup via UI. */
(function () {
  'use strict';
  var V = window.VIEWS = window.VIEWS || {};
  var API = window.API, ENGINE = window.ENGINE, UI = window.UI, U = window.U;

  var STATUS_ORDER = { red: 0, amber: 1, ack: 2, green: 3 };
  var MAT_ORDER = { 'Very High': 0, 'High': 1, 'Medium': 2, 'Low': 3 };

  function statusOf(m, asOf) { return asOf != null ? ENGINE.dispStatusAt(m, asOf) : ENGINE.dispStatus(m); }
  function sorted(list, asOf) {
    return list.slice().sort(function (a, b) {
      return STATUS_ORDER[statusOf(a, asOf)] - STATUS_ORDER[statusOf(b, asOf)] ||
        MAT_ORDER[a.materiality] - MAT_ORDER[b.materiality] || a.name.localeCompare(b.name);
    });
  }

  function card(m, asOf) {
    var st = statusOf(m, asOf);
    var href = asOf != null ? '#/models/' + U.esc(m.id) + '?run=' + U.esc(m.id + '-' + asOf) : '#/models/' + U.esc(m.id);
    var d = U.daysUntil(m.nextExecution);
    var foot = asOf != null
      ? 'Run: ' + U.esc(ENGINE.monthYear(asOf)) + ' — opens the run behind this'
      : 'Next execution ' + U.fmtD(m.nextExecution) + ' (' + (d <= 0 ? 'today' : 'in ' + d + 'd') + ')';
    return '<a class="cat-card rag-' + st + '" href="' + href + '">' +
      '<div class="cn">' + U.esc(m.name) + '</div>' +
      '<div class="cm"><span class="mono">' + U.esc(m.id) + '</span> · ' + U.esc(m.function) + ' · ' + U.esc(m.businessArea) + '</div>' +
      '<p class="small" style="margin:var(--s-2) 0">' + (asOf == null ? UI.changeTag(m) + ' ' : '') + UI.statusChip(m, asOf) + ' ' + UI.ackBadge(m) + ' ' + UI.symptomTag(m) + '</p>' +
      '<p class="tiny muted" style="margin:0">' + U.esc(m.materiality) + ' materiality (tier ' + U.esc(m.riskTier) + ') · owner ' + U.esc(m.accountableOwner) + '<br>' + foot + '</p>' +
      '</a>';
  }

  V.models = function (r) {
    var META = API.meta(), q = r.query || {};
    var asOf = (q.asOf != null && q.asOf !== '') ? +q.asOf : null;
    var all = API.models();
    var list = sorted(UI.filterModels(all, q), asOf);
    var extra = ENGINE.exceptions(list).length + ' need attention';

    var head = asOf != null
      ? '<h1>Model catalogue</h1><p class="section-note">Showing the estate <b>as of ' + U.esc(ENGINE.monthYear(asOf)) + '</b> — the models behind that trend point. Open one to see the run behind it. <a href="#/models">Back to now</a>.</p>'
      : '<h1>Model catalogue</h1><p class="section-note">You’re authorised for the ' + all.length + ' models shown — the full estate runs to roughly ' + META.estateTotal + '.</p>';

    return '<div class="wrap">' + head +
      UI.filterBar(['fn', 'tier', 'rag', 'owner', 'q'], q) +
      UI.reconcile(list.length, all.length, extra) +
      (list.length
        ? '<div class="cat-grid">' + list.map(function (m) { return card(m, asOf); }).join('') + '</div>'
        : '<p class="muted">No models match these filters. Use <b>Clear all</b> in the filter bar above to start over.</p>') +
      '</div>';
  };
})();
