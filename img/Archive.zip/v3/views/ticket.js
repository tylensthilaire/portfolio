/* Work item — one ticket per breach, moved forward-only through its states.
   Investigation and remediation are phases of the same record. Evidence is
   assembled for the analyst to conclude (no machine diagnosis); a clean re-run
   is the proof; rework raises a subtask rather than moving the ticket back.
   Data via API, status via ENGINE, markup via UI. */
(function () {
  'use strict';
  var V = window.VIEWS = window.VIEWS || {};
  var API = window.API, ENGINE = window.ENGINE, UI = window.UI, U = window.U;

  function lensPanel(key, label, items) {
    var open = window.STATE.open[key] !== false;
    return '<div class="lens-panel"><button type="button" class="btn btn-ghost btn-sm" data-action="expand" data-key="' + U.esc(key) + '" data-def="1" aria-expanded="' + open + '">' + U.esc(label) + (open ? ' ▴' : ' ▾') + '</button>' +
      (open ? '<div class="lens-body"><ul>' + items.map(function (i) { return '<li>' + i + '</li>'; }).join('') + '</ul></div>' : '') + '</div>';
  }
  function kpiLine(k) {
    return '<span class="mono">' + U.esc(k.code) + '</span> ' + U.esc(k.name) + ': ' + k.latest + ' ' + U.esc(k.unit) + ' ' +
      UI.chip(ENGINE.kst(k), U.titleCase(ENGINE.kst(k)), k.thresholdRule) + ' ' + UI.kpiMove(k) + ' ' + UI.spark(k);
  }
  function dataFactors(m) {
    var items = m.kpis.filter(function (k) { return k.metricType === 'dq'; }).map(kpiLine);
    (m.upstream || []).forEach(function (uid) {
      var u = API.model(uid); if (!u) return; var us = ENGINE.modelStatus(u);
      items.push('Upstream <a href="#/models/' + uid + '">' + U.esc(u.name) + '</a>: ' + UI.chip(us.rag, U.titleCase(us.rag)) + (us.hasAck ? ' (acknowledged position)' : ''));
    });
    if (m.notes) items.push('Feed / data note: ' + U.esc(m.notes));
    if (!items.length) items.push('No data-quality KPIs or upstream feeds flagged.');
    return items;
  }
  function modelFactors(m) {
    var items = m.kpis.filter(function (k) { return k.metricType === 'perf'; }).map(kpiLine);
    var vs = m.runs.map(function (rn) { return rn.codeVersion; });
    items.push(vs[0] === vs[vs.length - 1]
      ? 'Run deltas: code version unchanged across the last ' + m.runs.length + ' runs (' + U.esc(vs[0]) + ') — the change sits in the population or inputs, not the code.'
      : 'Run deltas: code version moved ' + U.esc(vs[vs.length - 1]) + ' → ' + U.esc(vs[0]) + ' across the last ' + m.runs.length + ' runs — check the release.');
    if (!items.length) items.push('No performance KPIs flagged.');
    return items;
  }
  function processFactors(m) {
    var items = [];
    API.ticketsForModel(m.id).forEach(function (t) {
      var e = t.eventLog[t.eventLog.length - 1];
      items.push('Work item <span class="mono">' + U.esc(t.ref) + '</span> (' + U.esc(t.state) + '): ' + U.esc(e.what));
    });
    items.push('Last run trigger: ' + U.esc(m.lastRun.trigger) + ' · environment ' + U.esc(m.environment) + '.');
    items.push('Declared breach context: ' + U.esc(m.breach ? m.breach.classification + ', ' + m.breach.stage : 'none for this cycle') + '.');
    return items;
  }

  // Investigation: evidence assembly + the analyst's conclusion (Open / Investigating)
  function investigationPanel(t, m) {
    var h = '<section class="card"><h2>Investigation — evidence assembly</h2>' +
      '<p class="section-note">Three lenses organise the evidence; the analyst authors the conclusion.</p>';
    h += lensPanel('data-' + t.ref, 'Data factors', dataFactors(m));
    h += lensPanel('model-' + t.ref, 'Model factors', modelFactors(m));
    h += lensPanel('proc-' + t.ref, 'Process factors', processFactors(m));
    h += '<p class="small links-out" style="margin-top:8px"><b>Links out:</b> ' + m.linksOut.map(function (l) {
      return '<span class="linklike" title="Opens in the team’s own tool">↗ ' + U.esc(l.kind) + ' — ' + U.esc(l.label) + '</span>';
    }).join(' ') + '</p>';

    if (window.STATE.lens === 'fix') {
      var catOpts = ['Data', 'Model', 'Process'].map(function (o) { return '<option' + (UI.draft('cat-' + t.ref, t.category || 'Model') === o ? ' selected' : '') + '>' + o + '</option>'; }).join('');
      var impOpts = ['Low', 'Medium', 'High'].map(function (o) { return '<option' + (UI.draft('imp-' + t.ref, 'Medium') === o ? ' selected' : '') + '>' + o + '</option>'; }).join('');
      h += '<div data-form><h3>Conclusion</h3>' +
        '<label for="conc-' + U.esc(t.ref) + '">Root cause (your words)</label>' +
        '<textarea id="conc-' + U.esc(t.ref) + '" placeholder="The system assembles, you conclude…">' + U.esc(UI.draft('conc-' + t.ref)) + '</textarea>' +
        '<div class="triage-grid" style="margin-top:10px">' +
        '<div><label for="imp-' + U.esc(t.ref) + '">Impact</label><select id="imp-' + U.esc(t.ref) + '">' + impOpts + '</select></div>' +
        '<div><label for="cat-' + U.esc(t.ref) + '">Category</label><select id="cat-' + U.esc(t.ref) + '">' + catOpts + '</select></div>' +
        '<div><label for="act-' + U.esc(t.ref) + '">Recommended fix</label><input type="text" id="act-' + U.esc(t.ref) + '" value="' + U.esc(UI.draft('act-' + t.ref)) + '" placeholder="e.g. Recalibrate segment weights"></div>' +
        '</div>' +
        '<div style="max-width:220px;margin-top:10px"><label for="tl-' + U.esc(t.ref) + '">By when</label><input type="date" id="tl-' + U.esc(t.ref) + '" value="' + U.esc(UI.draft('tl-' + t.ref, U.addDays(API.meta().today, 14))) + '"></div>' +
        UI.flashMsg('inv-' + t.ref) +
        '<div class="triage-actions">' +
        '<button type="button" class="btn btn-gold" data-action="conclude" data-act="file" data-ref="' + U.esc(t.ref) + '">File fix for approval</button>' +
        '<button type="button" class="btn" data-action="conclude" data-act="now" data-ref="' + U.esc(t.ref) + '">Fixed in-window — validate</button>' +
        '<span class="tiny">A material fix goes for owner approval; a quick in-window fix goes straight to a validation re-run — the clean run is the sign-off.</span>' +
        '</div></div>';
    } else {
      h += '<p class="muted small">Investigation and the conclusion sit with the Fix duty — switch the lens.</p>';
    }
    h += '<p class="footnote">Evidence assembled by the system; the conclusion is yours.</p>';
    return h + '</section>';
  }

  function ticketActions(t, m) {
    var lens = window.STATE.lens, h = '';
    if (t.state === 'Awaiting approval') {
      if (lens === 'review') {
        h += '<section class="card" data-form><h2>Owner decision</h2>' +
          '<p class="small">Recommended fix: <b>' + U.esc(t.action || t.title) + '</b>' + (t.impact ? ' · impact ' + U.esc(t.impact) : '') + (t.category ? ' · ' + U.esc(t.category) : '') + '</p>' +
          '<label for="note-' + U.esc(t.ref) + '">Audit note (mandatory)</label>' +
          '<textarea id="note-' + U.esc(t.ref) + '" placeholder="Why this decision…">' + U.esc(UI.draft('note-' + t.ref)) + '</textarea>' +
          UI.flashMsg('tk-' + t.ref) +
          '<div class="triage-actions">' +
          '<button type="button" class="btn btn-gold" data-action="tk" data-act="approve" data-ref="' + U.esc(t.ref) + '">Approve</button>' +
          '<button type="button" class="btn btn-danger" data-action="tk" data-act="wontdo" data-ref="' + U.esc(t.ref) + '">Won’t do</button>' +
          '</div></section>';
      } else {
        h += '<section class="card"><p class="muted small">Awaiting the Review duty’s decision — switch the lens.</p></section>';
      }
    }
    if (t.state === 'In progress') {
      h += (lens === 'fix')
        ? '<section class="card"><h2>Implementation</h2><p class="small">Implemented? Run the validation to get a post-fix reading.</p>' +
          '<button type="button" class="btn" data-action="tk" data-act="validate" data-ref="' + U.esc(t.ref) + '">Simulate validation re-run</button></section>'
        : '<section class="card"><p class="muted small">In implementation with the Fix duty (' + U.esc(t.assignee) + '). Switch the lens to validate.</p></section>';
    }
    if (t.state === 'Validating' && t.validation) {
      var subs = API.subtasksOf(t.ref);
      var openSub = subs.filter(function (s) { return !API.isTerminal(s); });
      h += '<section class="card"><h2>Validation re-run</h2>' +
        '<div class="validation-box">' + U.esc(t.validation.kpi) + ': ' + t.validation.before + ' → <b>' + t.validation.after + '</b> — inside the green threshold.</div>';
      if (subs.length) h += '<p class="small" style="margin-top:8px">Subtasks: ' + subs.map(function (s) { return '<a href="#/work/' + U.esc(s.ref) + '" class="mono">' + U.esc(s.ref) + '</a> ' + UI.stateChip(s.state); }).join(' · ') + '</p>';
      if (lens === 'fix') {
        h += '<div class="triage-actions"><button type="button" class="btn btn-gold" data-action="tk" data-act="resolve" data-ref="' + U.esc(t.ref) + '"' + (openSub.length ? ' disabled title="Resolve the open subtask first"' : '') + '>Resolve — clean re-run</button></div>' +
          '<div data-form style="margin-top:10px"><label for="sub-' + U.esc(t.ref) + '">Re-run didn’t clear it? Raise a subtask — the ticket stays parked here, it doesn’t move back</label>' +
          '<textarea id="sub-' + U.esc(t.ref) + '" placeholder="What the re-run didn’t clear…">' + U.esc(UI.draft('sub-' + t.ref)) + '</textarea>' +
          UI.flashMsg('sub-' + t.ref) +
          '<div class="triage-actions"><button type="button" class="btn btn-ghost" data-action="tk" data-act="subtask" data-ref="' + U.esc(t.ref) + '">Raise a subtask</button></div></div>';
      } else {
        h += '<p class="muted small">Resolve / raise-a-subtask sits with the Fix duty — switch the lens.</p>';
      }
      h += '</section>';
    }
    return h;
  }

  V.ticket = function (r) {
    var t = API.ticket(r.param);
    if (!t) return '<div class="wrap"><div class="card"><h1>Work item</h1><p class="muted">Work item not found.</p><p><a href="#/work">← Work</a></p></div></div>';
    var m = API.model(t.modelId);
    var parent = t.parentRef ? API.ticket(t.parentRef) : null;

    var h = '<div class="wrap">' +
      '<p class="small"><a href="#/work">← Work</a></p>' +
      '<div class="card"><h1><span class="mono" style="font-size:20px">' + U.esc(t.ref) + '</span> · ' + U.esc(t.title) + '</h1>' +
      (parent ? '<p class="small">Subtask of <a href="#/work/' + U.esc(parent.ref) + '" class="mono">' + U.esc(parent.ref) + '</a></p>' : '') +
      '<div class="q-meta">' +
      '<span>' + (t.category ? U.esc(t.category) + ' · ' : '') + UI.stateChip(t.state) + '</span>' +
      '<span>Model: <a href="#/models/' + m.id + '">' + U.esc(m.name) + '</a> ' + UI.statusChip(m) + '</span>' +
      '<span>Assignee: ' + U.esc(t.assignee) + '</span><span>By when: ' + U.fmtD(t.byWhen) + '</span></div>' +
      (t.closureEvidence ? '<div class="validation-box"><b>Closure:</b> ' + U.esc(t.closureEvidence) + '</div>' : '') +
      '</div>';

    if (['Open', 'Investigating'].indexOf(t.state) >= 0) h += investigationPanel(t, m);
    h += ticketActions(t, m);

    h += '<section class="card"><h2>Event log</h2><ul class="timeline">' +
      t.eventLog.map(function (e) { return '<li><span class="t-at">' + U.fmtD(e.at) + '</span><span class="t-who">' + U.esc(e.who) + '</span> — ' + U.esc(e.what) + '</li>'; }).join('') +
      '</ul></section></div>';
    return h;
  };
})();
