/* Work — cross-model ticket list: every investigation and remediation, one table.
   Reference view: data via API, status via ENGINE, markup via UI.
   Same data in every lens — the lens only changes which CTA a row gets. */
(function () {
  'use strict';
  var V = window.VIEWS = window.VIEWS || {};
  var API = window.API, ENGINE = window.ENGINE, UI = window.UI, U = window.U;

  function lastMove(t) {
    var e = t.eventLog[t.eventLog.length - 1];
    return e ? U.fmtD(e.at) + ' — ' + U.esc(e.what) : '—';
  }

  function legend() {
    var states = ENGINE.WORK_STATES;
    return '<div class="card states-legend">' + Object.keys(states).map(function (st) {
      return UI.stateChip(st) + ' <span class="small muted">' + U.esc(states[st].meaning) + '</span>';
    }).join('') + '</div>';
  }

  function cta(t, lens) {
    return (t.state === 'Awaiting approval' && lens === 'review')
      ? '<a class="btn btn-gold btn-sm" href="#/work/' + U.esc(t.ref) + '">Decide</a>'
      : '<a class="btn btn-ghost btn-sm" href="#/work/' + U.esc(t.ref) + '">Open</a>';
  }

  function row(t, lens) {
    var m = API.model(t.modelId);
    return '<tr><td><a class="mono" href="#/work/' + U.esc(t.ref) + '">' + U.esc(t.ref) + '</a></td>' +
      '<td><a href="#/models/' + m.id + '">' + U.esc(m.name) + '</a></td>' +
      '<td>' + U.esc(t.assignee) + '</td>' +
      '<td>' + U.fmtD(t.byWhen) + '</td>' +
      '<td>' + UI.stateChip(t.state) + '</td>' +
      '<td class="small">' + lastMove(t) + '</td>' +
      '<td>' + cta(t, lens) + '</td></tr>';
  }

  V.work = function (r) {
    var STATE = window.STATE;
    var order = ENGINE.WORK_ORDER;
    var tks = API.tickets().slice().sort(function (a, b) {
      var ia = order.indexOf(a.state), ib = order.indexOf(b.state);
      if (ia < 0) ia = order.length;
      if (ib < 0) ib = order.length;
      return ia - ib;
    });
    return '<div class="wrap"><h1>Work</h1>' +
      '<p class="section-note">Investigations and remediations as tracked tickets — assignee, by-when, state. The lifecycle is the record: closed tickets show what was fixed, and when.</p>' +
      legend() +
      '<div class="card" style="padding:0;overflow-x:auto"><table><thead><tr><th>Ref</th><th>Model</th><th>Assignee</th><th>By when</th><th>State</th><th>Last movement</th><th aria-label="Actions"></th></tr></thead><tbody>' +
      (tks.length ? tks.map(function (t) { return row(t, STATE.lens); }).join('') : '<tr><td colspan="7" class="muted">No tickets on the estate.</td></tr>') +
      '</tbody></table></div></div>';
  };
})();
