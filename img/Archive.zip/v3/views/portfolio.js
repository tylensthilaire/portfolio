/* Portfolio — the estate view. Lineage first (trouble propagates
   left to right), then KPI-tier counts, the risk-tier stack,
   deterioration, a 12-month trend, concentration by owner, and an
   indicative exec summary.
   Same seams as every other view: data via API, status via ENGINE,
   markup via UI. */
(function () {
  'use strict';
  var V = window.VIEWS = window.VIEWS || {};
  var API = window.API, ENGINE = window.ENGINE, UI = window.UI, U = window.U;

  // ---------------- (a) lineage — connected components over upstream edges ----------------
  function lineageSection(ms) {
    var inSet = {}; ms.forEach(function (m) { inSet[m.id] = true; });
    var parent = {};
    function find(x) { while (parent[x] !== x) { parent[x] = parent[parent[x]]; x = parent[x]; } return x; }
    ms.forEach(function (m) { parent[m.id] = m.id; });
    ms.forEach(function (m) {
      (m.upstream || []).forEach(function (u) { if (inSet[u]) parent[find(u)] = find(m.id); });
    });
    var comps = {};
    ms.forEach(function (m) { var root = find(m.id); (comps[root] = comps[root] || []).push(m); });
    function depth(m, seen) {
      seen = seen || {};
      var ups = (m.upstream || []).filter(function (u) { return inSet[u] && !seen[u]; });
      if (!ups.length) return 0;
      return 1 + Math.max.apply(null, ups.map(function (u) { seen[u] = 1; return depth(API.model(u), seen); }));
    }
    var chains = [], standalone = [];
    Object.keys(comps).forEach(function (root) {
      if (comps[root].length === 1) standalone.push(comps[root][0]); else chains.push(comps[root]);
    });
    function node(m) {
      var s = ENGINE.modelStatus(m);
      return '<a class="lnode rag-' + s.rag + '" href="#/models/' + m.id + '"><span class="ln-name">' + U.esc(m.name) + '</span> ' + UI.statusChip(m) +
        (s.hasAck ? '<br>' + UI.ackBadge(m) : '') +
        '<div class="ln-meta">' + U.esc(m.function) + ' · ' + U.esc(m.materiality) + '</div>' + UI.symptomTag(m) + '</a>';
    }
    var h = '<section class="card"><h2>Lineage — which models feed which</h2>' +
      '<p class="section-note">How trouble propagates across the estate — dependencies first.</p>';
    chains.forEach(function (comp) {
      var cols = [];
      comp.forEach(function (m) { var d = depth(m); (cols[d] = cols[d] || []).push(m); });
      h += '<div class="chain-row">' + cols.map(function (col) {
        return '<div class="chain-col">' + col.map(node).join('') + '</div>';
      }).join('<span class="chain-arrow" aria-hidden="true">→</span>') + '</div>';
    });
    if (standalone.length) h += '<h3>No declared lineage</h3><div class="standalone-grid">' + standalone.map(node).join('') + '</div>';
    if (!chains.length && !standalone.length) h += '<p class="muted small">No models in the current filter.</p>';
    return h + '</section>';
  }

  // ---------------- (b) KPI-tier counts, acknowledged split out ----------------
  function honestNumbers(ms) {
    var c = { key: { red: 0, amber: 0, green: 0 }, non: { red: 0, amber: 0, green: 0 }, ack: 0 };
    ms.forEach(function (m) {
      m.kpis.forEach(function (k) {
        if (ENGINE.ackOf(m, k) && ENGINE.kst(k) !== 'green') { c.ack++; return; }
        c[k.isKey ? 'key' : 'non'][ENGINE.kst(k)]++;
      });
    });
    var total = c.key.red + c.key.amber + c.key.green + c.non.red + c.non.amber + c.non.green + c.ack;
    var pctStyle = 'display:block;font-size:var(--size-tiny);color:var(--ink-500);font-weight:700';
    function share(n) { return total ? U.pct(n / total) : '0%'; }
    function tiles(o, lbl) {
      return ['red', 'amber', 'green'].map(function (rg) {
        return '<div class="count-tile rag-' + rg + '"><span class="n">' + o[rg] + '</span><span class="pct" style="' + pctStyle + '">' + share(o[rg]) + '</span><span class="lbl">' + lbl + ' ' + rg + '</span></div>';
      }).join('');
    }
    return '<section class="card"><h2>KPI status counts</h2>' +
      '<p class="section-note">Key vs non-key KPI statuses, with acknowledged positions counted separately — each tile as a share of all ' + total + ' KPIs.</p>' +
      '<div class="tier-counts">' + tiles(c.key, 'Key') + tiles(c.non, 'Non-key') +
      '<div class="count-tile ackd"><span class="n">' + c.ack + '</span><span class="pct" style="' + pctStyle + '">' + share(c.ack) + '</span><span class="lbl">Acknowledged</span></div>' +
      '<div class="count-tile" style="border-width:2px;border-color:var(--ink-300)"><span class="n">' + total + '</span><span class="pct" style="' + pctStyle + '">100%</span><span class="lbl">Total KPIs</span></div>' +
      '</div></section>';
  }

  // ---------------- (c) risk-tier stack — segments link through to the catalogue ----------------
  function tierStack(ms) {
    var tiers = ['VH', 'H', 'M', 'L'];
    var TIER_NAME = { VH: 'Very High', H: 'High', M: 'Medium', L: 'Low' };
    function segHref(tier, rg) {
      return '#/models?tier=' + tier + '&rag=' + rg;
    }
    var h = '<section class="card"><h2>Risk-tier stack</h2>' +
      '<p class="section-note">Each segment opens the models behind it.</p>';
    tiers.forEach(function (tier) {
      var tms = ms.filter(function (m) { return m.riskTier === tier; });
      if (!tms.length) { h += '<div class="stack-row"><span class="tier-lbl">' + tier + '</span><span class="tiny muted">No models in this tier for the current filters.</span></div>'; return; }
      var segs = ['red', 'amber', 'ack', 'green'].map(function (st) {
        var n = tms.filter(function (m) { return ENGINE.dispStatus(m) === st; }).length;
        if (!n) return '';
        var word = st === 'ack' ? 'acknowledged' : st;
        var aria = n + ' ' + word + ', ' + TIER_NAME[tier] + ' tier — open in catalogue';
        return '<a class="seg rag-' + st + '" style="flex:' + n + '" href="' + segHref(tier, st) + '" aria-label="' + U.esc(aria) + '" title="' + n + ' ' + word + ' — view in the model catalogue">' + n + (st === 'ack' ? ' ack' : '') + '</a>';
      }).join('');
      h += '<div class="stack-row"><span class="tier-lbl">' + tier + ' <span class="tiny">(' + tms.length + ')</span></span><div class="stack-bar">' + segs + '</div></div>';
    });
    return h + '</section>';
  }

  // ---------------- (d) deterioration — downgrades, ranked, chain-grouped ----------------
  function deterioration(ms) {
    var det = ms.filter(function (m) { return ENGINE.kpiDowngrades(m).length; })
      .sort(function (a, b) { return ENGINE.score(b) - ENGINE.score(a); });
    var ids = {}; det.forEach(function (m) { ids[m.id] = true; });
    var rows = [];
    det.forEach(function (m) { if (!(m.symptomOf && ids[m.symptomOf])) rows.push(m); });
    var h = '<section class="card"><h2>Deterioration</h2>' +
      '<p class="section-note">Models whose KPIs downgraded run-on-run — ranked by materiality and how soon they next execute, with symptoms grouped under their source model.</p>';
    function row(m, sym) {
      return '<div class="q-row' + (sym ? ' symptom' : '') + '"><div class="q-head">' + UI.symptomTag(m) +
        '<span class="name"><a href="#/models/' + m.id + '">' + U.esc(m.name) + '</a></span> ' + UI.changeTag(m) + ' ' + UI.statusChip(m) + ' ' + UI.ackBadge(m) +
        '<span class="tiny" style="margin-left:auto">' + U.esc(ENGINE.rankDriver(m)) + '</span></div>' +
        '<p class="q-why">' + ENGINE.kpiDowngrades(m).map(function (k) {
          return '<span class="mono">' + U.esc(k.code) + '</span> ' + UI.chip(ENGINE.ragOf(k, k.previous), U.titleCase(ENGINE.ragOf(k, k.previous))) + ' → ' +
            UI.chip(ENGINE.kst(k), U.titleCase(ENGINE.kst(k)), k.thresholdRule) + ' (' + k.previous + ' → ' + k.latest + ' ' + U.esc(k.unit) + ') <span class="tiny">' + U.esc(k.group + ' · ' + k.subGroup) + '</span>';
        }).join(' · ') + '</p></div>';
    }
    rows.forEach(function (m) {
      h += row(m, false);
      det.forEach(function (x) { if (x.symptomOf === m.id) h += row(x, true); });
    });
    if (!rows.length) h += '<p class="muted small">No run-on-run downgrades.</p>';
    return h + '</section>';
  }

  // ---------------- (e) 12-month trend — month-end R/A/G model counts ----------------
  function trendSection(ms) {
    var series = { red: [], amber: [], green: [] };
    for (var i = 0; i < 12; i++) {
      var c = { red: 0, amber: 0, green: 0 };
      ms.forEach(function (m) { c[ENGINE.modelStatus(m, i).rag]++; });
      series.red.push(c.red); series.amber.push(c.amber); series.green.push(c.green);
    }
    var W = 640, H = 170, max = ms.length || 1;
    var months = API.meta().months;
    function px(i) { return 40 + i * ((W - 60) / 11); }
    function py(v) { return H - 30 - (v / max) * (H - 50); }
    function line(vals, colour) {
      var pts = vals.map(function (v, i) { return px(i) + ',' + py(v); }).join(' ');
      return '<polyline points="' + pts + '" fill="none" stroke="' + colour + '" stroke-width="2.5"/>';
    }
    function markers(vals, colour, rag) {
      return vals.map(function (v, i) {
        var tip = months[i] + ': ' + series.red[i] + ' red · ' + series.amber[i] + ' amber · ' + series.green[i] + ' green — open the ' + rag + ' models';
        return '<a href="#/models?asOf=' + i + '&rag=' + rag + '" aria-label="' + U.esc(months[i] + ' — ' + v + ' ' + rag + ' models') + '">' +
          '<circle cx="' + px(i) + '" cy="' + py(v) + '" r="4" fill="' + colour + '" stroke="var(--card)" stroke-width="1"><title>' + U.esc(tip) + '</title></circle></a>';
      }).join('');
    }
    var labels = months.map(function (mo, i) {
      return '<text x="' + px(i) + '" y="' + (H - 10) + '" font-size="10" fill="var(--ink-400)" text-anchor="middle">' + U.esc(mo) + '</text>';
    }).join('');
    return '<section class="card"><h2>12-month trend</h2>' +
      '<svg width="100%" viewBox="0 0 ' + W + ' ' + H + '" role="img" aria-label="Month-end red, amber and green model counts over 12 months">' +
      '<line x1="40" y1="' + (H - 30) + '" x2="' + (W - 20) + '" y2="' + (H - 30) + '" stroke="var(--ink-200)"/>' +
      line(series.green, 'var(--rag-green-solid)') + line(series.amber, 'var(--rag-amber-solid)') + line(series.red, 'var(--rag-red-solid)') +
      markers(series.green, 'var(--rag-green-solid)', 'green') + markers(series.amber, 'var(--rag-amber-solid)', 'amber') + markers(series.red, 'var(--rag-red-solid)', 'red') +
      labels + '</svg>' +
      '<div class="legend"><span><span class="dot rag-red"></span>Red</span><span><span class="dot rag-amber"></span>Amber (incl. acknowledged)</span><span><span class="dot rag-green"></span>Green</span></div>' +
      '<p class="tiny">Aggregation rule under review — each point uses the same derivation as the status chips. Click a point to open that month’s models — and from there the run behind each.</p></section>';
  }

  // ---------------- (f) concentration — by accountable owner and by model type ----------------
  function concentrationBy(ms, keyOf, title, note) {
    var by = {};
    ms.forEach(function (m) { var k = keyOf(m); (by[k] = by[k] || []).push(m); });
    var keys = Object.keys(by).sort(function (a, b) { return by[b].length - by[a].length; });
    var max = keys.length ? by[keys[0]].length : 1;
    return '<section class="card"><h2>' + title + '</h2>' +
      '<p class="section-note">' + note + '</p>' +
      (keys.length ? keys.map(function (o) {
        var list = by[o];
        return '<div class="owner-row"><span class="o-name">' + U.esc(o) + '</span>' +
          '<div class="owner-bar" style="width:' + (list.length / max) * 45 + '%"></div>' +
          '<span>' + list.length + '</span><span class="owner-dots">' + list.map(function (m) {
            var st = ENGINE.dispStatus(m);
            return '<span class="dot rag-' + st + '" role="img" aria-label="' + U.esc(m.name + ' — ' + st) + '" title="' + U.esc(m.name + ' — ' + st) + '"></span>';
          }).join('') + '</span></div>';
      }).join('') : '<p class="muted small">No models in the current filter.</p>') + '</section>';
  }
  function concentration(ms) {
    return concentrationBy(ms, function (m) { return m.accountableOwner; }, 'Concentration by accountable owner', 'Owner = the accountable duty, distinct from who does the work.') +
      concentrationBy(ms, function (m) { return m.modelType; }, 'Concentration by model type', 'Where the risk clusters by the kind of model.');
  }

  // ---------------- (g) exec summary strip — indicative ----------------
  function execStrip(ms, counts) {
    var next = ms.filter(function (m) { return ENGINE.dispStatus(m) !== 'green'; })
      .sort(function (a, b) { return U.daysUntil(a.nextExecution) - U.daysUntil(b.nextExecution); })[0];
    return '<section class="card exec-strip"><span class="hypothesis-banner">Indicative</span>' +
      '<h2 style="margin-top:0">Exec summary</h2>' +
      '<p class="small">' + counts.red + ' red model' + (counts.red === 1 ? '' : 's') + '; ' +
      counts.amber + ' amber · ' + counts.ack + ' acknowledged (accepted positions, rationale on record); ' +
      (next ? 'next material execution: ' + U.esc(next.name) + ' ' + (U.daysUntil(next.nextExecution) <= 0 ? 'today' : 'in ' + U.daysUntil(next.nextExecution) + 'd') + '.' : 'no imminent executions.') + '</p>' +
      '<p class="tiny">An early, indicative executive summary — figures recompute on each run.</p></section>';
  }

  V.portfolio = function (r) {
    var ms = UI.filterModels(API.models(), r.query);
    var counts = { red: 0, amber: 0, ack: 0, green: 0 };
    ms.forEach(function (m) { counts[ENGINE.dispStatus(m)]++; });
    var extra = counts.red + ' red · ' + counts.amber + ' amber · ' + counts.ack + ' acknowledged · ' + counts.green + ' green';
    return '<div class="wrap"><h1>Portfolio</h1>' +
      UI.filterBar(['fn', 'tier', 'rag', 'owner'], r.query) +
      UI.reconcile(ms.length, API.models().length, extra) +
      lineageSection(ms) +
      honestNumbers(ms) +
      tierStack(ms) +
      deterioration(ms) +
      trendSection(ms) +
      concentration(ms) +
      execStrip(ms, counts) +
      '</div>';
  };
})();
