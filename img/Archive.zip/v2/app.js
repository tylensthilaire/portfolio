/* ============================================================
   MPMP · Monitoring & Remediation V2 — application
   Vanilla JS, hash routing, in-memory state only (no storage).
   Every view is commented with the PS-xx requirements it serves.
   Model status is COMPUTED here from KPI data via the assumed
   rule "Key-KPI dominance with materiality floor" (DN-13 open).
   ============================================================ */
(function () {
  'use strict';

  var DATA = window.DATA;
  var MODELS = DATA.models;
  var TICKETS = DATA.tickets; // mutated in memory — nothing persists
  var META = DATA.meta;

  // ---------------- in-memory state ----------------
  var STATE = {
    lens: 'fixer',            // PS-20 — duty lens, not role
    signalsDismissed: false,  // PS-21
    open: {},                 // expandable panels (derivation, triage, lenses…)
    acks: {},                 // 'modelId:kpiCode' → {rationale, who, at}  (PS-08)
    triaged: {},              // modelId → {action, ref?, rationale}       (PS-15)
    drafts: {},               // form values surviving re-renders
    flash: {},                // inline validation messages
    fn: 'All',                // portfolio Function filter (PS-21 adopts US-1/FR-4)
    tierFilter: null,         // {tier, status} from tier-stack click (PS-02)
    packOpen: {},             // modelId → evidence pack visible (un-14)
    seq: 2042                 // next mock Jira number
  };

  // ---------------- tiny helpers ----------------
  function $(sel) { return document.querySelector(sel); }
  function esc(s) {
    return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  }
  function modelById(id) { for (var i = 0; i < MODELS.length; i++) if (MODELS[i].id === id) return MODELS[i]; return null; }
  function ticketByRef(ref) { for (var i = 0; i < TICKETS.length; i++) if (TICKETS[i].ref === ref) return TICKETS[i]; return null; }
  function openTicketFor(mid) {
    for (var i = 0; i < TICKETS.length; i++) {
      if (TICKETS[i].modelId === mid && ['Resolved', 'Rejected'].indexOf(TICKETS[i].state) < 0) return TICKETS[i];
    }
    return null;
  }
  function kpiByCode(m, code) { for (var i = 0; i < m.kpis.length; i++) if (m.kpis[i].code === code) return m.kpis[i]; return null; }
  function parseD(s) { return new Date(String(s).replace(' ', 'T')); }
  function fmtD(s) {
    var d = parseD(s), mo = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
    return d.getDate() + ' ' + mo[d.getMonth()] + ' ' + d.getFullYear();
  }
  function daysUntil(s) { return Math.round((parseD(s) - parseD(META.today)) / 864e5); }
  function ageOf(s) {
    var ms = parseD(META.now) - parseD(s);
    var hrs = Math.round(ms / 36e5);
    return hrs < 24 ? hrs + 'h' : Math.round(hrs / 24) + 'd';
  }
  function addDays(s, n) {
    var d = parseD(s); d.setDate(d.getDate() + n);
    return d.toISOString().slice(0, 10);
  }
  function draft(id, fallback) { return STATE.drafts[id] !== undefined ? STATE.drafts[id] : (fallback || ''); }
  function names(list) { return list.map(function (k) { return k.code; }).join(', '); }
  function pct(x) { return Math.round(x * 100) + '%'; }

  // ============================================================
  // STATUS ENGINE — assumed aggregation rule (PS-08, DN-13 open)
  //   1. any Key KPI red → model Red
  //   2. any Key KPI amber (unacknowledged) → model Amber
  //   3. else ≥30% of non-Key KPIs amber-or-red, or ≥15% red → Amber
  //   4. else Green — but acknowledged ambers show as Acknowledged Amber
  // Acknowledged KPIs are excluded from dominance, counted separately.
  // ============================================================
  function ragOf(k, v) {
    if (k.dir === 'lt') return v < k.green ? 'green' : v <= k.amber ? 'amber' : 'red';
    return v >= k.green ? 'green' : v >= k.amber ? 'amber' : 'red';
  }
  function kst(k, i) { // KPI status at history index i (default: latest)
    var h = k.history;
    return ragOf(k, i == null ? h[h.length - 1] : h[i]);
  }
  function ackOf(m, k) { return k.acknowledged || STATE.acks[m.id + ':' + k.code] || null; }

  function modelStatus(m, i) {
    var key = [], nonKey = [], acked = [];
    m.kpis.forEach(function (k) {
      if (ackOf(m, k)) { acked.push(k); return; }
      (k.isKey ? key : nonKey).push(k);
    });
    var keyRed = key.filter(function (k) { return kst(k, i) === 'red'; });
    var keyAmber = key.filter(function (k) { return kst(k, i) === 'amber'; });
    var nkBad = nonKey.filter(function (k) { return kst(k, i) !== 'green'; });
    var nkRed = nonKey.filter(function (k) { return kst(k, i) === 'red'; });
    var badShare = nonKey.length ? nkBad.length / nonKey.length : 0;
    var redShare = nonKey.length ? nkRed.length / nonKey.length : 0;
    var r = {
      key: key, nonKey: nonKey, acked: acked, keyRed: keyRed, keyAmber: keyAmber,
      nkBad: nkBad, badShare: badShare, redShare: redShare, ackedOnly: false
    };
    if (keyRed.length) { r.rag = 'red'; r.branch = 'Branch 1 fired — Key-KPI dominance: ' + names(keyRed) + ' red → model Red.'; }
    else if (keyAmber.length) { r.rag = 'amber'; r.branch = 'Branch 2 fired — Key-KPI dominance: ' + names(keyAmber) + ' amber (unacknowledged) → model Amber.'; }
    else if (badShare >= 0.3 || redShare >= 0.15) { r.rag = 'amber'; r.branch = 'Branch 3 fired — materiality floor: ' + pct(badShare) + ' of non-Key KPIs amber-or-red (floor 30%) → model Amber.'; }
    else if (acked.some(function (k) { return kst(k, i) !== 'green'; })) {
      r.rag = 'amber'; r.ackedOnly = true;
      r.branch = 'Acknowledged branch — residual status Green, but ' + names(acked) + ' amber is acknowledged (excluded from dominance): shown as Acknowledged Amber.';
    }
    else { r.rag = 'green'; r.branch = 'Branch 4 fired — no Key-KPI breach; non-Key amber-or-red share ' + pct(badShare) + ' is below the 30% floor → model Green.'; }
    r.hasAck = acked.length > 0;
    return r;
  }

  function drivingKpi(m) {
    var s = modelStatus(m);
    return s.keyRed[0] || s.keyAmber[0] ||
      s.nonKey.filter(function (k) { return kst(k) === 'red'; })[0] ||
      s.nkBad[0] || s.acked[0] || null;
  }
  function ackInfo(m) { // first acknowledged non-green KPI, for badges
    for (var i = 0; i < m.kpis.length; i++) {
      var a = ackOf(m, m.kpis[i]);
      if (a && kst(m.kpis[i]) !== 'green') return { kpi: m.kpis[i], ack: a };
    }
    return null;
  }

  // Ranking = materiality × execution proximity (PS-15, IN-03)
  var MATW = { 'Very High': 4, 'High': 3, 'Medium': 2, 'Low': 1 };
  function score(m) {
    var d = daysUntil(m.nextExecution);
    return MATW[m.materiality] * (d <= 7 ? (8 - d) : 1);
  }
  function rankDriver(m) {
    var d = daysUntil(m.nextExecution);
    return m.materiality + ' materiality × executes ' + (d <= 0 ? 'today' : 'in ' + d + 'd');
  }

  function exceptions() { // exceptions only — PS-23 exception-first
    return MODELS.filter(function (m) {
      var t = STATE.triaged[m.id];
      if (t && t.action === 'Rejected') return false;
      var s = modelStatus(m);
      return s.rag !== 'green' && !s.ackedOnly;
    });
  }
  function acknowledgedModels() {
    return MODELS.filter(function (m) { return modelStatus(m).ackedOnly; });
  }
  function kpiDowngrades(m) { // latest vs previous run (PS-06/PS-12)
    var rank = { green: 0, amber: 1, red: 2 };
    return m.kpis.filter(function (k) {
      return rank[kst(k)] > rank[ragOf(k, k.previous)];
    });
  }

  // ---------------- shared render pieces ----------------
  function chip(rag, label, title) {
    return '<span class="chip rag-' + rag + '"' + (title ? ' title="' + esc(title) + '"' : '') +
      '><span class="dot" aria-hidden="true"></span>' + esc(label) + '</span>';
  }
  function statusChip(m) {
    var s = modelStatus(m);
    var label = s.rag.charAt(0).toUpperCase() + s.rag.slice(1);
    if (s.ackedOnly) label = 'Amber';
    return chip(s.rag, label, 'Computed by the assumed rule — expand Derivation for the why (PS-08)');
  }
  function ackBadge(m) { // acknowledged-state is first-class, shown everywhere (PS-08)
    var a = ackInfo(m);
    if (!a) return '';
    return '<span class="ack-badge" title="' + esc(a.kpi.code + ' — ' + a.ack.who + ', ' + fmtD(a.ack.at)) + '">✓ Acknowledged — ' + esc(a.ack.rationale) + '</span>';
  }
  function moveArrow(prevRag, lastRag, detail) {
    var rank = { green: 0, amber: 1, red: 2 };
    if (rank[lastRag] > rank[prevRag]) return '<span class="move-up" title="' + esc(detail || '') + '">▲ worsened</span>';
    if (rank[lastRag] < rank[prevRag]) return '<span class="move-down" title="' + esc(detail || '') + '">▼ improved</span>';
    return '<span class="move-flat">– unchanged</span>';
  }
  function kpiMove(k) {
    return moveArrow(ragOf(k, k.previous), kst(k), k.previous + ' → ' + k.latest + ' ' + k.unit);
  }
  function spark(k) { // 12-run inline sparkline (PS-09 — drift vs blip in one glance)
    var h = k.history, min = Math.min.apply(null, h), max = Math.max.apply(null, h);
    var span = (max - min) || 1;
    var pts = h.map(function (v, i) {
      return (4 + i * 7) + ',' + (17 - ((v - min) / span) * 13);
    }).join(' ');
    var last = pts.split(' ').pop().split(',');
    var col = { red: 'var(--rag-red-solid)', amber: 'var(--rag-amber-solid)', green: 'var(--rag-green-solid)' }[kst(k)];
    return '<svg class="sparkline" width="88" height="20" viewBox="0 0 88 20" role="img" aria-label="12-run history for ' + esc(k.code) + '">' +
      '<polyline points="' + pts + '" fill="none" stroke="var(--ink-300)" stroke-width="1.5"/>' +
      '<circle cx="' + last[0] + '" cy="' + last[1] + '" r="2.5" fill="' + col + '"/></svg>';
  }
  function expander(key, label, expanded) {
    return '<button type="button" class="btn btn-ghost btn-sm" data-action="expand" data-key="' + esc(key) + '" aria-expanded="' + (!!expanded) + '">' + esc(label) + (expanded ? ' ▴' : ' ▾') + '</button>';
  }

  // Derivation panel — the colour never travels alone (PS-08, A4, un-17)
  function derivation(m) {
    var s = modelStatus(m);
    var kpiLines = m.kpis.map(function (k) {
      var a = ackOf(m, k);
      return k.code + ' ' + (k.isKey ? '[KEY] ' : '') + kst(k) + (a ? ' — acknowledged, excluded from dominance' : '');
    }).join(' · ');
    var chain = m.symptomOf ? '<dt>Chain attribution</dt><dd>Likely a symptom of ' + esc(modelById(m.symptomOf).name) + ' (' + m.symptomOf + ') — see the upstream strip before investigating locally (A3).</dd>' : '';
    return '<div class="deriv" id="deriv-' + m.id + '"><dl style="margin:0">' +
      '<dt>Assumed rule</dt><dd>“Key-KPI dominance with materiality floor” — any Key KPI red → Red; any unacknowledged Key KPI amber → Amber; else ≥30% of non-Key KPIs amber-or-red (or ≥15% red) → Amber; else Green.</dd>' +
      '<dt>KPIs evaluated</dt><dd>' + s.key.length + ' Key + ' + s.nonKey.length + ' non-Key evaluated' + (s.acked.length ? '; ' + s.acked.length + ' acknowledged (excluded, counted separately)' : '') + '. ' + esc(kpiLines) + '</dd>' +
      '<dt>Branch fired</dt><dd>' + esc(s.branch) + '</dd>' + chain +
      '</dl><p class="caveat">Assumed rule — DN-13 unresolved. Any rule must be explainable in one line (T1).</p></div>';
  }
  function statusBlock(m) { // status chip + derivation affordance + ack badge, used everywhere
    var open = STATE.open['deriv-' + m.id];
    return statusChip(m) + ' ' + expander('deriv-' + m.id, 'Derivation', open) + ' ' + ackBadge(m) + (open ? derivation(m) : '');
  }
  function lastVisitLine() { // "since you were last here" framing (PS-21, IN-02)
    return '<p class="lastvisit">Last visit: ' + fmtD(META.lastVisit) + ' — ' + META.lastVisitAgo + '. Here’s what changed.</p>';
  }
  function flashMsg(key) {
    return STATE.flash[key] ? '<p class="flash" role="alert">' + esc(STATE.flash[key]) + '</p>' : '';
  }

  // ============================================================
  // SIGNALS strip — mocked push into Teams/Jira/email (PS-21, M0)
  // ============================================================
  function renderSignals() {
    var el = $('#signals');
    if (STATE.signalsDismissed) { el.innerHTML = ''; return; }
    el.innerHTML = '<div class="signals"><div class="signals-inner">' +
      '<span class="signals-title">Pushed to you</span>' +
      DATA.signals.map(function (s) {
        return '<a class="signal" href="' + esc(s.route) + '"><span class="ch">' + esc(s.channel) + '</span> ' + esc(s.text) + ' <span class="ago">' + esc(s.ago) + '</span></a>';
      }).join('') +
      '<button type="button" class="btn btn-ghost btn-sm dismiss" data-action="dismiss-signals">Dismiss</button>' +
      '</div></div>';
  }

  // ============================================================
  // HOME — per-duty landing, "since you were last here" (PS-18/19/21, M1)
  // ============================================================
  function viewHome() {
    var h = '<div class="wrap"><h1>Since you were last here</h1>' + lastVisitLine();
    if (STATE.lens === 'fixer') h += homeFixer();
    else if (STATE.lens === 'owner') h += homeOwner();
    else h += homeGovernance();
    return h + '</div>';
  }

  function exceptionLine(m, ownerAltitude) {
    var k = drivingKpi(m);
    var t = openTicketFor(m.id);
    var isNew = m.breach && parseD(m.breach.openedAt) > parseD(META.lastVisit);
    return '<tr>' +
      '<td><a href="#/model/' + m.id + '">' + esc(m.name) + '</a>' + (isNew ? ' <span class="keytag" style="background:var(--brand-gold-500);color:var(--brand-purple-900)">NEW</span>' : '') +
      (m.symptomOf ? ' <span class="symptom-tag">symptom of ↑ ' + m.symptomOf + '</span>' : '') + '</td>' +
      '<td>' + (k ? esc(k.code) + (k.isKey ? ' <span class="keytag">KEY</span>' : '') + ' ' + chip(kst(k), kst(k), k.thresholdRule) : '—') + '</td>' +
      '<td>' + esc(m.materiality) + '</td>' +
      (ownerAltitude
        ? '<td>' + esc(t ? t.assignee + ' (' + t.ref + ')' : m.delegate + ' — to triage') + '</td><td>' + esc(t ? fmtD(t.byWhen) : 'SLA ' + m.breach.slaDays + 'd') + '</td>'
        : '<td>' + (k ? kpiMove(k) : '') + '</td><td class="tiny">' + esc(rankDriver(m)) + '</td>') +
      '</tr>';
  }

  function homeFixer() { // ranked exceptions top slice + my open tickets (PS-18 framing for the fixer duty)
    var exs = exceptions().sort(function (a, b) { return score(b) - score(a); }).slice(0, 4);
    var mine = TICKETS.filter(function (t) { return ['Resolved', 'Rejected'].indexOf(t.state) < 0; });
    return '<div class="grid-2">' +
      '<section class="card"><h2>Needs triage — top of the queue</h2>' +
      '<p class="section-note">Ranked by materiality × execution proximity; chain-grouped in the <a href="#/queue">full queue</a> (PS-15).</p>' +
      '<table><thead><tr><th>Model</th><th>Driving KPI</th><th>Materiality</th><th>Movement</th><th>Rank driver</th></tr></thead><tbody>' +
      exs.map(function (m) { return exceptionLine(m, false); }).join('') + '</tbody></table></section>' +
      '<section class="card"><h2>My open tickets</h2>' +
      '<table><thead><tr><th>Ref</th><th>Model</th><th>Type</th><th>State</th><th>By when</th></tr></thead><tbody>' +
      mine.map(function (t) {
        return '<tr><td><a href="#/work/' + esc(t.ref) + '" class="mono">' + esc(t.ref) + '</a></td><td>' + esc(modelById(t.modelId).name) + '</td><td>' + esc(t.type) + '</td><td>' + stateChip(t.state) + '</td><td>' + fmtD(t.byWhen) + '</td></tr>';
      }).join('') + '</tbody></table></section></div>';
  }

  function homeOwner() { // owner altitude: which KPI, materiality, who's on it, by when (PS-18/19)
    var exs = exceptions().sort(function (a, b) { return score(b) - score(a); });
    var awaiting = TICKETS.filter(function (t) { return t.state === 'Awaiting approval'; });
    var feed = recentEvents(8);
    return '<section class="card"><h2>Decisions waiting on the owner duty</h2>' +
      (awaiting.length ? '<table><thead><tr><th>Ref</th><th>Model</th><th>Recommendation</th><th>By when</th><th></th></tr></thead><tbody>' +
        awaiting.map(function (t) {
          return '<tr><td class="mono">' + esc(t.ref) + '</td><td>' + esc(modelById(t.modelId).name) + '</td><td>' + esc(t.title) + '</td><td>' + fmtD(t.byWhen) + '</td><td><a class="btn btn-gold btn-sm" href="#/work/' + esc(t.ref) + '">Decide</a></td></tr>';
        }).join('') + '</tbody></table>' : '<p class="muted">Nothing awaiting approval.</p>') + '</section>' +
      '<div class="grid-2">' +
      '<section class="card"><h2>My models — exceptions</h2>' +
      '<p class="section-note">Which of mine needs me — not a grid of everything (PS-18, un-11).</p>' +
      '<table><thead><tr><th>Model</th><th>Driving KPI</th><th>Materiality</th><th>Who’s on it</th><th>By when</th></tr></thead><tbody>' +
      exs.map(function (m) { return exceptionLine(m, true); }).join('') + '</tbody></table>' +
      acknowledgedModels().map(function (m) {
        return '<p class="small"><a href="#/model/' + m.id + '">' + esc(m.name) + '</a> ' + ackBadge(m) + '</p>';
      }).join('') + '</section>' +
      '<section class="card"><h2>Remediation movement</h2>' +
      '<p class="section-note">Who’s on it, by when, what state — readable without asking the deputy (PS-19, qb-o02/o03).</p>' +
      '<ul class="timeline">' + feed + '</ul></section></div>';
  }

  function homeGovernance() { // portfolio deltas + items awaiting challenge (PS-19/M5 altitude)
    var deltas = MODELS.filter(function (m) { return kpiDowngrades(m).length; });
    var awaiting = TICKETS.filter(function (t) { return t.state === 'Awaiting approval'; });
    var acks = acknowledgedModels();
    return '<div class="grid-2">' +
      '<section class="card"><h2>Portfolio deltas</h2>' +
      '<p class="section-note">Models whose KPIs downgraded latest-vs-previous run. Full picture in the <a href="#/portfolio">Portfolio</a> (PS-06).</p>' +
      '<table><thead><tr><th>Model</th><th>Status</th><th>Downgraded KPIs</th></tr></thead><tbody>' +
      deltas.map(function (m) {
        return '<tr><td><a href="#/model/' + m.id + '">' + esc(m.name) + '</a></td><td>' + statusChip(m) + ' ' + ackBadge(m) + '</td><td>' +
          kpiDowngrades(m).map(function (k) { return esc(k.code) + ' ' + chip(ragOf(k, k.previous), ragOf(k, k.previous)) + '→' + chip(kst(k), kst(k), k.thresholdRule); }).join('<br>') + '</td></tr>';
      }).join('') + '</tbody></table></section>' +
      '<section class="card"><h2>Awaiting challenge</h2>' +
      '<p class="section-note">Owner decisions pending, plus acknowledged risk positions to review.</p>' +
      (awaiting.map(function (t) {
        return '<p class="small"><a href="#/work/' + esc(t.ref) + '" class="mono">' + esc(t.ref) + '</a> — ' + esc(t.title) + ' <span class="state-chip st-awaiting">Awaiting approval</span></p>';
      }).join('') || '<p class="muted">No approvals pending.</p>') +
      acks.map(function (m) {
        return '<p class="small"><a href="#/model/' + m.id + '">' + esc(m.name) + '</a> ' + ackBadge(m) + '</p>';
      }).join('') + '</section></div>';
  }

  function recentEvents(n) {
    var evts = [];
    TICKETS.forEach(function (t) {
      t.eventLog.forEach(function (e) { evts.push({ t: t, e: e }); });
    });
    evts.sort(function (a, b) { return parseD(b.e.at) - parseD(a.e.at); });
    return evts.slice(0, n).map(function (x) {
      var since = parseD(x.e.at) >= parseD(META.lastVisit);
      return '<li>' + (since ? '<span class="keytag" style="background:var(--brand-gold-500);color:var(--brand-purple-900)">SINCE LAST VISIT</span> ' : '') +
        '<span class="t-at">' + fmtD(x.e.at) + ' · <a href="#/work/' + esc(x.t.ref) + '" class="mono">' + esc(x.t.ref) + '</a></span>' +
        '<span class="t-who">' + esc(x.e.who) + '</span> — ' + esc(x.e.what) + '</li>';
    }).join('');
  }

  // ============================================================
  // QUEUE — ranked exceptions, chain-aware grouping, inline triage
  // (PS-15, PS-16, PS-14, PS-23 — M2)
  // ============================================================
  function viewQueue() {
    var exs = exceptions();
    var byId = {}; exs.forEach(function (m) { byId[m.id] = m; });
    var groups = [], attached = {};
    exs.forEach(function (m) { // symptom rows group under their upstream source (A3/IN-10)
      if (m.symptomOf && byId[m.symptomOf]) attached[m.id] = m.symptomOf;
    });
    exs.forEach(function (m) {
      if (attached[m.id]) return;
      groups.push({
        source: m,
        symptoms: exs.filter(function (x) { return attached[x.id] === m.id; })
      });
    });
    groups.sort(function (a, b) { return score(b.source) - score(a.source); });

    var h = '<div class="wrap"><h1>Queue</h1>' +
      '<p class="section-note">Exceptions only — ranked by materiality × execution proximity, chain-grouped: a source breach carries its downstream symptoms with it (PS-15, PS-23). Only the ranking is standardised — diagnosis is not (IN-03).</p>';
    groups.forEach(function (g) {
      h += '<div class="q-group">' + queueRow(g.source, false);
      g.symptoms.forEach(function (m) { h += queueRow(m, true); });
      h += '</div>';
    });
    if (!groups.length) h += '<p class="card muted">No open exceptions — everything triaged or green.</p>';

    var acks = acknowledgedModels();
    if (acks.length) {
      h += '<h2>Acknowledged</h2><p class="section-note">First-class state — acknowledged, not hidden (PS-08).</p>';
      acks.forEach(function (m) {
        h += '<div class="q-row"><div class="q-head"><span class="name"><a href="#/model/' + m.id + '">' + esc(m.name) + '</a></span> ' + statusChip(m) + ' ' + ackBadge(m) + '</div></div>';
      });
    }
    var rejected = MODELS.filter(function (m) { return STATE.triaged[m.id] && STATE.triaged[m.id].action === 'Rejected'; });
    if (rejected.length) {
      h += '<h2>Closed this session</h2>';
      rejected.forEach(function (m) {
        h += '<div class="q-row"><div class="q-head"><span class="name">' + esc(m.name) + '</span> <span class="state-chip st-rejected">Rejected</span> <span class="small muted">“' + esc(STATE.triaged[m.id].rationale) + '”</span></div></div>';
      });
    }
    return h + '</div>';
  }

  function queueRow(m, isSymptom) {
    var k = drivingKpi(m);
    var open = STATE.open['q-' + m.id];
    var t = STATE.triaged[m.id];
    var age = m.breach ? ageOf(m.breach.openedAt) : '—';
    var overdue = m.breach && (parseD(META.now) - parseD(m.breach.openedAt)) / 864e5 > m.breach.slaDays;
    var h = '<div class="q-row' + (isSymptom ? ' symptom' : '') + '">' +
      '<div class="q-head">' +
      (isSymptom ? '<span class="symptom-tag">symptom of ↑</span>' : '') +
      '<span class="name"><a href="#/model/' + m.id + '">' + esc(m.name) + '</a></span> ' +
      statusChip(m) + ' ' + expander('deriv-' + m.id, 'Why', STATE.open['deriv-' + m.id]) +
      (t && t.action === 'Escalated' ? ' <span class="done-note">Escalated → ' + esc(t.ref) + ' (Jira mock)</span>' : '') +
      '<span class="q-expand">' + expander('q-' + m.id, open ? 'Close triage' : 'Triage', open) + '</span>' +
      '</div>' +
      (STATE.open['deriv-' + m.id] ? derivation(m) : '') +
      '<p class="q-why">' + (k ? esc(k.code) + ' ' + esc(k.name) + (k.isKey ? ' <span class="keytag">KEY</span>' : '') + ' — ' + k.latest + ' ' + esc(k.unit) + ' vs rule <span class="mono" title="' + esc(k.thresholdRule) + '">' + esc(k.thresholdRule) + '</span>' : '') + '</p>' +
      '<div class="q-meta">' +
      '<span>Movement: ' + (k ? kpiMove(k) : '—') + '</span>' +
      '<span' + (overdue ? ' class="overdue"' : '') + '>Age ' + age + ' · SLA ' + (m.breach ? m.breach.slaDays + 'd' + (overdue ? ' — overdue' : '') : '—') + '</span>' +
      '<span>Suggested severity: ' + esc(m.breach ? m.breach.suggestedSeverity : '—') + '</span>' +
      '<span>' + esc(rankDriver(m)) + '</span>' +
      '</div>';
    if (open) h += triagePanel(m);
    return h + '</div>';
  }

  function triagePanel(m) { // inline triage: severity + materiality + mandatory rationale (PS-15); escalate mints a ticket (PS-16)
    if (STATE.lens !== 'fixer') {
      return '<div class="triage"><p class="muted small">Triage actions live with the fixer duty — switch the lens to act. Data is identical in every lens (PS-20).</p></div>';
    }
    var up = (m.upstream || []).map(function (id) {
      var u = modelById(id); var s = modelStatus(u);
      return esc(u.name) + ' ' + chip(s.rag, s.rag, 'Upstream status');
    }).join(' · ') || 'none declared';
    var sevOpts = ['Low', 'Medium', 'High', 'Critical'].map(function (o) {
      var sel = draft('sev-' + m.id, m.breach ? m.breach.suggestedSeverity : 'Medium') === o;
      return '<option' + (sel ? ' selected' : '') + '>' + o + '</option>';
    }).join('');
    var matOpts = ['Low', 'Medium', 'High', 'Very High'].map(function (o) {
      var sel = draft('mat-' + m.id, m.materiality) === o;
      return '<option' + (sel ? ' selected' : '') + '>' + o + '</option>';
    }).join('');
    return '<div class="triage" data-form>' +
      '<p class="small"><b>Upstream check — symptom or source?</b> ' + up +
      (m.symptomOf ? ' · <span class="symptom-tag">likely symptom of ' + esc(modelById(m.symptomOf).name) + '</span> — attribute upstream, don’t investigate locally (A3)' : ' · no upstream exception — treat as source') + '</p>' +
      (m.breach ? '<p class="small"><b>Breach context (PS-14):</b> ' + esc(m.breach.classification) + ' · stage: ' + esc(m.breach.stage) + '</p>' : '') +
      '<div class="triage-grid">' +
      '<div><label for="sev-' + m.id + '">Severity</label><select id="sev-' + m.id + '">' + sevOpts + '</select></div>' +
      '<div><label for="mat-' + m.id + '">Materiality</label><select id="mat-' + m.id + '">' + matOpts + '</select></div>' +
      '<div><label for="rat-' + m.id + '">Rationale (mandatory on every decision)</label><textarea id="rat-' + m.id + '" placeholder="Why this classification / decision…">' + esc(draft('rat-' + m.id)) + '</textarea></div>' +
      '</div>' + flashMsg('q-' + m.id) +
      '<div class="triage-actions">' +
      '<button type="button" class="btn" data-action="triage" data-act="ack" data-model="' + m.id + '">Acknowledge</button>' +
      '<button type="button" class="btn btn-gold" data-action="triage" data-act="esc" data-model="' + m.id + '">Escalate — mint ticket</button>' +
      '<button type="button" class="btn btn-danger" data-action="triage" data-act="rej" data-model="' + m.id + '">Reject</button>' +
      '<span class="tiny">Escalation creates a Jira ticket with an assignee (mock) — PS-16.</span>' +
      '</div></div>';
  }

  // ============================================================
  // MODEL ROOM — status+derivation, upstream strip, last run &
  // movement, KPI table, Runs, Work, Links-out, Evidence pack
  // (PS-08/09/10/11/12/13/14/17, un-14 — M2/M3)
  // ============================================================
  function viewModel(id) {
    var m = modelById(id);
    if (!m) return '<div class="wrap"><p class="card">Unknown model.</p></div>';
    var s = modelStatus(m);
    var h = '<div class="wrap">';

    // Header — PS-08: status only ever renders with its derivation affordance
    h += '<div class="card"><div class="room-head"><div style="flex:1">' +
      '<h1>' + esc(m.name) + '</h1>' +
      '<div class="facts"><span>Function <b>' + esc(m.function) + '</b></span><span>Area <b>' + esc(m.businessArea) + '</b></span>' +
      '<span>Materiality <b>' + esc(m.materiality) + '</b> (tier ' + esc(m.riskTier) + ')</span>' +
      '<span>Next execution <b>' + fmtD(m.nextExecution) + '</b> (' + daysUntil(m.nextExecution) + 'd)</span>' +
      '<span>Owner <b>' + esc(m.accountableOwner) + '</b> · delegate ' + esc(m.delegate) + ' · developer ' + esc(m.developer) + '</span>' +
      '<span>' + esc(m.version) + ' · ' + esc(m.environment) + '</span></div>' +
      '</div><div>' + statusBlock(m) + '</div></div></div>';

    // Upstream strip — symptom or source? (PS-13, IN-10, un-07)
    h += '<section class="card"><h2>Upstream</h2>' +
      '<p class="section-note">The models and feeds this one depends on — check here before classifying: symptom or source? (PS-13).</p>' +
      '<div class="upstream-strip">' +
      ((m.upstream || []).length ? m.upstream.map(function (uid) {
        var u = modelById(uid); var us = modelStatus(u);
        return '<a class="up-chip" href="#/model/' + uid + '">' + esc(u.name) + ' ' + chip(us.rag, us.rag, 'Expand Derivation in its model room for the why') + (us.hasAck ? ' ✓ack' : '') + '</a>';
      }).join('') : '<span class="muted small">No upstream dependencies declared.</span>') +
      (m.symptomOf ? ' <span class="symptom-tag">current exception likely a symptom of ' + esc(modelById(m.symptomOf).name) + '</span>' : '') +
      '</div></section>';

    // Latest run + movement vs previous run (PS-10, PS-12, qb-d01–d03)
    var moved = m.kpis.filter(function (k) { return kst(k) !== ragOf(k, k.previous); });
    h += '<section class="card"><h2>Latest run</h2>' +
      '<p class="small">' + esc(m.lastRun.status) + ' · executed ' + esc(m.lastRun.executedAt) + ' · runtime ' + esc(m.lastRun.runtime) + ' · ' + esc(m.lastRun.codeVersion) + ' · ' + esc(m.lastRun.trigger) + '</p>' +
      '<h3>Movement vs previous run</h3>' +
      (moved.length ? '<ul>' + moved.map(function (k) {
        return '<li class="small">' + esc(k.code) + ' ' + esc(k.name) + ': ' + k.previous + ' → ' + k.latest + ' ' + esc(k.unit) + ' — ' + chip(ragOf(k, k.previous), ragOf(k, k.previous)) + ' → ' + chip(kst(k), kst(k), k.thresholdRule) + ' ' + kpiMove(k) + '</li>';
      }).join('') + '</ul>' : '<p class="muted small">No KPI status movement between the last two runs.</p>') +
      (m.breach ? '<p class="small"><b>Breach context (PS-14):</b> ' + esc(m.breach.classification) + ' · implicated stage: ' + esc(m.breach.stage) + '</p>' : '') +
      '</section>';

    // KPI table — thresholds as visible text, sparkline history (PS-09, PS-11, un-03)
    var rank = { red: 0, amber: 1, green: 2 };
    var kpis = m.kpis.slice().sort(function (a, b) { return rank[kst(a)] - rank[kst(b)] || (b.isKey - a.isKey); });
    h += '<section class="card"><h2>KPIs</h2>' +
      '<p class="section-note">Exception-first ordering (PS-23). Threshold rules shown as text — no bare colour (PS-09).</p>' +
      '<table><thead><tr><th>Code</th><th>Name</th><th>Tier</th><th>Latest</th><th>Threshold rule</th><th>Status</th><th>12-run history</th><th>Movement</th></tr></thead><tbody>' +
      kpis.map(function (k) {
        var a = ackOf(m, k);
        return '<tr class="kpi-' + kst(k) + '"><td class="mono">' + esc(k.code) + '</td><td>' + esc(k.name) + '</td>' +
          '<td>' + (k.isKey ? '<span class="keytag">KEY</span>' : '<span class="tiny">non-key</span>') + '</td>' +
          '<td>' + k.latest + ' ' + esc(k.unit) + '</td>' +
          '<td class="mono">' + esc(k.thresholdRule) + '</td>' +
          '<td>' + chip(kst(k), kst(k), k.thresholdRule) + (a ? '<br><span class="ack-badge">✓ Acknowledged — ' + esc(a.rationale) + '</span>' : '') + '</td>' +
          '<td>' + spark(k) + '</td><td>' + kpiMove(k) + '</td></tr>';
      }).join('') + '</tbody></table></section>';

    // Runs
    h += '<section class="card"><h2>Runs</h2><table><thead><tr><th>Executed</th><th>Runtime</th><th>Status</th><th>Code version</th><th>Trigger</th></tr></thead><tbody>' +
      m.runs.map(function (r) {
        return '<tr><td>' + esc(r.executedAt) + '</td><td>' + esc(r.runtime) + '</td><td>' + esc(r.status) + '</td><td class="mono">' + esc(r.codeVersion) + '</td><td>' + esc(r.trigger) + '</td></tr>';
      }).join('') + '</tbody></table></section>';

    // Work — this model's tickets (PS-16/19)
    var tks = TICKETS.filter(function (t) { return t.modelId === m.id; });
    h += '<section class="card"><h2>Work</h2>' +
      (tks.length ? '<table><thead><tr><th>Ref</th><th>Type</th><th>Title</th><th>Assignee</th><th>By when</th><th>State</th></tr></thead><tbody>' +
        tks.map(function (t) {
          return '<tr><td><a href="#/work/' + esc(t.ref) + '" class="mono">' + esc(t.ref) + '</a></td><td>' + esc(t.type) + '</td><td>' + esc(t.title) + '</td><td>' + esc(t.assignee) + '</td><td>' + fmtD(t.byWhen) + '</td><td>' + stateChip(t.state) + '</td></tr>';
        }).join('') + '</tbody></table>' : '<p class="muted small">No tickets on this model.</p>') + '</section>';

    // Links-out — MP² links out to local monitoring rather than replicating it (PS-17, IN-07)
    h += '<section class="card links-out"><h2>Links out — team’s local monitoring</h2>' +
      '<p class="section-note">MP² is the KPI layer; depth stays local. It links out rather than replicates (PS-17, IN-07).</p>' +
      m.linksOut.map(function (l) {
        return '<a href="#/model/' + m.id + '" onclick="return false" title="Mock link — would open ' + esc(l.kind) + '">↗ ' + esc(l.kind) + ' — ' + esc(l.label) + '</a>';
      }).join('') + '</section>';

    // Evidence pack — producible on demand (un-14, M5)
    h += '<section class="card"><h2>Evidence pack</h2>' +
      '<button type="button" class="btn" data-action="pack" data-model="' + m.id + '">' + (STATE.packOpen[m.id] ? 'Hide evidence pack' : 'Assemble evidence pack') + '</button>';
    if (STATE.packOpen[m.id]) h += evidencePack(m);
    return h + '</section></div>';
  }

  function evidencePack(m) { // printable per-model summary (un-14)
    var s = modelStatus(m);
    var tks = TICKETS.filter(function (t) { return t.modelId === m.id; });
    var decisions = [];
    m.kpis.forEach(function (k) {
      var a = ackOf(m, k);
      if (a) decisions.push(fmtD(a.at) + ' — ' + a.who + ' acknowledged ' + k.code + ': “' + a.rationale + '”');
    });
    tks.forEach(function (t) {
      t.eventLog.forEach(function (e) {
        if (/approved|rejected|acknowledged|resolved/i.test(e.what)) decisions.push(fmtD(e.at) + ' — ' + e.who + ' (' + t.ref + '): ' + e.what);
      });
    });
    return '<div class="card evidence-pack" style="margin-top:12px">' +
      '<h3>Evidence pack — ' + esc(m.name) + '</h3><p class="tiny">Generated on demand ' + esc(META.now) + ' (un-14). Print-ready.</p>' +
      '<h3>Status & derivation</h3><p class="small">' + statusChip(m) + ' ' + ackBadge(m) + '</p>' + derivation(m) +
      '<h3>KPI history (12 runs)</h3><table><thead><tr><th>KPI</th><th>Rule</th>' + META.months.map(function (mo) { return '<th class="tiny">' + mo + '</th>'; }).join('') + '</tr></thead><tbody>' +
      m.kpis.map(function (k) {
        return '<tr><td class="mono">' + esc(k.code) + (k.isKey ? ' <span class="keytag">KEY</span>' : '') + '</td><td class="mono tiny">' + esc(k.thresholdRule) + '</td>' +
          k.history.map(function (v, i) { return '<td class="tiny" title="' + kst(k, i) + '">' + v + '</td>'; }).join('') + '</tr>';
      }).join('') + '</tbody></table>' +
      '<h3>Work — open & closed</h3>' +
      (tks.length ? '<ul>' + tks.map(function (t) {
        return '<li class="small">' + esc(t.ref) + ' · ' + esc(t.type) + ' · ' + esc(t.title) + ' — ' + esc(t.state) + (t.closureEvidence ? '. Closure evidence: ' + esc(t.closureEvidence) : '') + '</li>';
      }).join('') + '</ul>' : '<p class="muted small">None.</p>') +
      '<h3>Decisions log</h3>' +
      (decisions.length ? '<ul>' + decisions.map(function (d) { return '<li class="small">' + esc(d) + '</li>'; }).join('') + '</ul>' : '<p class="muted small">No recorded decisions.</p>') +
      '</div>';
  }

  // ============================================================
  // WORK — cross-model ticket surface (PS-16, PS-19 — M3/M4)
  // ============================================================
  function stateChip(st) {
    var cls = { 'Awaiting approval': 'st-awaiting', 'In progress': 'st-progress', 'Validating': 'st-validating', 'Resolved': 'st-resolved', 'Rejected': 'st-rejected' }[st] || '';
    return '<span class="state-chip ' + cls + '">' + esc(st) + '</span>';
  }
  function lastMove(t) {
    var e = t.eventLog[t.eventLog.length - 1];
    return e ? fmtD(e.at) + ' — ' + e.what : '—';
  }

  function viewWork() {
    var order = ['Awaiting approval', 'Open', 'Analysing', 'In progress', 'Validating', 'Iterating', 'Resolved', 'Rejected'];
    var tks = TICKETS.slice().sort(function (a, b) { return order.indexOf(a.state) - order.indexOf(b.state); });
    var h = '<div class="wrap"><h1>Work</h1>' +
      '<p class="section-note">Investigations and remediations as tickets — assignee, by-when, state. The lifecycle is the record: closed tickets answer “what was fixed quietly?” (PS-16, PS-19, qb-o08).</p>' +
      '<div class="card" style="padding:0;overflow-x:auto"><table><thead><tr><th>Ref</th><th>Model</th><th>Type</th><th>Assignee</th><th>By when</th><th>State</th><th>Last movement</th><th></th></tr></thead><tbody>' +
      tks.map(function (t) {
        var m = modelById(t.modelId);
        var cta = (t.state === 'Awaiting approval' && STATE.lens === 'owner') ? 'Decide' : 'Open';
        return '<tr><td class="mono">' + esc(t.ref) + '</td><td><a href="#/model/' + m.id + '">' + esc(m.name) + '</a></td><td>' + esc(t.type) + '</td>' +
          '<td>' + esc(t.assignee) + '</td><td>' + fmtD(t.byWhen) + '</td><td>' + stateChip(t.state) + '</td>' +
          '<td class="small">' + esc(lastMove(t)) + '</td>' +
          '<td><a class="btn ' + (cta === 'Decide' ? 'btn-gold' : 'btn-ghost') + ' btn-sm" href="#/work/' + esc(t.ref) + '">' + cta + '</a></td></tr>';
      }).join('') + '</tbody></table></div></div>';
    return h;
  }

  // ---- Ticket detail: approvals (M4), validation re-run, investigation (M3) ----
  function viewTicket(ref) {
    var t = ticketByRef(ref);
    if (!t) return '<div class="wrap"><p class="card">Unknown ticket.</p></div>';
    var m = modelById(t.modelId);
    var h = '<div class="wrap">' +
      '<p class="small"><a href="#/work">← Work</a></p>' +
      '<div class="card"><h1><span class="mono" style="font-size:20px">' + esc(t.ref) + '</span> · ' + esc(t.title) + '</h1>' +
      '<div class="q-meta"><span>' + esc(t.type) + (t.category ? ' · category: ' + esc(t.category) : '') + '</span>' +
      '<span>Model: <a href="#/model/' + m.id + '">' + esc(m.name) + '</a> ' + statusChip(m) + ' ' + ackBadge(m) + '</span>' +
      '<span>Assignee: ' + esc(t.assignee) + '</span><span>By when: ' + fmtD(t.byWhen) + '</span><span>State: ' + stateChip(t.state) + '</span></div>' +
      (t.closureEvidence ? '<div class="validation-box"><b>Closure evidence:</b> ' + esc(t.closureEvidence) + '</div>' : '') +
      '</div>';

    if (t.type === 'Investigation' && ['Open', 'Analysing'].indexOf(t.state) >= 0) h += investigationPanel(t, m);
    h += ticketActions(t, m);

    // Event log as timeline — the record is a by-product of the fix (A6, qb-o08)
    h += '<section class="card"><h2>Event log</h2><ul class="timeline">' +
      t.eventLog.map(function (e) {
        return '<li><span class="t-at">' + fmtD(e.at) + '</span><span class="t-who">' + esc(e.who) + '</span> — ' + esc(e.what) + '</li>';
      }).join('') + '</ul></section></div>';
    return h;
  }

  // Owner decisions & fixer implementation controls per lens (PS-20; M4)
  function ticketActions(t, m) {
    var h = '';
    if (t.state === 'Awaiting approval') {
      if (STATE.lens === 'owner') {
        h += '<section class="card" data-form><h2>Owner decision</h2>' +
          '<label for="note-' + esc(t.ref) + '">Audit note (mandatory)</label>' +
          '<textarea id="note-' + esc(t.ref) + '" placeholder="Why this decision…">' + esc(draft('note-' + t.ref)) + '</textarea>' +
          flashMsg('tk-' + t.ref) +
          '<div class="triage-actions">' +
          '<button type="button" class="btn btn-gold" data-action="tk" data-act="approve" data-ref="' + esc(t.ref) + '">Approve</button>' +
          '<button type="button" class="btn btn-ghost" data-action="tk" data-act="revise" data-ref="' + esc(t.ref) + '">Request revisions</button>' +
          '<button type="button" class="btn btn-danger" data-action="tk" data-act="reject" data-ref="' + esc(t.ref) + '">Reject</button>' +
          '</div></section>';
      } else {
        h += '<section class="card"><p class="muted small">Awaiting the owner duty’s decision — switch to the Owner lens to approve / request revisions / reject (PS-20).</p></section>';
      }
    }
    if (t.state === 'In progress') {
      if (STATE.lens === 'fixer') {
        h += '<section class="card"><h2>Implementation</h2>' +
          '<p class="small">Implemented? Run the validation to get a post-implementation KPI reading (M4).</p>' +
          '<button type="button" class="btn" data-action="tk" data-act="validate" data-ref="' + esc(t.ref) + '">Simulate validation re-run</button></section>';
      } else {
        h += '<section class="card"><p class="muted small">In implementation with the fixer duty (' + esc(t.assignee) + '). Switch to the Fixer lens to simulate the validation re-run.</p></section>';
      }
    }
    if (t.state === 'Validating' && t.validation) {
      h += '<section class="card"><h2>Validation re-run result</h2>' +
        '<div class="validation-box">' + esc(t.validation.kpi) + ': ' + t.validation.before + ' → <b>' + t.validation.after + '</b> — post-implementation reading is inside the green threshold.</div>' +
        (STATE.lens === 'fixer'
          ? '<div class="triage-actions"><button type="button" class="btn btn-gold" data-action="tk" data-act="resolve" data-ref="' + esc(t.ref) + '">Resolve — recompute status</button>' +
            '<button type="button" class="btn btn-ghost" data-action="tk" data-act="iterate" data-ref="' + esc(t.ref) + '">Iterate — spawn new investigation</button></div>'
          : '<p class="muted small">Resolve / Iterate sits with the fixer duty — switch lens.</p>') +
        '</section>';
    }
    return h;
  }

  // ============================================================
  // INVESTIGATION — evidence assembly, NOT machine diagnosis
  // (PS-17, A5, f-s3-018 — M3)
  // ============================================================
  function investigationPanel(t, m) {
    var h = '<section class="card"><h2>Investigation — evidence assembly</h2>' +
      '<p class="section-note">Three lenses organise the evidence; the analyst authors the conclusion (PS-17).</p>';
    h += evidenceLens('data-' + t.ref, 'Data factors', dataFactors(m));
    h += evidenceLens('model-' + t.ref, 'Model factors', modelFactors(m));
    h += evidenceLens('proc-' + t.ref, 'Process factors', processFactors(m));
    h += '<p class="small links-out" style="margin-top:8px"><b>Links out:</b> ' + m.linksOut.map(function (l) {
      return '<a href="#/work/' + esc(t.ref) + '" onclick="return false" title="Mock link">↗ ' + esc(l.kind) + ' — ' + esc(l.label) + '</a>';
    }).join('') + '</p>';

    if (STATE.lens === 'fixer') {
      var catOpts = ['Data', 'Model', 'Process'].map(function (o) {
        return '<option' + (draft('cat-' + t.ref, t.category || 'Model') === o ? ' selected' : '') + '>' + o + '</option>';
      }).join('');
      var impOpts = ['Low', 'Medium', 'High'].map(function (o) {
        return '<option' + (draft('imp-' + t.ref, 'Medium') === o ? ' selected' : '') + '>' + o + '</option>';
      }).join('');
      h += '<div data-form><h3>Analyst conclusion</h3>' +
        '<textarea id="conc-' + esc(t.ref) + '" placeholder="Root cause in your words — the system assembles, you conclude…">' + esc(draft('conc-' + t.ref)) + '</textarea>' +
        '<div class="triage-grid" style="margin-top:10px">' +
        '<div><label for="imp-' + esc(t.ref) + '">Impact</label><select id="imp-' + esc(t.ref) + '">' + impOpts + '</select></div>' +
        '<div><label for="cat-' + esc(t.ref) + '">Category</label><select id="cat-' + esc(t.ref) + '">' + catOpts + '</select></div>' +
        '<div><label for="act-' + esc(t.ref) + '">Recommended action</label><input type="text" id="act-' + esc(t.ref) + '" value="' + esc(draft('act-' + t.ref)) + '" placeholder="e.g. Recalibrate segment weights"></div>' +
        '</div>' +
        '<div style="max-width:220px;margin-top:10px"><label for="tl-' + esc(t.ref) + '">Timeline (by when)</label><input type="date" id="tl-' + esc(t.ref) + '" value="' + esc(draft('tl-' + t.ref, addDays(META.today, 14))) + '"></div>' +
        flashMsg('inv-' + t.ref) +
        '<div class="triage-actions"><button type="button" class="btn btn-gold" data-action="file-rem" data-ref="' + esc(t.ref) + '">File remediation recommendation</button>' +
        '<span class="tiny">Creates a remediation ticket for owner approval (M4).</span></div></div>';
    } else {
      h += '<p class="muted small">Investigation authoring lives with the fixer duty — switch lens (PS-20).</p>';
    }
    h += '<p class="footnote">Evidence assembled by the system; conclusions are yours — no automated root-cause (f-s3-018).</p>';
    return h + '</section>';
  }

  function evidenceLens(key, label, items) {
    var open = STATE.open[key] !== false; // lenses default open
    return '<div class="lens-panel"><button type="button" data-action="expand" data-key="' + esc(key) + '" data-def="1" aria-expanded="' + open + '">' + esc(label) + (open ? ' ▴' : ' ▾') + '</button>' +
      (open ? '<div class="lens-body"><ul>' + items.map(function (i) { return '<li>' + i + '</li>'; }).join('') + '</ul></div>' : '') + '</div>';
  }
  function dataFactors(m) {
    var items = m.kpis.filter(function (k) { return k.metricType === 'dq'; }).map(function (k) {
      return esc(k.code + ' ' + k.name) + ': ' + k.latest + ' ' + esc(k.unit) + ' ' + chip(kst(k), kst(k), k.thresholdRule) + ' ' + kpiMove(k) + ' ' + spark(k);
    });
    (m.upstream || []).forEach(function (uid) {
      var u = modelById(uid); var us = modelStatus(u);
      items.push('Upstream ' + esc(u.name) + ': ' + chip(us.rag, us.rag) + (us.hasAck ? ' (acknowledged position)' : '') + ' — <a href="#/model/' + uid + '">open its room</a>');
    });
    if (m.notes) items.push('Feed / data note: ' + esc(m.notes));
    if (!items.length) items.push('No data-quality KPIs or upstream feeds flagged.');
    return items;
  }
  function modelFactors(m) {
    var items = m.kpis.filter(function (k) { return k.metricType === 'perf'; }).map(function (k) {
      return esc(k.code + ' ' + k.name) + ': ' + k.latest + ' ' + esc(k.unit) + ' ' + chip(kst(k), kst(k), k.thresholdRule) + ' ' + kpiMove(k) + ' ' + spark(k);
    });
    var vs = m.runs.map(function (r) { return r.codeVersion; });
    items.push(vs[0] === vs[vs.length - 1]
      ? 'Run deltas: code version unchanged across the last ' + m.runs.length + ' runs (' + esc(vs[0]) + ') — change is in the population or inputs, not the code.'
      : 'Run deltas: code version moved ' + esc(vs[vs.length - 1]) + ' → ' + esc(vs[0]) + ' across the last ' + m.runs.length + ' runs — check the release.');
    return items;
  }
  function processFactors(m) {
    var items = [];
    TICKETS.filter(function (t) { return t.modelId === m.id; }).forEach(function (t) {
      var e = t.eventLog[t.eventLog.length - 1];
      items.push('Ticket ' + esc(t.ref) + ' (' + esc(t.state) + '): ' + esc(e.what));
    });
    items.push('Last run trigger: ' + esc(m.lastRun.trigger) + ' · environment ' + esc(m.environment) + '.');
    items.push('No process changes declared this cycle (declarable breach context: ' + esc(m.breach ? m.breach.classification + ', ' + m.breach.stage : 'none') + ').');
    return items;
  }

  // ============================================================
  // PORTFOLIO — lineage-first, honest numbers, tier stack,
  // deterioration, trend, concentration, exec hypothesis
  // (PS-01…PS-07, PS-21 filters — M5)
  // ============================================================
  function fmodels() {
    return MODELS.filter(function (m) { return STATE.fn === 'All' || m.function === STATE.fn; });
  }
  function dispStatus(m) { // portfolio counting category: red / amber / ack / green (PS-01/PS-08)
    var s = modelStatus(m);
    if (s.ackedOnly) return 'ack';
    return s.rag;
  }

  function viewPortfolio() {
    var ms = fmodels();
    var counts = { red: 0, amber: 0, ack: 0, green: 0 };
    ms.forEach(function (m) { counts[dispStatus(m)]++; });
    var h = '<div class="wrap"><h1>Portfolio</h1>' +
      '<div class="q-meta" style="align-items:center;margin-bottom:12px"><span class="fn-filter" role="group" aria-label="Function filter">' +
      ['All', 'Finance', 'Treasury'].map(function (f) {
        return '<button type="button" class="' + (STATE.fn === f ? 'active' : '') + '" data-action="fn" data-fn="' + f + '">' + f + '</button>';
      }).join('') + '</span>' +
      '<span class="reconcile">Showing ' + ms.length + ' of 12 models — ' + counts.red + ' red · ' + counts.amber + ' amber · ' + counts.ack + ' acknowledged · ' + counts.green + ' green (reconciles: ' + (counts.red + counts.amber + counts.ack + counts.green) + ').</span></div>';

    h += lineageSection(ms);      // (a) PS-03 — lineage first
    h += honestNumbers(ms);       // (b) PS-01 — KPI-tier counts, not a doughnut
    h += tierStack(ms);           // (c) PS-02 — client FR-2
    h += deterioration(ms);       // (d) PS-06
    h += trendSection(ms);        // (e) PS-05
    h += concentration(ms);       // (f) PS-04
    h += execStrip(ms, counts);   // (g) PS-07 — hypothesis
    return h + '</div>';
  }

  // (a) Lineage map — where trouble propagates (PS-03, IN-10, un-07)
  function lineageSection(ms) {
    var inSet = {}; ms.forEach(function (m) { inSet[m.id] = true; });
    // connected components over upstream edges
    var parent = {};
    function find(x) { while (parent[x] !== x) { parent[x] = parent[parent[x]]; x = parent[x]; } return x; }
    ms.forEach(function (m) { parent[m.id] = m.id; });
    ms.forEach(function (m) {
      (m.upstream || []).forEach(function (u) {
        if (inSet[u]) parent[find(u)] = find(m.id);
      });
    });
    var comps = {};
    ms.forEach(function (m) { var r = find(m.id); (comps[r] = comps[r] || []).push(m); });
    function depth(m, seen) {
      seen = seen || {};
      var ups = (m.upstream || []).filter(function (u) { return inSet[u] && !seen[u]; });
      if (!ups.length) return 0;
      return 1 + Math.max.apply(null, ups.map(function (u) { seen[u] = 1; return depth(modelById(u), seen); }));
    }
    var chains = [], standalone = [];
    Object.keys(comps).forEach(function (r) {
      if (comps[r].length === 1) standalone.push(comps[r][0]);
      else chains.push(comps[r]);
    });
    function node(m) {
      var s = modelStatus(m);
      return '<a class="lnode rag-' + s.rag + '" href="#/model/' + m.id + '"><span class="ln-name">' + esc(m.name) + '</span> ' + statusChip(m) +
        (s.hasAck ? '<br>' + ackBadge(m) : '') +
        '<div class="ln-meta">' + esc(m.function) + ' · ' + esc(m.materiality) + (m.symptomOf ? ' · <span class="symptom-tag">symptom of ↑</span>' : '') + '</div></a>';
    }
    var h = '<section class="card"><h2>Lineage — which models feed which</h2>' +
      '<p class="section-note">The portfolio reads lineage-first: trouble propagates left to right — the inherited-breach question before the concentration cuts (PS-03).</p>';
    chains.forEach(function (comp) {
      var cols = [];
      comp.forEach(function (m) {
        var d = depth(m);
        (cols[d] = cols[d] || []).push(m);
      });
      h += '<div class="chain-row">' + cols.map(function (col) {
        return '<div class="chain-col">' + col.map(node).join('') + '</div>';
      }).join('<span class="chain-arrow" aria-hidden="true">→</span>') + '</div>';
    });
    if (standalone.length) {
      h += '<h3>No declared lineage</h3><div class="standalone-grid">' + standalone.map(node).join('') + '</div>';
    }
    return h + '</section>';
  }

  // (b) Honest numbers — KPI-tier counts with acknowledged split (PS-01, replaces US-1/FR-1 doughnut)
  function honestNumbers(ms) {
    var c = { key: { red: 0, amber: 0, green: 0 }, non: { red: 0, amber: 0, green: 0 }, ack: 0 };
    ms.forEach(function (m) {
      m.kpis.forEach(function (k) {
        if (ackOf(m, k) && kst(k) !== 'green') { c.ack++; return; }
        c[k.isKey ? 'key' : 'non'][kst(k)]++;
      });
    });
    function tiles(o, lbl) {
      return ['red', 'amber', 'green'].map(function (r) {
        return '<div class="count-tile rag-' + r + '"><span class="n">' + o[r] + '</span><span class="lbl">' + lbl + ' ' + r + '</span></div>';
      }).join('');
    }
    return '<section class="card"><h2>Honest numbers — KPI-tier status counts</h2>' +
      '<p class="section-note">Replaces the client’s US-1/FR-1 doughnut of bare aggregate model colours (PS-01): Key vs non-Key KPI statuses, with acknowledged positions counted separately — never blended in.</p>' +
      '<div class="tier-counts">' + tiles(c.key, 'Key') + tiles(c.non, 'Non-key') +
      '<div class="count-tile ackd"><span class="n">' + c.ack + '</span><span class="lbl">Acknowledged</span></div></div></section>';
  }

  // (c) Risk-tier stack — VH/H/M/L × status, segments click through with the why (PS-02)
  function tierStack(ms) {
    var tiers = ['VH', 'H', 'M', 'L'];
    var h = '<section class="card"><h2>Risk-tier stack</h2>' +
      '<p class="section-note">Adopts the client’s FR-2 — each segment clicks through to the models behind it, carrying the why (PS-02). Acknowledged shows as its own split, e.g. “3 amber · 1 acknowledged”.</p>';
    tiers.forEach(function (tier) {
      var tms = ms.filter(function (m) { return m.riskTier === tier; });
      if (!tms.length) { h += '<div class="stack-row"><span class="tier-lbl">' + tier + '</span><span class="tiny muted">none in filter</span></div>'; return; }
      var segs = ['red', 'amber', 'ack', 'green'].map(function (st) {
        var n = tms.filter(function (m) { return dispStatus(m) === st; }).length;
        if (!n) return '';
        return '<button type="button" class="seg rag-' + st + '" style="flex:' + n + '" data-action="tierseg" data-tier="' + tier + '" data-status="' + st + '" title="' + n + ' ' + (st === 'ack' ? 'acknowledged' : st) + ' — click to list">' + n + (st === 'ack' ? ' ack' : '') + '</button>';
      }).join('');
      h += '<div class="stack-row"><span class="tier-lbl">' + tier + ' <span class="tiny">(' + tms.length + ')</span></span><div class="stack-bar">' + segs + '</div></div>';
    });
    if (STATE.tierFilter) {
      var f = STATE.tierFilter;
      var list = ms.filter(function (m) { return m.riskTier === f.tier && dispStatus(m) === f.status; });
      h += '<div class="decision-box"><b>' + f.tier + ' × ' + (f.status === 'ack' ? 'acknowledged' : f.status) + ':</b> ' +
        list.map(function (m) { return '<a href="#/model/' + m.id + '">' + esc(m.name) + '</a> ' + statusChip(m) + ' ' + ackBadge(m); }).join(' · ') +
        ' <button type="button" class="linklike" data-action="tierseg" data-tier="" data-status="">clear</button></div>';
    }
    return h + '</section>';
  }

  // (d) Deterioration — KPI downgrades latest-vs-previous, ranked & chain-grouped (PS-06)
  function deterioration(ms) {
    var det = ms.filter(function (m) { return kpiDowngrades(m).length; })
      .sort(function (a, b) { return score(b) - score(a); });
    var ids = {}; det.forEach(function (m) { ids[m.id] = true; });
    var rows = [];
    det.forEach(function (m) { if (!(m.symptomOf && ids[m.symptomOf])) rows.push(m); });
    var h = '<section class="card"><h2>Deterioration</h2>' +
      '<p class="section-note">Models whose KPIs downgraded latest-vs-previous run — ordered by materiality × execution proximity, chain-grouped (PS-06, un-13).</p>';
    function row(m, sym) {
      return '<div class="q-row' + (sym ? ' symptom' : '') + '"><div class="q-head">' +
        (sym ? '<span class="symptom-tag">symptom of ↑</span>' : '') +
        '<span class="name"><a href="#/model/' + m.id + '">' + esc(m.name) + '</a></span> ' + statusChip(m) + ' ' + ackBadge(m) +
        '<span class="tiny" style="margin-left:auto">' + esc(rankDriver(m)) + '</span></div>' +
        '<p class="q-why">' + kpiDowngrades(m).map(function (k) {
          return esc(k.code) + ' ' + chip(ragOf(k, k.previous), ragOf(k, k.previous)) + ' → ' + chip(kst(k), kst(k), k.thresholdRule) + ' (' + k.previous + ' → ' + k.latest + ' ' + esc(k.unit) + ')';
        }).join(' · ') + '</p></div>';
    }
    rows.forEach(function (m) {
      h += row(m, false);
      det.forEach(function (x) { if (x.symptomOf === m.id) h += row(x, true); });
    });
    if (!rows.length) h += '<p class="muted small">No downgrades between the last two runs.</p>';
    return h + '</section>';
  }

  // (e) 12-month trend — month-end R/A/G model counts (PS-05, provisional on DN-13)
  function trendSection(ms) {
    var series = { red: [], amber: [], green: [] };
    for (var i = 0; i < 12; i++) {
      var c = { red: 0, amber: 0, green: 0 };
      ms.forEach(function (m) { c[modelStatus(m, i).rag]++; });
      series.red.push(c.red); series.amber.push(c.amber); series.green.push(c.green);
    }
    var W = 640, H = 170, max = ms.length || 1;
    function line(vals, colour) {
      var pts = vals.map(function (v, i) {
        return (40 + i * ((W - 60) / 11)) + ',' + (H - 30 - (v / max) * (H - 50));
      }).join(' ');
      return '<polyline points="' + pts + '" fill="none" stroke="' + colour + '" stroke-width="2.5"/>';
    }
    var labels = META.months.map(function (mo, i) {
      return '<text x="' + (40 + i * ((W - 60) / 11)) + '" y="' + (H - 10) + '" font-size="10" fill="var(--ink-400)" text-anchor="middle">' + mo + '</text>';
    }).join('');
    return '<section class="card"><h2>12-month trend</h2>' +
      '<svg width="100%" viewBox="0 0 ' + W + ' ' + H + '" role="img" aria-label="Month-end red, amber and green model counts over 12 months">' +
      '<line x1="40" y1="' + (H - 30) + '" x2="' + (W - 20) + '" y2="' + (H - 30) + '" stroke="var(--ink-200)"/>' +
      line(series.green, 'var(--rag-green-solid)') + line(series.amber, 'var(--rag-amber-solid)') + line(series.red, 'var(--rag-red-solid)') +
      labels + '</svg>' +
      '<div class="legend"><span><span class="dot rag-red"></span>Red</span><span><span class="dot rag-amber"></span>Amber (incl. acknowledged)</span><span><span class="dot rag-green"></span>Green</span></div>' +
      '<p class="tiny">Model-level series provisional on DN-13 — the aggregation rule behind these lines is assumed; each point derives from the same computable rule as the status chips (PS-05).</p></section>';
  }

  // (f) Concentration by accountable owner (PS-04, IN-06)
  function concentration(ms) {
    var byOwner = {};
    ms.forEach(function (m) { (byOwner[m.accountableOwner] = byOwner[m.accountableOwner] || []).push(m); });
    var owners = Object.keys(byOwner).sort(function (a, b) { return byOwner[b].length - byOwner[a].length; });
    var max = owners.length ? byOwner[owners[0]].length : 1;
    return '<section class="card"><h2>Concentration by accountable owner</h2>' +
      '<p class="section-note">Owner = the accountable duty, distinct from who does the work — every owner interviewed is a delegate (PS-04, IN-06).</p>' +
      owners.map(function (o) {
        var list = byOwner[o];
        return '<div class="owner-row"><span class="o-name">' + esc(o) + '</span>' +
          '<div class="owner-bar" style="width:' + (list.length / max) * 45 + '%"></div>' +
          '<span>' + list.length + '</span><span class="owner-dots">' + list.map(function (m) {
            return '<span class="dot rag-' + dispStatus(m) + '" title="' + esc(m.name) + ' — ' + dispStatus(m) + '"></span>';
          }).join('') + '</span></div>';
      }).join('') + '</section>';
  }

  // (g) Exec summary strip — explicitly a hypothesis (PS-07, DN-14)
  function execStrip(ms, counts) {
    var next = ms.filter(function (m) { return dispStatus(m) !== 'green'; })
      .sort(function (a, b) { return daysUntil(a.nextExecution) - daysUntil(b.nextExecution); })[0];
    return '<section class="card exec-strip"><span class="hypothesis-banner">Hypothesis — to be corrected by exec interview (PS-07)</span>' +
      '<h2 style="margin-top:0">Exec summary</h2>' +
      '<p class="small">' + counts.red + ' red model' + (counts.red === 1 ? '' : 's') + ' — every red is under active work; ' +
      counts.amber + ' amber · ' + counts.ack + ' acknowledged (accepted positions, rationale on record); ' +
      (next ? 'next material execution: ' + esc(next.name) + ' ' + (daysUntil(next.nextExecution) <= 0 ? 'today' : 'in ' + daysUntil(next.nextExecution) + 'd') + '.' : 'no imminent executions.') + '</p>' +
      '<p class="tiny">This strip is deliberately unvalidated: no exec has been interviewed (DN-14 is evidentially thin). It exists to be corrected by Andrew Wells — and says so rather than inventing content (PS-24).</p></section>';
  }

  // ============================================================
  // ACTIONS — all in-memory; every mutation re-renders (happy path)
  // ============================================================
  function doTriage(act, mid) { // PS-15: mandatory rationale; PS-16: escalate mints a ticket
    var m = modelById(mid);
    var rat = (STATE.drafts['rat-' + mid] || '').trim();
    if (!rat) { STATE.flash['q-' + mid] = 'Rationale is mandatory on every triage decision (PS-15).'; return; }
    delete STATE.flash['q-' + mid];
    var who = m.delegate + ' (fixer duty)';
    if (act === 'ack') { // acknowledged-state becomes first-class everywhere (PS-08)
      var k = drivingKpi(m);
      STATE.acks[mid + ':' + k.code] = { rationale: rat, who: who, at: META.today };
      STATE.triaged[mid] = { action: 'Acknowledged' };
    } else if (act === 'esc') {
      var ref = 'PROTO-' + (STATE.seq++);
      var kk = drivingKpi(m);
      TICKETS.unshift({
        ref: ref, type: 'Investigation', modelId: mid, kpiCode: kk ? kk.code : null,
        title: (kk ? kk.code + ' ' + kk.name : 'Exception') + ' — investigate',
        assignee: m.developer, byWhen: addDays(META.today, 7), state: 'Open', openedAt: META.today,
        eventLog: [
          { at: m.breach ? m.breach.openedAt : META.today, who: 'System', what: 'Breach opened — ' + (kk ? kk.code + ' ' + kst(kk) : 'exception raised') + '.' },
          { at: META.today, who: who, what: 'Triaged: severity ' + draft('sev-' + mid, m.breach ? m.breach.suggestedSeverity : 'Medium') + ', materiality ' + draft('mat-' + mid, m.materiality) + '. Rationale: “' + rat + '”. Escalated → ticket minted with assignee ' + m.developer + ' (Jira mock).' }
        ]
      });
      STATE.triaged[mid] = { action: 'Escalated', ref: ref };
    } else if (act === 'rej') {
      STATE.triaged[mid] = { action: 'Rejected', rationale: rat };
    }
    STATE.open['q-' + mid] = false;
    delete STATE.drafts['rat-' + mid];
  }

  function doTicket(act, ref) { // M4 — owner decides; fixer implements & validates
    var t = ticketByRef(ref);
    var m = modelById(t.modelId);
    var note = (STATE.drafts['note-' + ref] || '').trim();
    var owner = m.accountableOwner + ' (owner duty)';
    var fixer = t.assignee + ' (fixer duty)';
    if (['approve', 'revise', 'reject'].indexOf(act) >= 0 && !note) {
      STATE.flash['tk-' + ref] = 'An audit note is mandatory on owner decisions (M4).'; return;
    }
    delete STATE.flash['tk-' + ref];
    if (act === 'approve') {
      t.state = 'In progress';
      t.eventLog.push({ at: META.today, who: owner, what: 'Approved with audit note: “' + note + '”. Moved to In progress.' });
    } else if (act === 'revise') {
      t.state = 'Open';
      t.eventLog.push({ at: META.today, who: owner, what: 'Revisions requested: “' + note + '”. Back with the fixer duty.' });
    } else if (act === 'reject') {
      t.state = 'Rejected';
      t.eventLog.push({ at: META.today, who: owner, what: 'Rejected with audit note: “' + note + '”.' });
    } else if (act === 'validate') { // simulated post-implementation KPI reading
      var k = kpiByCode(m, t.kpiCode) || drivingKpi(m);
      var after = k.dir === 'lt' ? +(k.green * 0.7).toFixed(2) : +(k.green + Math.abs(k.green - k.amber) * 0.3).toFixed(2);
      t.validation = { kpi: k.code, before: k.latest, after: after };
      t.state = 'Validating';
      t.eventLog.push({ at: META.today, who: fixer, what: 'Implemented; validation re-run executed — ' + k.code + ' ' + k.latest + ' → ' + after + ' ' + k.unit + ' (green).' });
    } else if (act === 'resolve') { // status recomputes; closure evidence appended (qb-o08)
      var kr = kpiByCode(m, t.kpiCode) || drivingKpi(m);
      if (t.validation) { kr.history.push(t.validation.after); kr.history.shift(); kr.latest = t.validation.after; kr.previous = kr.history[kr.history.length - 2]; }
      t.state = 'Resolved'; t.closedAt = META.today;
      t.closureEvidence = 'Post-implementation reading ' + kr.code + ' = ' + kr.latest + ' ' + kr.unit + ' (green). Model status recomputed ' + modelStatus(m).rag + ' on ' + fmtD(META.today) + '.';
      t.eventLog.push({ at: META.today, who: 'System', what: 'Resolved — closure evidence attached; model status recomputed ' + modelStatus(m).rag + '.' });
      delete STATE.triaged[m.id];
    } else if (act === 'iterate') { // spawns a new M3
      t.state = 'Iterating';
      var ref2 = 'PROTO-' + (STATE.seq++);
      t.eventLog.push({ at: META.today, who: fixer, what: 'Validation not accepted — iterating: new investigation ' + ref2 + ' spawned.' });
      TICKETS.unshift({
        ref: ref2, type: 'Investigation', modelId: m.id, kpiCode: t.kpiCode,
        title: 'Iteration of ' + t.ref + ' — ' + t.title,
        assignee: t.assignee, byWhen: addDays(META.today, 7), state: 'Open', openedAt: META.today,
        eventLog: [{ at: META.today, who: fixer, what: 'Spawned from ' + t.ref + ' after validation re-run — evidence carried over (M4 → M3).' }]
      });
      location.hash = '#/work/' + ref2;
    }
  }

  function doFileRem(ref) { // M3 → M4: analyst conclusion + recommendation → remediation ticket
    var t = ticketByRef(ref);
    var m = modelById(t.modelId);
    var conc = (STATE.drafts['conc-' + ref] || '').trim();
    var action = (STATE.drafts['act-' + ref] || '').trim();
    if (!conc || !action) { STATE.flash['inv-' + ref] = 'Analyst conclusion and recommended action are both required — the system assembles, you conclude (PS-17).'; return; }
    delete STATE.flash['inv-' + ref];
    var cat = draft('cat-' + ref, t.category || 'Model');
    var tl = draft('tl-' + ref, addDays(META.today, 14));
    var imp = draft('imp-' + ref, 'Medium');
    var ref2 = 'PROTO-' + (STATE.seq++);
    TICKETS.unshift({
      ref: ref2, type: 'Remediation', modelId: m.id, kpiCode: t.kpiCode, category: cat,
      title: action, assignee: m.developer, byWhen: tl, state: 'Awaiting approval', openedAt: META.today,
      eventLog: [
        { at: META.today, who: t.assignee + ' (fixer duty)', what: 'Recommendation filed from ' + t.ref + '. Conclusion: “' + conc + '”. Impact: ' + imp + '. Category: ' + cat + '.' },
        { at: META.today, who: 'System', what: 'Awaiting approval — owner decision required (' + m.accountableOwner + ').' }
      ]
    });
    t.state = 'Resolved'; t.closedAt = META.today;
    t.closureEvidence = 'Analyst conclusion: “' + conc + '” (impact ' + imp + '). Remediation ' + ref2 + ' recommended for owner approval.';
    t.eventLog.push({ at: META.today, who: t.assignee + ' (fixer duty)', what: 'Conclusion authored; remediation ' + ref2 + ' filed for owner approval (M4).' });
    location.hash = '#/work/' + ref2;
  }

  // ============================================================
  // HEADER / ROUTER / EVENTS
  // ============================================================
  function renderHeader(hash) {
    document.querySelectorAll('.lens-btn').forEach(function (b) {
      b.classList.toggle('active', b.getAttribute('data-lens') === STATE.lens);
    });
    var view = hash.slice(2).split('/')[0] || 'home';
    if (view === 'model') view = 'queue';
    var emph = { fixer: 'queue', owner: 'work', governance: 'portfolio' }[STATE.lens];
    document.querySelectorAll('.mainnav a').forEach(function (a) {
      a.classList.toggle('active', a.getAttribute('data-nav') === view);
      a.classList.toggle('emph', a.getAttribute('data-nav') === emph); // nav emphasis follows the lens (PS-20)
    });
    var bell = $('#bell');
    bell.setAttribute('aria-pressed', String(!STATE.signalsDismissed));
    $('#bell-count').textContent = DATA.signals.length;
  }

  function render() {
    var hash = location.hash || '#/home';
    renderHeader(hash);
    renderSignals();
    var parts = hash.slice(2).split('/');
    var app = $('#app');
    if (parts[0] === 'queue') app.innerHTML = viewQueue();
    else if (parts[0] === 'model' && parts[1]) app.innerHTML = viewModel(parts[1]);
    else if (parts[0] === 'work' && parts[1]) app.innerHTML = viewTicket(parts[1]);
    else if (parts[0] === 'work') app.innerHTML = viewWork();
    else if (parts[0] === 'portfolio') app.innerHTML = viewPortfolio();
    else app.innerHTML = viewHome();
  }

  document.addEventListener('click', function (e) {
    var el = e.target.closest('[data-action]');
    if (!el) return;
    var a = el.getAttribute('data-action');
    if (a === 'lens') { STATE.lens = el.getAttribute('data-lens'); }
    else if (a === 'toggle-signals') { STATE.signalsDismissed = !STATE.signalsDismissed; }
    else if (a === 'dismiss-signals') { STATE.signalsDismissed = true; }
    else if (a === 'expand') {
      var key = el.getAttribute('data-key');
      // evidence lenses default open (data-def) — first click closes
      if (el.getAttribute('data-def') && STATE.open[key] === undefined) STATE.open[key] = false;
      else STATE.open[key] = !STATE.open[key];
    }
    else if (a === 'triage') { doTriage(el.getAttribute('data-act'), el.getAttribute('data-model')); }
    else if (a === 'tk') { doTicket(el.getAttribute('data-act'), el.getAttribute('data-ref')); }
    else if (a === 'file-rem') { doFileRem(el.getAttribute('data-ref')); }
    else if (a === 'pack') { var mid = el.getAttribute('data-model'); STATE.packOpen[mid] = !STATE.packOpen[mid]; }
    else if (a === 'fn') { STATE.fn = el.getAttribute('data-fn'); STATE.tierFilter = null; }
    else if (a === 'tierseg') {
      var tier = el.getAttribute('data-tier');
      STATE.tierFilter = tier ? { tier: tier, status: el.getAttribute('data-status') } : null;
    }
    else return;
    render();
  });

  // form values survive re-renders (in memory only)
  document.addEventListener('input', function (e) {
    if (e.target.id && e.target.closest('[data-form]')) STATE.drafts[e.target.id] = e.target.value;
  });
  document.addEventListener('change', function (e) {
    if (e.target.id && e.target.closest('[data-form]')) STATE.drafts[e.target.id] = e.target.value;
  });

  window.addEventListener('hashchange', render);
  if (!location.hash) location.hash = '#/home';
  render();
})();
