/* ============================================================
   MPMP · Monitoring & Remediation V2 — fixture (window.DATA)
   Fabricated data, prototype only. Model-level statuses are NOT
   stored here: app.js computes them from KPI values via the
   assumed aggregation rule (DN-13 unresolved — PS-08).
   KPI histories are 12 runs, oldest → newest (Aug 2025 → Jul 2026).
   ============================================================ */
(function () {
  'use strict';

  // Flat-ish 12-run history with a deterministic wobble (kept inside thresholds).
  function wob(v, amp) {
    var p = [0, 1, -1, 0, 1, 0, -1, 1, 0, -1, 0, 0];
    return p.map(function (d) { return +(v + d * amp).toFixed(3); });
  }

  // KPI builder. dir 'lt' = lower is better, 'gt' = higher is better.
  // Threshold rule rendered as visible text (PS-09).
  function K(code, name, isKey, metricType, unit, dir, green, amber, history, acknowledged) {
    return {
      code: code, name: name, isKey: isKey, metricType: metricType, unit: unit,
      dir: dir, green: green, amber: amber,
      thresholdRule: dir === 'lt'
        ? '< ' + green + ' → green; ≤ ' + amber + ' → amber; else red'
        : '≥ ' + green + ' → green; ≥ ' + amber + ' → amber; else red',
      history: history,
      acknowledged: acknowledged || null
    };
  }

  var MODELS = [
    {
      id: 'm01', name: 'Macro Scenario Feed', kind: 'Upstream data publisher',
      function: 'Finance', businessArea: 'Group Economics',
      materiality: 'High', riskTier: 'H',
      accountableOwner: 'Sarah McAllister', delegate: 'Tom Ferris', developer: 'Ana Kovač',
      version: 'v3.2', environment: 'On-prem', nextExecution: '2026-07-24',
      upstream: [],
      breach: { openedAt: '2026-07-13', slaDays: 5, suggestedSeverity: 'High', classification: 'Data', stage: 'Ingestion — vendor macro file' },
      notes: 'Vendor delivery on 10 Jul arrived truncated: two scenario blocks (adverse, severely adverse) missing whole variable sets.',
      linksOut: [
        { kind: 'S3', label: 'Daily ingest check-pack (S3)' },
        { kind: 'Confluence', label: 'Feed runbook — vendor escalation path' }
      ],
      runs: [
        { executedAt: '2026-07-22 06:10', runtime: '14m', status: 'Succeeded with warnings', codeVersion: 'v3.2.0', trigger: 'Scheduled (daily)' },
        { executedAt: '2026-07-21 06:09', runtime: '13m', status: 'Succeeded with warnings', codeVersion: 'v3.2.0', trigger: 'Scheduled (daily)' },
        { executedAt: '2026-07-20 06:11', runtime: '15m', status: 'Succeeded', codeVersion: 'v3.2.0', trigger: 'Scheduled (daily)' }
      ],
      kpis: [
        K('MSF-DQ1', 'Feed completeness', true, 'dq', '%', 'gt', 99.5, 98.0, [99.9, 99.8, 99.9, 99.7, 99.8, 99.6, 99.7, 99.6, 99.6, 99.1, 98.4, 96.4]),
        K('MSF-DQ2', 'Delivery timeliness', true, 'dq', 'hrs late', 'lt', 2, 6, wob(1.0, 0.4)),
        K('MSF-DQ3', 'Schema conformance', false, 'dq', '%', 'gt', 99, 97, wob(99.9, 0.05)),
        K('MSF-DQ4', 'Outlier rate', false, 'dq', '%', 'lt', 1.0, 2.5, [0.6, 0.7, 0.5, 0.8, 0.7, 0.6, 0.9, 0.8, 0.7, 0.8, 0.9, 1.8]),
        K('MSF-DQ5', 'Scenario coverage', false, 'dq', 'scenarios', 'gt', 9, 7, wob(12, 0)),
        K('MSF-DQ6', 'Variable dictionary conformance', false, 'dq', '%', 'gt', 99, 97, wob(99.8, 0.05))
      ]
    },
    {
      id: 'm02', name: 'Climate Transition Plan Forecast', kind: 'Model',
      function: 'Finance', businessArea: 'Climate Hub',
      materiality: 'Medium', riskTier: 'M',
      accountableOwner: 'Sarah McAllister', delegate: 'Tom Ferris', developer: 'Nadia Rahman',
      version: 'v1.4', environment: 'SageMaker', nextExecution: '2026-08-12',
      upstream: ['m09'],
      breach: { openedAt: '2026-07-06', slaDays: 10, suggestedSeverity: 'Medium', classification: 'Data', stage: 'Input assembly — vendor coverage' },
      notes: 'Vendor climate dataset has a persistent coverage gap on Scope 3 emissions factors for mid-cap counterparties.',
      linksOut: [
        { kind: 'Tableau', label: 'Climate pathways workbook' },
        { kind: 'Confluence', label: 'Vendor data-gap tracker' }
      ],
      runs: [
        { executedAt: '2026-07-12 21:40', runtime: '1h 52m', status: 'Succeeded', codeVersion: 'v1.4.2', trigger: 'Scheduled (monthly)' },
        { executedAt: '2026-06-12 21:35', runtime: '1h 49m', status: 'Succeeded', codeVersion: 'v1.4.2', trigger: 'Scheduled (monthly)' },
        { executedAt: '2026-05-12 21:38', runtime: '1h 55m', status: 'Succeeded', codeVersion: 'v1.4.1', trigger: 'Scheduled (monthly)' }
      ],
      kpis: [
        // Acknowledged Amber — first-class state (PS-08; f-s2-009 flavour)
        K('CTP-DQ1', 'Vendor data coverage', true, 'dq', '%', 'gt', 95, 88,
          [96.1, 95.8, 95.2, 94.9, 94.1, 93.6, 93.2, 92.8, 92.6, 92.5, 92.4, 92.1],
          { rationale: 'Climate vendor data gap — accepted, out of team’s control', who: 'Tom Ferris (fixer duty)', at: '2026-07-08' }),
        K('CTP-PM1', 'Scenario RMSE', true, 'perf', 'index', 'lt', 0.15, 0.25, wob(0.11, 0.01)),
        K('CTP-PM2', 'Pathway back-test error', false, 'perf', '%', 'lt', 8, 12, wob(6.4, 0.5)),
        K('CTP-DQ2', 'Emissions factor freshness', false, 'dq', 'days', 'lt', 45, 90, wob(30, 4)),
        K('CTP-OP1', 'Run success rate', false, 'ops', '%', 'gt', 98, 95, wob(100, 0))
      ]
    },
    {
      id: 'm03', name: 'Retail PD Model', kind: 'Model',
      function: 'Finance', businessArea: 'Retail Credit Risk',
      materiality: 'Very High', riskTier: 'VH',
      accountableOwner: 'James Okonkwo', delegate: 'Meera Shah', developer: 'Callum Reid',
      version: 'v5.1', environment: 'SageMaker', nextExecution: '2026-08-03',
      upstream: [],
      linksOut: [
        { kind: 'Tableau', label: 'PD monitoring workbook' },
        { kind: 'S3', label: 'Monthly check-pack (S3)' }
      ],
      runs: [
        { executedAt: '2026-07-03 02:15', runtime: '38m', status: 'Succeeded', codeVersion: 'v5.1.3', trigger: 'Scheduled (monthly)' },
        { executedAt: '2026-06-03 02:14', runtime: '37m', status: 'Succeeded', codeVersion: 'v5.1.3', trigger: 'Scheduled (monthly)' },
        { executedAt: '2026-05-28 11:02', runtime: '39m', status: 'Succeeded', codeVersion: 'v5.1.3', trigger: 'Manual (post-recalibration validation)' }
      ],
      kpis: [
        K('RPD-PM1', 'Gini coefficient', true, 'perf', 'ratio', 'gt', 0.55, 0.48, wob(0.62, 0.01)),
        // Q2 population shift, recalibrated via PROTO-2029 (closed 2 Jul) — drift then fix.
        K('RPD-PM2', 'Population stability index', true, 'perf', 'index', 'lt', 0.10, 0.25, [0.06, 0.07, 0.09, 0.12, 0.18, 0.27, 0.24, 0.11, 0.07, 0.06, 0.06, 0.06]),
        K('RPD-CAL1', 'Calibration error', false, 'perf', '%', 'lt', 5, 10, wob(3.1, 0.3)),
        K('RPD-DQ1', 'Missing-field rate', false, 'dq', '%', 'lt', 2, 5, [1.4, 1.6, 1.5, 1.8, 1.7, 1.9, 2.1, 2.2, 2.4, 2.3, 2.5, 2.6]),
        K('RPD-DQ2', 'Bureau feed completeness', false, 'dq', '%', 'gt', 99, 97, wob(99.7, 0.1)),
        K('RPD-OP1', 'Run success rate', false, 'ops', '%', 'gt', 98, 95, wob(100, 0))
      ]
    },
    {
      id: 'm04', name: 'IFRS9 Impairment Engine', kind: 'Model',
      function: 'Finance', businessArea: 'Finance — Impairment',
      materiality: 'Very High', riskTier: 'VH',
      accountableOwner: 'Sarah McAllister', delegate: 'Tom Ferris', developer: 'Ana Kovač',
      version: 'v4.0', environment: 'On-prem', nextExecution: '2026-07-27',
      upstream: ['m01', 'm03'],
      symptomOf: 'm01', // downstream amber explained by the upstream feed breach (PS-13/A3)
      breach: { openedAt: '2026-07-14', slaDays: 10, suggestedSeverity: 'Medium', classification: 'Data (inherited)', stage: 'Input assembly — macro scenarios' },
      linksOut: [
        { kind: 'Tableau', label: 'ECL movement workbook' },
        { kind: 'Confluence', label: 'Impairment run governance page' }
      ],
      runs: [
        { executedAt: '2026-07-14 23:05', runtime: '3h 41m', status: 'Succeeded with warnings', codeVersion: 'v4.0.1', trigger: 'Scheduled (monthly)' },
        { executedAt: '2026-06-14 23:02', runtime: '3h 38m', status: 'Succeeded', codeVersion: 'v4.0.1', trigger: 'Scheduled (monthly)' },
        { executedAt: '2026-05-14 23:04', runtime: '3h 44m', status: 'Succeeded', codeVersion: 'v4.0.0', trigger: 'Scheduled (monthly)' }
      ],
      kpis: [
        K('IFRS-DQ1', 'Macro input completeness', true, 'dq', '%', 'gt', 99, 95, [99.8, 99.7, 99.8, 99.6, 99.7, 99.5, 99.6, 99.4, 99.5, 99.3, 99.2, 95.8]),
        K('IFRS-PM1', 'ECL coverage variance', true, 'perf', '%', 'lt', 5, 9, wob(4.2, 0.3)),
        K('IFRS-PM2', 'Stage-2 migration stability', false, 'perf', 'index', 'lt', 0.12, 0.2, wob(0.09, 0.01)),
        K('IFRS-DQ2', 'Account reconciliation breaks', false, 'dq', 'accounts', 'lt', 50, 200, wob(12, 4)),
        K('IFRS-OP1', 'Runtime vs baseline', false, 'ops', '%', 'lt', 120, 150, wob(104, 3)),
        K('IFRS-PM3', 'Overlay proportion of ECL', false, 'perf', '%', 'lt', 10, 18, wob(8.9, 0.4))
      ]
    },
    {
      id: 'm05', name: 'Wholesale LGD Model', kind: 'Model',
      function: 'Finance', businessArea: 'Commercial Credit Risk',
      materiality: 'High', riskTier: 'H',
      accountableOwner: 'James Okonkwo', delegate: 'Meera Shah', developer: 'Callum Reid',
      version: 'v2.7', environment: 'On-prem', nextExecution: '2026-08-10',
      upstream: [],
      linksOut: [
        { kind: 'Tableau', label: 'LGD back-testing workbook' }
      ],
      runs: [
        { executedAt: '2026-07-10 03:30', runtime: '52m', status: 'Succeeded', codeVersion: 'v2.7.0', trigger: 'Scheduled (monthly)' },
        { executedAt: '2026-06-10 03:28', runtime: '51m', status: 'Succeeded', codeVersion: 'v2.7.0', trigger: 'Scheduled (monthly)' },
        { executedAt: '2026-05-10 03:31', runtime: '54m', status: 'Succeeded', codeVersion: 'v2.7.0', trigger: 'Scheduled (monthly)' }
      ],
      kpis: [
        K('WLG-PM1', 'LGD back-test error', true, 'perf', '%', 'lt', 6, 10, wob(4.8, 0.3)),
        K('WLG-PM2', 'Rank ordering (Somers’ D)', true, 'perf', 'ratio', 'gt', 0.5, 0.4, wob(0.57, 0.01)),
        K('WLG-DQ1', 'Collateral data completeness', false, 'dq', '%', 'gt', 97, 94, wob(98.8, 0.2)),
        // One-run dip (Apr) — the rejected investigation PROTO-2025: collateral feed lag, not a model issue.
        K('WLG-PM3', 'Downturn floor headroom', false, 'perf', '%', 'gt', 5, 2, [7.2, 7.0, 6.8, 6.9, 6.6, 6.4, 6.1, 5.8, 4.9, 6.8, 7.1, 7.5]),
        K('WLG-OP1', 'Run success rate', false, 'ops', '%', 'gt', 98, 95, wob(100, 0))
      ]
    },
    {
      id: 'm06', name: 'Behavioural Deposit Model', kind: 'Model',
      function: 'Treasury', businessArea: 'Treasury ALM',
      materiality: 'High', riskTier: 'H',
      accountableOwner: 'Fiona Drummond', delegate: 'David Lam', developer: 'Priya Nair',
      version: 'v2.5', environment: 'SageMaker', nextExecution: '2026-07-29',
      upstream: [],
      breach: { openedAt: '2026-07-11', slaDays: 10, suggestedSeverity: 'High', classification: 'Model', stage: 'Scoring — population drift' },
      notes: 'Instant-access segment behaviour shifted after the June rate change; PSI climb is sustained across six runs — drift, not blip.',
      linksOut: [
        { kind: 'Tableau', label: 'Deposit behaviour workbook' },
        { kind: 'S3', label: 'Monthly check-pack (S3)' },
        { kind: 'Confluence', label: 'Local monitoring runbook' }
      ],
      runs: [
        { executedAt: '2026-07-10 04:20', runtime: '47m', status: 'Succeeded', codeVersion: 'v2.5.0', trigger: 'Scheduled (monthly)' },
        { executedAt: '2026-06-10 04:19', runtime: '46m', status: 'Succeeded', codeVersion: 'v2.5.0', trigger: 'Scheduled (monthly)' },
        { executedAt: '2026-05-10 04:22', runtime: '48m', status: 'Succeeded', codeVersion: 'v2.5.0', trigger: 'Scheduled (monthly)' }
      ],
      kpis: [
        // The genuine Red — Key-KPI PSI drift driving investigation PROTO-2041.
        K('BDM-PM1', 'Population stability index', true, 'perf', 'index', 'lt', 0.10, 0.25, [0.05, 0.06, 0.07, 0.08, 0.09, 0.11, 0.13, 0.15, 0.17, 0.19, 0.22, 0.31]),
        K('BDM-PM2', 'Decay-rate back-test error', true, 'perf', '%', 'lt', 5, 8, wob(4.1, 0.3)),
        K('BDM-DQ1', 'Balance reconciliation breaks', false, 'dq', 'accounts', 'lt', 20, 80, [18, 22, 25, 28, 24, 30, 26, 32, 29, 31, 33, 34]),
        K('BDM-PM3', 'Segment coverage', false, 'perf', '%', 'gt', 95, 90, wob(99, 0.3)),
        K('BDM-OP1', 'Run success rate', false, 'ops', '%', 'gt', 98, 95, wob(100, 0)),
        K('BDM-DQ2', 'Source feed timeliness', false, 'dq', 'hrs', 'lt', 4, 12, wob(2, 0.5))
      ]
    },
    {
      id: 'm07', name: 'Capital Forecast Model', kind: 'Model',
      function: 'Finance', businessArea: 'Capital Management',
      materiality: 'Very High', riskTier: 'VH',
      accountableOwner: 'Sarah McAllister', delegate: 'Tom Ferris', developer: 'Ana Kovač',
      version: 'v1.9', environment: 'Excel', nextExecution: '2026-08-05',
      upstream: ['m04'],
      symptomOf: 'm01', // inherits the same upstream trouble via m04 (chain-aware grouping, PS-15)
      breach: { openedAt: '2026-07-15', slaDays: 10, suggestedSeverity: 'Medium', classification: 'Data (inherited)', stage: 'Input freshness' },
      linksOut: [
        { kind: 'Confluence', label: 'Capital plan assumptions log' }
      ],
      runs: [
        { executedAt: '2026-07-15 17:50', runtime: '22m', status: 'Succeeded', codeVersion: 'v1.9.4', trigger: 'Scheduled (monthly)' },
        { executedAt: '2026-06-15 17:45', runtime: '21m', status: 'Succeeded', codeVersion: 'v1.9.4', trigger: 'Scheduled (monthly)' },
        { executedAt: '2026-05-15 17:52', runtime: '23m', status: 'Succeeded', codeVersion: 'v1.9.3', trigger: 'Scheduled (monthly)' }
      ],
      kpis: [
        K('CFM-DQ1', 'Upstream input freshness', true, 'dq', 'days stale', 'lt', 2, 5, [1, 1, 2, 1, 1, 2, 1, 1, 2, 1, 1, 4]),
        K('CFM-PM1', 'Forecast back-test error', true, 'perf', '%', 'lt', 8, 15, wob(6.2, 0.4)),
        K('CFM-DQ2', 'Input reconciliation breaks', false, 'dq', 'lines', 'lt', 10, 40, wob(3, 1)),
        K('CFM-PM2', 'Buffer headroom sensitivity', false, 'perf', '%', 'lt', 25, 40, wob(18, 1)),
        K('CFM-OP1', 'Workbook control checks passed', false, 'ops', '%', 'gt', 99, 95, wob(100, 0))
      ]
    },
    {
      id: 'm08', name: 'Liquidity Stress Overlay', kind: 'Model',
      function: 'Treasury', businessArea: 'Liquidity Risk',
      materiality: 'Very High', riskTier: 'VH',
      accountableOwner: 'Fiona Drummond', delegate: 'David Lam', developer: 'Priya Nair',
      version: 'v3.0', environment: 'On-prem', nextExecution: '2026-07-25',
      upstream: [],
      breach: { openedAt: '2026-07-23 07:02', slaDays: 5, suggestedSeverity: 'High', classification: 'Model', stage: 'Stress assumptions — outflow calibration' },
      notes: 'Fresh breach this morning: LCR back-test variance jumped 2.6 → 4.8 on the overnight run.',
      linksOut: [
        { kind: 'Tableau', label: 'Liquidity stress workbook' },
        { kind: 'S3', label: 'Overnight check-pack (S3)' }
      ],
      runs: [
        { executedAt: '2026-07-23 05:55', runtime: '1h 05m', status: 'Succeeded', codeVersion: 'v3.0.2', trigger: 'Scheduled (weekly)' },
        { executedAt: '2026-07-16 05:52', runtime: '1h 03m', status: 'Succeeded', codeVersion: 'v3.0.2', trigger: 'Scheduled (weekly)' },
        { executedAt: '2026-07-09 05:58', runtime: '1h 07m', status: 'Succeeded', codeVersion: 'v3.0.2', trigger: 'Scheduled (weekly)' }
      ],
      kpis: [
        K('LSO-PM1', 'LCR back-test variance', true, 'perf', '%', 'lt', 3, 6, [1.8, 2.1, 1.9, 2.4, 2.2, 2.5, 2.3, 2.6, 2.4, 2.5, 2.6, 4.8]),
        K('LSO-PM2', 'Outflow assumption error', true, 'perf', '%', 'lt', 5, 9, wob(3.9, 0.3)),
        K('LSO-DQ1', 'Position feed completeness', false, 'dq', '%', 'gt', 99, 97, wob(99.9, 0.05)),
        K('LSO-PM3', 'Survival horizon headroom', false, 'perf', 'days', 'gt', 10, 5, wob(16, 1)),
        K('LSO-OP1', 'Run success rate', false, 'ops', '%', 'gt', 98, 95, wob(100, 0))
      ]
    },
    {
      id: 'm09', name: 'Climate Vendor Data Feed', kind: 'Upstream data publisher',
      function: 'Finance', businessArea: 'Climate Hub',
      materiality: 'Low', riskTier: 'L',
      accountableOwner: 'Elena Marchetti', delegate: 'Chris Duffy', developer: 'Nadia Rahman',
      version: 'v2.2', environment: 'On-prem', nextExecution: '2026-07-26',
      upstream: [],
      notes: 'Vendor coverage on Scope 3 factors remains below target — known gap, tracked with the vendor; downstream m02 carries the acknowledged amber.',
      linksOut: [
        { kind: 'S3', label: 'Vendor file drop audit (S3)' }
      ],
      runs: [
        { executedAt: '2026-07-19 07:15', runtime: '9m', status: 'Succeeded', codeVersion: 'v2.2.1', trigger: 'Scheduled (weekly)' },
        { executedAt: '2026-07-12 07:14', runtime: '9m', status: 'Succeeded', codeVersion: 'v2.2.1', trigger: 'Scheduled (weekly)' },
        { executedAt: '2026-07-05 07:16', runtime: '10m', status: 'Succeeded', codeVersion: 'v2.2.1', trigger: 'Scheduled (weekly)' }
      ],
      kpis: [
        K('CVF-DQ1', 'File delivery success', true, 'dq', '%', 'gt', 99, 97, wob(100, 0)),
        K('CVF-DQ2', 'Field coverage', false, 'dq', '%', 'gt', 92, 85, [93.5, 93.1, 92.8, 92.4, 91.9, 91.2, 90.6, 90.1, 89.8, 89.4, 89.1, 88.9]),
        K('CVF-DQ3', 'Schema conformance', false, 'dq', '%', 'gt', 99, 97, wob(100, 0)),
        K('CVF-DQ4', 'Delivery timeliness', false, 'dq', 'hrs', 'lt', 24, 48, wob(6, 2)),
        K('CVF-OP1', 'Vendor SLA adherence', false, 'ops', '%', 'gt', 95, 90, wob(97, 0.5))
      ]
    },
    {
      id: 'm10', name: 'Intraday Liquidity Model', kind: 'Model',
      function: 'Treasury', businessArea: 'Liquidity Risk',
      materiality: 'Medium', riskTier: 'M',
      accountableOwner: 'Rob Whitfield', delegate: 'Sofia Petrov', developer: 'Ewan Baxter',
      version: 'v1.6', environment: 'SageMaker', nextExecution: '2026-08-01',
      upstream: [],
      linksOut: [
        { kind: 'Tableau', label: 'Intraday usage workbook' }
      ],
      runs: [
        { executedAt: '2026-07-20 06:40', runtime: '26m', status: 'Succeeded', codeVersion: 'v1.6.0', trigger: 'Scheduled (weekly)' },
        { executedAt: '2026-07-13 06:38', runtime: '25m', status: 'Succeeded', codeVersion: 'v1.6.0', trigger: 'Scheduled (weekly)' },
        { executedAt: '2026-07-06 06:41', runtime: '27m', status: 'Succeeded', codeVersion: 'v1.6.0', trigger: 'Scheduled (weekly)' }
      ],
      kpis: [
        K('ILM-PM1', 'Throughput forecast error', true, 'perf', '%', 'lt', 10, 15, wob(7, 0.5)),
        K('ILM-PM2', 'Peak usage back-test error', true, 'perf', '%', 'lt', 8, 12, wob(5.5, 0.4)),
        K('ILM-DQ1', 'Payment feed completeness', false, 'dq', '%', 'gt', 99.5, 98, wob(99.9, 0.03)),
        K('ILM-OP1', 'Run success rate', false, 'ops', '%', 'gt', 98, 95, wob(100, 0)),
        K('ILM-PM3', 'Stress buffer coverage', false, 'perf', 'ratio', 'gt', 1.2, 1.0, wob(1.5, 0.05))
      ]
    },
    {
      id: 'm11', name: 'FX Options Valuation (vendor)', kind: 'Vendor model',
      function: 'Treasury', businessArea: 'Markets Treasury',
      materiality: 'High', riskTier: 'H',
      accountableOwner: 'Rob Whitfield', delegate: 'Sofia Petrov', developer: 'Ewan Baxter',
      version: 'v4.7.1 (vendor)', environment: 'On-prem', nextExecution: '2026-08-14',
      upstream: [],
      notes: 'Vendor confirmed the vol-surface staleness is an interpolation defect; patch 4.7.2 scheduled — remediation PROTO-2033 in progress.',
      linksOut: [
        { kind: 'Confluence', label: 'Vendor model due-diligence pack' },
        { kind: 'Tableau', label: 'IPV variance workbook' }
      ],
      runs: [
        { executedAt: '2026-07-21 19:30', runtime: '33m', status: 'Succeeded', codeVersion: 'v4.7.1', trigger: 'Scheduled (weekly)' },
        { executedAt: '2026-07-14 19:28', runtime: '32m', status: 'Succeeded', codeVersion: 'v4.7.1', trigger: 'Scheduled (weekly)' },
        { executedAt: '2026-07-07 19:31', runtime: '34m', status: 'Succeeded', codeVersion: 'v4.7.0', trigger: 'Scheduled (weekly)' }
      ],
      kpis: [
        K('FXV-PM1', 'IPV variance', true, 'perf', 'bps', 'lt', 5, 10, wob(3.2, 0.3)),
        K('FXV-PM2', 'Greeks stability index', true, 'perf', 'index', 'lt', 0.1, 0.2, wob(0.06, 0.01)),
        // Vol-surface staleness climbing — the in-progress vendor patch PROTO-2033 targets this.
        K('FXV-DQ1', 'Vol surface staleness', false, 'dq', 'hrs', 'lt', 24, 72, [8, 10, 9, 12, 11, 10, 14, 12, 16, 20, 26, 30]),
        K('FXV-DQ2', 'Market data completeness', false, 'dq', '%', 'gt', 99, 97, wob(99.7, 0.1)),
        K('FXV-OP1', 'Vendor batch success', false, 'ops', '%', 'gt', 98, 95, wob(99, 0.3)),
        K('FXV-PM3', 'P&L explain ratio', false, 'perf', '%', 'gt', 95, 90, wob(97, 0.4))
      ]
    },
    {
      id: 'm12', name: 'IRRBB Sensitivity Model', kind: 'Model',
      function: 'Treasury', businessArea: 'Treasury ALM',
      materiality: 'Medium', riskTier: 'M',
      accountableOwner: 'Fiona Drummond', delegate: 'David Lam', developer: 'Ewan Baxter',
      version: 'v2.1', environment: 'Excel', nextExecution: '2026-08-20',
      upstream: [],
      linksOut: [
        { kind: 'Confluence', label: 'IRRBB workbook control checklist' }
      ],
      runs: [
        { executedAt: '2026-07-18 15:10', runtime: '18m', status: 'Succeeded', codeVersion: 'v2.1.1', trigger: 'Scheduled (monthly)' },
        { executedAt: '2026-06-18 15:08', runtime: '18m', status: 'Succeeded', codeVersion: 'v2.1.1', trigger: 'Scheduled (monthly)' },
        { executedAt: '2026-06-11 09:30', runtime: '19m', status: 'Succeeded', codeVersion: 'v2.1.1', trigger: 'Manual (post-fix validation — PROTO-2018)' }
      ],
      kpis: [
        K('IRB-PM1', 'EVE sensitivity back-test', true, 'perf', '%', 'lt', 10, 15, wob(6.8, 0.4)),
        K('IRB-PM2', 'NII forecast error', true, 'perf', '%', 'lt', 8, 12, wob(5.2, 0.3)),
        K('IRB-DQ1', 'Position completeness', false, 'dq', '%', 'gt', 99, 97, wob(99.8, 0.05)),
        K('IRB-OP1', 'Workbook checks passed', false, 'ops', '%', 'gt', 99, 95, wob(100, 0)),
        // Duplicated bucketing fixed via PROTO-2018 (closed 11 Jun) — breaks 14 → 0.
        K('IRB-PM3', 'Bucketing reconciliation breaks', false, 'dq', 'lines', 'lt', 5, 20, [12, 13, 14, 11, 13, 14, 12, 10, 2, 1, 0, 0])
      ]
    }
  ];

  // ---- Tickets — investigations & remediations (PS-16, M3–M4). ----
  // The ticket lifecycle IS the record (qb-o08: "what was fixed quietly?").
  var TICKETS = [
    {
      ref: 'PROTO-2041', type: 'Investigation', modelId: 'm06', kpiCode: 'BDM-PM1',
      title: 'PSI drift on Behavioural Deposit Model',
      assignee: 'Priya Nair', byWhen: '2026-07-28', state: 'Analysing', openedAt: '2026-07-14',
      eventLog: [
        { at: '2026-07-11', who: 'System', what: 'Breach opened — BDM-PM1 PSI crossed amber on run 2026-06-10; red on 2026-07-10 (0.31 vs < 0.10 green).' },
        { at: '2026-07-14', who: 'David Lam (fixer duty)', what: 'Triaged: severity High, materiality High. Rationale: “Sustained six-run PSI climb — drift, not blip.” Escalated → ticket minted (Jira mock).' },
        { at: '2026-07-15', who: 'Priya Nair (fixer duty)', what: 'Evidence lenses assembled; upstream check clean — source, not symptom.' },
        { at: '2026-07-20', who: 'Priya Nair (fixer duty)', what: 'Segment analysis in local Tableau workbook: instant-access segment shifted after June rate change.' }
      ]
    },
    {
      ref: 'PROTO-2036', type: 'Remediation', modelId: 'm01', kpiCode: 'MSF-DQ1', category: 'Data',
      title: 'Backfill vendor macro file & add completeness gate',
      assignee: 'Ana Kovač', byWhen: '2026-07-31', state: 'Awaiting approval', openedAt: '2026-07-16',
      eventLog: [
        { at: '2026-07-13', who: 'System', what: 'Breach opened — MSF-DQ1 feed completeness below amber floor (98.4%).' },
        { at: '2026-07-14', who: 'Tom Ferris (fixer duty)', what: 'Triaged: severity High. Rationale: “Vendor file truncated — two scenario blocks missing.” Escalated.' },
        { at: '2026-07-16', who: 'Ana Kovač (fixer duty)', what: 'Investigation concluded: data factor — vendor delivery truncation. Remediation recommended: backfill + automated completeness gate before publish.' },
        { at: '2026-07-22', who: 'System', what: 'Moved to Awaiting approval — owner decision required (Sarah McAllister).' }
      ]
    },
    {
      ref: 'PROTO-2038', type: 'Investigation', modelId: 'm04', kpiCode: 'IFRS-DQ1',
      title: 'Amber attributed upstream — track against PROTO-2036',
      assignee: 'Tom Ferris', byWhen: '2026-08-01', state: 'Open', openedAt: '2026-07-15',
      eventLog: [
        { at: '2026-07-14', who: 'System', what: 'Breach opened — IFRS-DQ1 macro input completeness amber (95.8%).' },
        { at: '2026-07-15', who: 'Tom Ferris (fixer duty)', what: 'Upstream check: symptom of m01 Macro Scenario Feed red — attributed upstream, not investigated locally (A3). Tracking against PROTO-2036.' }
      ]
    },
    {
      ref: 'PROTO-2033', type: 'Remediation', modelId: 'm11', kpiCode: 'FXV-DQ1', category: 'Model',
      title: 'Apply vendor patch 4.7.2 — stale vol-surface interpolation',
      assignee: 'Ewan Baxter', byWhen: '2026-08-08', state: 'In progress', openedAt: '2026-07-06',
      eventLog: [
        { at: '2026-07-03', who: 'Sofia Petrov (fixer duty)', what: 'Investigation concluded: model factor — vendor interpolation defect confirmed by vendor. Remediation recommended: patch 4.7.2.' },
        { at: '2026-07-06', who: 'System', what: 'Moved to Awaiting approval.' },
        { at: '2026-07-09', who: 'Rob Whitfield (owner duty)', what: 'Approved with audit note: “Vendor patch is the right fix; interim manual refresh of the surface each morning until deployed.”' },
        { at: '2026-07-15', who: 'Ewan Baxter (fixer duty)', what: 'Patch received from vendor; deployment scheduled into the weekly release window.' }
      ]
    },
    {
      ref: 'PROTO-2029', type: 'Remediation', modelId: 'm03', kpiCode: 'RPD-PM2', category: 'Model',
      title: 'Recalibrate scorecard weights after Q2 population shift',
      assignee: 'Callum Reid', byWhen: '2026-07-01', state: 'Resolved', openedAt: '2026-06-05', closedAt: '2026-07-02',
      closureEvidence: 'Post-fix PSI 0.07 → 0.06 (green) across two consecutive validation runs; model status recomputed Green on 2026-07-02.',
      eventLog: [
        { at: '2026-05-12', who: 'System', what: 'Breach opened — RPD-PM2 PSI red (0.27).' },
        { at: '2026-05-13', who: 'Meera Shah (fixer duty)', what: 'Triaged: severity High. Escalated — investigation confirmed genuine population shift in Q2 originations.' },
        { at: '2026-06-05', who: 'James Okonkwo (owner duty)', what: 'Approved with audit note: “Recalibration within existing model scope; no redevelopment trigger.”' },
        { at: '2026-06-28', who: 'Callum Reid (fixer duty)', what: 'Recalibrated weights deployed (v5.1.3); validation re-run requested.' },
        { at: '2026-07-02', who: 'System', what: 'Validation re-run: PSI 0.06 (green). Resolved — closure evidence attached; status recomputed.' }
      ]
    },
    {
      ref: 'PROTO-2025', type: 'Investigation', modelId: 'm05', kpiCode: 'WLG-PM3',
      title: 'Suspected downturn-floor breach',
      assignee: 'Callum Reid', byWhen: '2026-06-20', state: 'Rejected', openedAt: '2026-06-12',
      eventLog: [
        { at: '2026-06-10', who: 'System', what: 'WLG-PM3 downturn floor headroom dipped to 4.9% (amber) on the April run.' },
        { at: '2026-06-12', who: 'Meera Shah (fixer duty)', what: 'Escalated for a look — headroom trend had been narrowing for three runs.' },
        { at: '2026-06-18', who: 'James Okonkwo (owner duty)', what: 'Rejected with audit note: “Single-run dip caused by collateral feed lag — reverted next run. No model issue.”' }
      ]
    },
    {
      ref: 'PROTO-2018', type: 'Remediation', modelId: 'm12', kpiCode: 'IRB-PM3', category: 'Process',
      title: 'Fix duplicated cashflow bucketing in workbook',
      assignee: 'David Lam', byWhen: '2026-06-15', state: 'Resolved', openedAt: '2026-05-20', closedAt: '2026-06-11',
      closureEvidence: 'Bucketing reconciliation breaks 14 → 0 post-fix; a workbook control check was added to the run checklist. Fixed quietly — no committee needed (qb-o08).',
      eventLog: [
        { at: '2026-05-18', who: 'David Lam (fixer duty)', what: 'Investigation concluded: process factor — a copied formula range double-counted the 3–6m bucket.' },
        { at: '2026-05-20', who: 'Fiona Drummond (owner duty)', what: 'Approved with audit note: “Workbook fix plus a control check — proportionate.”' },
        { at: '2026-06-11', who: 'System', what: 'Validation re-run: breaks 0 (green). Resolved — closure evidence attached; status recomputed.' }
      ]
    }
  ];

  // ---- Signals — mocked push events with deep links (PS-21, M0). ----
  var SIGNALS = [
    { id: 's1', channel: 'Teams', text: 'Breach opened on Liquidity Stress Overlay — LCR back-test variance amber', ago: '2h ago', route: '#/model/m08' },
    { id: 's2', channel: 'Email', text: 'Execution window opens Mon 27 Jul — IFRS9 Impairment Engine', ago: '3h ago', route: '#/model/m04' },
    { id: 's3', channel: 'Jira', text: 'PROTO-2036 moved to Awaiting approval — remediation on Macro Scenario Feed', ago: '1d ago', route: '#/work/PROTO-2036' },
    { id: 's4', channel: 'Teams', text: 'PSI drift red on Behavioural Deposit Model — investigation PROTO-2041 analysing', ago: '2d ago', route: '#/work/PROTO-2041' }
  ];

  // ---- Post-process: latest / previous readings, lastRun alias. ----
  MODELS.forEach(function (m) {
    m.kpis.forEach(function (k) {
      k.latest = k.history[k.history.length - 1];
      k.previous = k.history[k.history.length - 2];
    });
    m.lastRun = m.runs[0];
  });

  window.DATA = {
    meta: {
      today: '2026-07-23',
      now: '2026-07-23 09:00',
      lastVisit: '2026-07-14',
      lastVisitAgo: '9 days ago',
      ingest: '4 min ago',
      months: ['Aug', 'Sep', 'Oct', 'Nov', 'Dec', 'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul']
    },
    models: MODELS,
    tickets: TICKETS,
    signals: SIGNALS
  };
})();
