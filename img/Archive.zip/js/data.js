/* ============================================================
   Fixtures — models, KPIs, runs, investigations, remediations.
   All fabricated. Dates in Q3 2026. Deterministic (no PRNG needed —
   the shape and richness is authored, not generated).

   Namespace: window.MPMP.data
   Read-only from the app's point of view.
   ============================================================ */
(function () {
  "use strict";
  var MPMP = window.MPMP = window.MPMP || {};

  var RAG = { R: "r", A: "a", G: "g" };

  // 12 runs of KPI history — Wednesday cadence, most recent last.
  var RUNS = [
    "2026-04-22", "2026-04-29", "2026-05-06", "2026-05-13",
    "2026-05-20", "2026-05-27", "2026-06-03", "2026-06-10",
    "2026-06-17", "2026-06-24", "2026-07-01", "2026-07-08"
  ];

  // Business areas — mirror the wireframe strawman
  var AREAS = [
    "Retail credit", "Wholesale credit", "Market risk",
    "Treasury / Liquidity", "Capital & stress", "IFRS9 / Impairment"
  ];

  function h() { return Array.prototype.slice.call(arguments); }

  // ------------------------------------------------------------
  // Models — 12 across Finance & Treasury, with 4–7 KPIs each
  // ------------------------------------------------------------
  var models = [
    {
      id: "retail-pd-v3",
      name: "Retail PD Model v3",
      businessArea: "Retail credit",
      fn: "Finance",
      materiality: "Very High",
      owner: "Sebastien Geroult",
      developer: "Xiaole Kong",
      version: "v3.2 (MMS-approved)",
      environment: "AWS SageMaker",
      lastRunAt: "2026-07-08 06:00",
      description: "Probability-of-default model for the retail unsecured portfolio. Feeds IFRS 9 staging and regulatory capital calculation.",
      kpis: [
        { code: "PSI", name: "PSI (population stability)", isKey: true, unit: "index", latest: "0.31", threshold: "< 0.25 → g · ≤ 0.40 → a · else r", history: h("g","g","g","g","a","a","a","r","r","r","r","r") },
        { code: "GINI", name: "Gini / AUC", isKey: true, unit: "", latest: "0.58", threshold: "> 0.60 → g · ≥ 0.55 → a · else r", history: h("g","g","g","g","g","g","a","a","a","a","a","a") },
        { code: "CAL", name: "Calibration (obs vs pred)", isKey: true, unit: "%", latest: "1.4%", threshold: "< 1.0 → g · ≤ 2.0 → a · else r", history: h("g","g","g","a","a","a","a","r","r","r","r","r") },
        { code: "COMPL", name: "Data completeness", isKey: false, unit: "%", latest: "99.7%", threshold: "> 99.5 → g · ≥ 98.0 → a · else r", history: h("g","g","g","g","g","g","g","g","g","g","g","g") },
        { code: "LAT", name: "Run latency", isKey: false, unit: "min", latest: "42", threshold: "< 60 → g · ≤ 90 → a · else r", history: h("g","g","g","g","g","g","g","g","g","g","g","g") },
        { code: "COV", name: "Test coverage", isKey: false, unit: "%", latest: "94%", threshold: "> 90 → g · ≥ 80 → a · else r", history: h("g","g","g","g","g","g","g","g","g","g","g","g") },
        { code: "DRIFT", name: "Feature drift (KS)", isKey: false, unit: "", latest: "0.14", threshold: "< 0.10 → g · ≤ 0.20 → a · else r", history: h("g","g","g","g","a","a","a","a","a","a","a","a") }
      ]
    },
    {
      id: "irrbb-eve",
      name: "IRRBB — EVE",
      businessArea: "Treasury / Liquidity",
      fn: "Treasury",
      materiality: "Very High",
      owner: "Karl Rodolfo",
      developer: "Loic Thomson",
      version: "v2.1 (MMS-approved)",
      environment: "On-prem",
      lastRunAt: "2026-07-08 07:15",
      description: "Interest Rate Risk in the Banking Book — Economic Value of Equity sensitivity model.",
      kpis: [
        { code: "BACK", name: "Backtest exceptions", isKey: true, unit: "n", latest: "8", threshold: "< 4 → g · ≤ 7 → a · else r", history: h("g","g","a","a","a","a","a","a","r","r","r","r") },
        { code: "SHIFT", name: "Rate shift sensitivity", isKey: true, unit: "bp", latest: "182", threshold: "< 150 → g · ≤ 200 → a · else r", history: h("g","g","g","a","a","a","a","a","a","a","a","a") },
        { code: "COMPL", name: "Data completeness", isKey: false, unit: "%", latest: "99.9%", threshold: "> 99.5 → g · ≥ 98.0 → a · else r", history: h("g","g","g","g","g","g","g","g","g","g","g","g") },
        { code: "LAT", name: "Run latency", isKey: false, unit: "min", latest: "128", threshold: "< 90 → g · ≤ 120 → a · else r", history: h("g","g","g","g","g","a","a","a","a","r","r","r") }
      ]
    },
    {
      id: "lgd-cards",
      name: "LGD Cards",
      businessArea: "Retail credit",
      fn: "Finance",
      materiality: "High",
      owner: "Sophie Pass",
      developer: "Charis Koukoutsi",
      version: "v1.9 (MMS-approved)",
      environment: "AWS SageMaker",
      lastRunAt: "2026-07-08 06:20",
      description: "Loss-Given-Default model for the cards portfolio.",
      kpis: [
        { code: "CAL", name: "Calibration gap", isKey: true, unit: "%", latest: "1.8%", threshold: "< 1.0 → g · ≤ 2.5 → a · else r", history: h("g","g","g","g","g","a","a","a","a","a","a","a") },
        { code: "GINI", name: "Gini / AUC", isKey: true, unit: "", latest: "0.71", threshold: "> 0.65 → g · ≥ 0.55 → a · else r", history: h("g","g","g","g","g","g","g","g","g","g","g","g") },
        { code: "COMPL", name: "Data completeness", isKey: false, unit: "%", latest: "99.8%", threshold: "> 99.5 → g · ≥ 98.0 → a · else r", history: h("g","g","g","g","g","g","g","g","g","g","g","g") },
        { code: "COV", name: "Test coverage", isKey: false, unit: "%", latest: "88%", threshold: "> 90 → g · ≥ 80 → a · else r", history: h("g","g","g","g","g","a","a","a","a","a","a","a") },
        { code: "DRIFT", name: "Feature drift (KS)", isKey: false, unit: "", latest: "0.09", threshold: "< 0.10 → g · ≤ 0.20 → a · else r", history: h("g","g","g","g","g","g","g","g","g","g","g","g") }
      ]
    },
    {
      id: "lcr",
      name: "Liquidity — LCR",
      businessArea: "Treasury / Liquidity",
      fn: "Treasury",
      materiality: "High",
      owner: "Bruno Muongkhot",
      developer: "Songlin Yang",
      version: "v1.5",
      environment: "On-prem",
      lastRunAt: "2026-07-08 05:45",
      description: "Liquidity Coverage Ratio model.",
      kpis: [
        { code: "COMPL", name: "Input completeness", isKey: true, unit: "%", latest: "97.2%", threshold: "> 99.5 → g · ≥ 98.0 → a · else r", history: h("g","g","g","g","g","a","a","a","a","a","a","a") },
        { code: "RATIO", name: "LCR ratio", isKey: true, unit: "%", latest: "112%", threshold: "> 110 → g · ≥ 100 → a · else r", history: h("g","g","g","g","g","g","g","g","g","g","g","g") },
        { code: "LAT", name: "Run latency", isKey: false, unit: "min", latest: "55", threshold: "< 60 → g · ≤ 90 → a · else r", history: h("g","g","g","g","g","g","g","g","g","g","g","g") }
      ]
    },
    {
      id: "mortgage-ead",
      name: "Mortgage EAD",
      businessArea: "Retail credit",
      fn: "Finance",
      materiality: "Very High",
      owner: "Sebastien Geroult",
      developer: "Xiaole Kong",
      version: "v4.0 (MMS-approved)",
      environment: "AWS SageMaker",
      lastRunAt: "2026-07-08 06:10",
      description: "Exposure-at-Default model for the mortgage portfolio.",
      kpis: [
        { code: "CAL", name: "Calibration", isKey: true, unit: "%", latest: "0.6%", threshold: "< 1.0 → g · ≤ 2.0 → a · else r", history: h("g","g","g","g","g","g","g","g","g","g","g","g") },
        { code: "GINI", name: "Gini", isKey: true, unit: "", latest: "0.74", threshold: "> 0.65 → g · ≥ 0.55 → a · else r", history: h("g","g","g","g","g","g","g","g","g","g","g","g") },
        { code: "COMPL", name: "Data completeness", isKey: false, unit: "%", latest: "99.9%", threshold: "> 99.5 → g · ≥ 98.0 → a · else r", history: h("g","g","g","g","g","g","g","g","g","g","g","g") },
        { code: "DRIFT", name: "Feature drift", isKey: false, unit: "", latest: "0.06", threshold: "< 0.10 → g · ≤ 0.20 → a · else r", history: h("g","g","g","g","g","g","g","g","g","g","g","g") }
      ]
    },
    {
      id: "ifrs9-stage",
      name: "IFRS 9 Stage Allocation",
      businessArea: "IFRS9 / Impairment",
      fn: "Finance",
      materiality: "Very High",
      owner: "Sophie Pass",
      developer: "Loic Thomson",
      version: "v2.4 (MMS-approved)",
      environment: "AWS SageMaker",
      lastRunAt: "2026-07-08 06:30",
      description: "IFRS 9 stage 1/2/3 allocation model.",
      kpis: [
        { code: "TRANS", name: "Stage transition rate", isKey: true, unit: "%", latest: "3.1%", threshold: "< 4 → g · ≤ 6 → a · else r", history: h("g","g","g","g","g","g","g","g","g","g","g","g") },
        { code: "COMPL", name: "Data completeness", isKey: false, unit: "%", latest: "99.6%", threshold: "> 99.5 → g · ≥ 98.0 → a · else r", history: h("g","g","g","g","g","g","g","g","g","g","g","g") },
        { code: "COV", name: "Portfolio coverage", isKey: false, unit: "%", latest: "97%", threshold: "> 95 → g · ≥ 90 → a · else r", history: h("g","g","g","g","g","g","g","g","g","g","g","g") }
      ]
    },
    {
      id: "wholesale-lgd",
      name: "Wholesale LGD",
      businessArea: "Wholesale credit",
      fn: "Finance",
      materiality: "High",
      owner: "Karl Rodolfo",
      developer: "Charis Koukoutsi",
      version: "v1.2 (MMS-approved)",
      environment: "On-prem",
      lastRunAt: "2026-07-07 22:00",
      description: "Wholesale portfolio Loss-Given-Default.",
      kpis: [
        { code: "CAL", name: "Calibration", isKey: true, unit: "%", latest: "1.3%", threshold: "< 1.0 → g · ≤ 2.0 → a · else r", history: h("g","g","g","g","a","a","a","a","a","a","a","a") },
        { code: "GINI", name: "Gini", isKey: true, unit: "", latest: "0.62", threshold: "> 0.60 → g · ≥ 0.50 → a · else r", history: h("g","g","g","g","g","g","g","g","g","g","g","g") },
        { code: "COMPL", name: "Data completeness", isKey: false, unit: "%", latest: "99.7%", threshold: "> 99.5 → g · ≥ 98.0 → a · else r", history: h("g","g","g","g","g","g","g","g","g","g","g","g") }
      ]
    },
    {
      id: "var-market",
      name: "Market VaR",
      businessArea: "Market risk",
      fn: "Treasury",
      materiality: "High",
      owner: "Bruno Muongkhot",
      developer: "Xiaole Kong",
      version: "v3.1 (MMS-approved)",
      environment: "On-prem",
      lastRunAt: "2026-07-08 04:00",
      description: "Value-at-Risk model — trading book.",
      kpis: [
        { code: "BACK", name: "Backtest exceptions", isKey: true, unit: "n", latest: "2", threshold: "< 4 → g · ≤ 7 → a · else r", history: h("g","g","g","g","g","g","g","g","g","g","g","g") },
        { code: "COV", name: "P&L attribution", isKey: false, unit: "%", latest: "96%", threshold: "> 95 → g · ≥ 90 → a · else r", history: h("g","g","g","g","g","g","g","g","g","g","g","g") },
        { code: "COMPL", name: "Data completeness", isKey: false, unit: "%", latest: "99.9%", threshold: "> 99.5 → g · ≥ 98.0 → a · else r", history: h("g","g","g","g","g","g","g","g","g","g","g","g") }
      ]
    },
    {
      id: "stress-base",
      name: "Stress — Base scenario",
      businessArea: "Capital & stress",
      fn: "Finance",
      materiality: "High",
      owner: "Sebastien Geroult",
      developer: "Songlin Yang",
      version: "v2.0 (MMS-approved)",
      environment: "AWS SageMaker",
      lastRunAt: "2026-07-01 10:00",
      description: "Base-case stress scenario model for capital planning.",
      kpis: [
        { code: "PROJ", name: "Projection stability", isKey: true, unit: "", latest: "0.92", threshold: "> 0.90 → g · ≥ 0.80 → a · else r", history: h("g","g","g","g","g","g","g","g","g","g","g","g") },
        { code: "COMPL", name: "Data completeness", isKey: false, unit: "%", latest: "99.8%", threshold: "> 99.5 → g · ≥ 98.0 → a · else r", history: h("g","g","g","g","g","g","g","g","g","g","g","g") }
      ]
    },
    {
      id: "counterparty-ead",
      name: "Counterparty EAD",
      businessArea: "Wholesale credit",
      fn: "Treasury",
      materiality: "Medium",
      owner: "Karl Rodolfo",
      developer: "Loic Thomson",
      version: "v1.1",
      environment: "Excel",
      lastRunAt: "2026-07-08 09:30",
      description: "Counterparty Exposure-at-Default model — still on spreadsheets.",
      kpis: [
        { code: "CAL", name: "Calibration", isKey: true, unit: "%", latest: "2.4%", threshold: "< 1.0 → g · ≤ 2.0 → a · else r", history: h("g","g","g","a","a","a","a","a","a","a","a","a") },
        { code: "COMPL", name: "Data completeness", isKey: false, unit: "%", latest: "97.1%", threshold: "> 99.5 → g · ≥ 98.0 → a · else r", history: h("g","g","g","g","a","a","a","a","a","a","a","a") }
      ]
    },
    {
      id: "cards-pd",
      name: "Cards PD",
      businessArea: "Retail credit",
      fn: "Finance",
      materiality: "Medium",
      owner: "Sophie Pass",
      developer: "Charis Koukoutsi",
      version: "v2.3 (MMS-approved)",
      environment: "AWS SageMaker",
      lastRunAt: "2026-07-08 06:15",
      description: "Cards portfolio probability-of-default.",
      kpis: [
        { code: "GINI", name: "Gini", isKey: true, unit: "", latest: "0.68", threshold: "> 0.60 → g · ≥ 0.55 → a · else r", history: h("g","g","g","g","g","g","g","g","g","g","g","g") },
        { code: "CAL", name: "Calibration", isKey: true, unit: "%", latest: "0.9%", threshold: "< 1.0 → g · ≤ 2.0 → a · else r", history: h("g","g","g","g","g","g","g","g","g","g","g","g") },
        { code: "COMPL", name: "Data completeness", isKey: false, unit: "%", latest: "99.6%", threshold: "> 99.5 → g · ≥ 98.0 → a · else r", history: h("g","g","g","g","g","g","g","g","g","g","g","g") }
      ]
    },
    {
      id: "overdraft-pd",
      name: "Overdraft PD",
      businessArea: "Retail credit",
      fn: "Finance",
      materiality: "Low",
      owner: "Sophie Pass",
      developer: "Songlin Yang",
      version: "v1.0",
      environment: "Excel",
      lastRunAt: "2026-07-08 06:25",
      description: "Overdraft PD — small portfolio, low materiality.",
      kpis: [
        { code: "GINI", name: "Gini", isKey: true, unit: "", latest: "0.63", threshold: "> 0.60 → g · ≥ 0.50 → a · else r", history: h("g","g","g","g","g","g","g","g","g","g","g","g") },
        { code: "COMPL", name: "Data completeness", isKey: false, unit: "%", latest: "98.1%", threshold: "> 99.5 → g · ≥ 98.0 → a · else r", history: h("g","g","g","g","g","g","a","a","a","a","a","a") }
      ]
    }
  ];

  // Precompute a per-KPI `currentRag` — the last entry of history.
  models.forEach(function (m) {
    m.kpis.forEach(function (k) {
      k.currentRag = k.history[k.history.length - 1];
    });
  });

  // ------------------------------------------------------------
  // Triage queue — items published by MPMP awaiting triage
  // ------------------------------------------------------------
  var triageQueue = [
    {
      id: "tq-01",
      modelId: "retail-pd-v3",
      kpiCode: "PSI",
      severity: "High",
      openedAt: "2026-07-08 06:04",
      ageDays: 2,
      slaDays: 3,
      note: "PSI drift crossed 0.30 for the 4th consecutive run. Materially affects staging for the retail unsecured portfolio.",
      status: "needs-triage"
    },
    {
      id: "tq-02",
      modelId: "retail-pd-v3",
      kpiCode: "CAL",
      severity: "High",
      openedAt: "2026-07-08 06:05",
      ageDays: 2,
      slaDays: 3,
      note: "Observed vs predicted calibration gap has widened for 5 consecutive runs.",
      status: "needs-triage"
    },
    {
      id: "tq-03",
      modelId: "irrbb-eve",
      kpiCode: "BACK",
      severity: "High",
      openedAt: "2026-07-08 07:20",
      ageDays: 1,
      slaDays: 3,
      note: "Backtest exceptions above tolerance limit — 8 vs threshold of 7.",
      status: "needs-triage"
    },
    {
      id: "tq-04",
      modelId: "lgd-cards",
      kpiCode: "CAL",
      severity: "Medium",
      openedAt: "2026-07-05 08:00",
      ageDays: 4,
      slaDays: 5,
      note: "Calibration gap 1.8% — persistent Amber, not yet Red.",
      status: "needs-triage"
    },
    {
      id: "tq-05",
      modelId: "lcr",
      kpiCode: "COMPL",
      severity: "Medium",
      openedAt: "2026-07-07 05:50",
      ageDays: 1,
      slaDays: 5,
      note: "Input completeness dipped to 97.2%. Possible upstream data lag.",
      status: "needs-triage"
    },
    {
      id: "tq-06",
      modelId: "counterparty-ead",
      kpiCode: "CAL",
      severity: "Low",
      openedAt: "2026-07-04 09:30",
      ageDays: 5,
      slaDays: 7,
      note: "Excel-hosted model, calibration drift ongoing — remediation likely to require migration first.",
      status: "acknowledged",
      triage: { decision: "acknowledge", rationale: "Excel migration in scope Q4 2026 — accept and monitor.", by: "Xiaole Kong", at: "2026-07-05 10:00" }
    },
    {
      id: "tq-07",
      modelId: "wholesale-lgd",
      kpiCode: "CAL",
      severity: "Medium",
      openedAt: "2026-07-02 09:00",
      ageDays: 7,
      slaDays: 5,
      note: "Calibration Amber for 8 consecutive runs — SLA breached.",
      status: "acknowledged",
      triage: { decision: "escalate", rationale: "Persistent — escalate to investigation.", by: "Charis Koukoutsi", at: "2026-07-03 14:00" }
    }
  ];

  // ------------------------------------------------------------
  // Investigations — one already open, seeded from tq-07
  // ------------------------------------------------------------
  var investigations = [
    {
      id: "inv-2026-039",
      modelId: "wholesale-lgd",
      triggerKpiCode: "CAL",
      status: "Analysing",
      openedBy: "Charis Koukoutsi",
      openedAt: "2026-07-03 14:05",
      hypotheses: [
        { lens: "data",    id: "h1", title: "Segment-mix shift in the wholesale book",             evidence: "New corporate customers concentrated in mid-market segment; recovery profile shifted.", confidence: "high", state: "confirmed" },
        { lens: "data",    id: "h2", title: "Missing collateral valuations for large exposures",   evidence: "12% of exposures over £50M have stale collateral (>90 days).",                    confidence: "med",  state: "open" },
        { lens: "model",   id: "h3", title: "Feature weights stale post-2025 recalibration",       evidence: "Weights not refreshed since 2025-11; recovery-lag feature dominant.",             confidence: "med",  state: "open" },
        { lens: "model",   id: "h4", title: "Concept drift — post-rate-cycle behaviour shift",     evidence: "Base rates fell 200bp since last recal; recovery timing distribution shifted.", confidence: "high", state: "open" },
        { lens: "process", id: "h5", title: "Data feed timing mismatch upstream of run",           evidence: "Feed A arrives 4h later on Tuesdays; runs on Wednesday.",                         confidence: "low",  state: "dismissed" }
      ],
      rootCause: "Segment-mix shift in the wholesale book (h1 confirmed). Likely compounded by concept drift (h4 under investigation).",
      recommendation: "Recalibrate model with 2026-H1 data limited to mid-market segment; validate against holdout. Interim: flag mid-market exposures for manual review.",
      recommendationCategory: "Model",
      recommendationTimeline: "10 business days"
    }
  ];

  // ------------------------------------------------------------
  // Remediations — one awaiting owner approval
  // ------------------------------------------------------------
  var remediations = [
    {
      id: "rem-2026-024",
      investigationId: "inv-2026-039",
      modelId: "wholesale-lgd",
      status: "Pending approval",
      category: "Model",
      proposedBy: "Charis Koukoutsi",
      proposedAt: "2026-07-08 09:00",
      actionPlan: "Recalibrate LGD model on 2026-H1 wholesale data, segment-stratified. Validate on 2025-H2 holdout. Interim mitigation: manual review flag on mid-market exposures over £20M.",
      timeline: "10 business days",
      validationResults: null,
      timeline_events: [
        { title: "Investigation filed", meta: "Charis Koukoutsi · 2026-07-08 09:00", state: "done" },
        { title: "Owner review",        meta: "Karl Rodolfo · pending",              state: "current" },
        { title: "Implementation",      meta: "Model dev team · pending",            state: "pending" },
        { title: "Post-implementation validation", meta: "Automated re-run · pending", state: "pending" },
        { title: "Confirm resolution",  meta: "Karl Rodolfo · pending",              state: "pending" }
      ]
    }
  ];

  MPMP.data = {
    RAG: RAG,
    RUNS: RUNS,
    AREAS: AREAS,
    models: models,
    triageQueue: triageQueue,
    investigations: investigations,
    remediations: remediations
  };
})();
