/* ============================================================
   Aggregation — the ASSUMED model-level RAG rule.

   Rule name: "Key-KPI dominance with materiality floor"

     1. Any KEY KPI = Red         → model = Red
     2. Any KEY KPI = Amber       → model = Amber
     3. ≥30% of non-key KPIs Red+Amber → Amber
        (or ≥15% non-key Red      → Amber)
     4. Otherwise                 → Green

   The derivation object it returns is used verbatim by the
   "Derivation" panel on every model-level RAG surface —
   part of the design need to expose HOW the RAG is derived,
   not just the colour (DN-13 / I-02).
   ============================================================ */
(function () {
  "use strict";
  var MPMP = window.MPMP = window.MPMP || {};

  function aggregate(model) {
    var kpis = model.kpis || [];
    var key = kpis.filter(function (k) { return k.isKey; });
    var nonKey = kpis.filter(function (k) { return !k.isKey; });

    var keyReds = key.filter(function (k) { return k.currentRag === "r"; });
    var keyAmbers = key.filter(function (k) { return k.currentRag === "a"; });
    var nonKeyReds = nonKey.filter(function (k) { return k.currentRag === "r"; });
    var nonKeyBad = nonKey.filter(function (k) { return k.currentRag === "r" || k.currentRag === "a"; });

    var branch, rag;
    if (keyReds.length > 0) {
      rag = "r";
      branch = "1 — key-KPI Red";
    } else if (keyAmbers.length > 0) {
      rag = "a";
      branch = "2 — key-KPI Amber";
    } else if (
      (nonKey.length > 0 && nonKeyBad.length / nonKey.length >= 0.30) ||
      (nonKey.length > 0 && nonKeyReds.length / nonKey.length >= 0.15)
    ) {
      rag = "a";
      branch = "3 — non-key materiality floor";
    } else {
      rag = "g";
      branch = "4 — no material breach";
    }

    return {
      rag: rag,
      branch: branch,
      inputs: {
        totalKpis: kpis.length,
        keyCount: key.length,
        nonKeyCount: nonKey.length,
        keyReds: keyReds.map(function (k) { return k.code; }),
        keyAmbers: keyAmbers.map(function (k) { return k.code; }),
        nonKeyReds: nonKeyReds.map(function (k) { return k.code; }),
        nonKeyBad: nonKeyBad.map(function (k) { return k.code; })
      }
    };
  }

  // Attach derivation to every model on load.
  MPMP.aggregate = aggregate;
  MPMP.decorate = function () {
    if (!MPMP.data) return;
    MPMP.data.models.forEach(function (m) {
      m.derivation = aggregate(m);
      m.rag = m.derivation.rag;
    });
  };
  MPMP.decorate();
})();
