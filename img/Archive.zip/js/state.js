/* ============================================================
   State — in-memory only. No storage APIs.
   Holds: current persona role, decisions/edits made during the
   session (triage acks/escalations, remediation approvals).
   Emits change events that views can subscribe to.
   ============================================================ */
(function () {
  "use strict";
  var MPMP = window.MPMP = window.MPMP || {};

  var ROLES = {
    developer:  { title: "Model Developer", desc: "Triages breaches, investigates root causes." },
    owner:      { title: "Model Owner",     desc: "Reviews and approves remediation on the models you own." },
    governance: { title: "MRM Governance",  desc: "Independent 2LOD oversight, challenge and portfolio-level tracking." },
    mro:        { title: "Model Risk Owner", desc: "SMF-level accountability; portfolio & risk-appetite alignment." }
  };

  var state = {
    role: "developer",
    triage: {}, // id → { decision, severity, materiality, rationale, by, at }
    remediation: {}, // id → { status, decision, rationale }
    toastTimer: null
  };

  var listeners = [];
  function emit() { listeners.forEach(function (fn) { fn(state); }); }

  MPMP.state = {
    ROLES: ROLES,
    get: function () { return state; },
    setRole: function (role) {
      if (!ROLES[role]) return;
      state.role = role;
      emit();
    },
    recordTriage: function (id, payload) {
      state.triage[id] = Object.assign({}, payload, { at: new Date().toISOString().slice(0, 16).replace("T", " ") });
      emit();
    },
    recordRemediation: function (id, payload) {
      state.remediation[id] = Object.assign({}, payload, { at: new Date().toISOString().slice(0, 16).replace("T", " ") });
      emit();
    },
    subscribe: function (fn) { listeners.push(fn); },
    // Effective triage status for a queue item (overlay session state on fixture)
    triageStatus: function (item) {
      var s = state.triage[item.id];
      if (s) return { status: s.decision === "acknowledge" ? "acknowledged" : (s.decision === "reject" ? "rejected" : "escalated"), overlay: s };
      return { status: item.status, overlay: item.triage || null };
    },
    remediationStatus: function (rem) {
      var s = state.remediation[rem.id];
      if (s) return { status: s.status, overlay: s };
      return { status: rem.status, overlay: null };
    }
  };

  // Toast helper — declared here so views can trigger it cheaply.
  MPMP.toast = function (msg) {
    var t = document.getElementById("toast");
    if (!t) return;
    t.textContent = msg;
    t.classList.add("is-visible");
    clearTimeout(state.toastTimer);
    state.toastTimer = setTimeout(function () { t.classList.remove("is-visible"); }, 2600);
  };
})();
