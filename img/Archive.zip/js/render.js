/* ============================================================
   Render helpers — tiny escape + component snippets used across
   views. Keep components dumb: they take data, return HTML.
   ============================================================ */
(function () {
  "use strict";
  var MPMP = window.MPMP = window.MPMP || {};

  function escape(s) {
    if (s === undefined || s === null) return "";
    return String(s)
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;")
      .replace(/'/g, "&#39;");
  }

  var LABEL = { r: "Red", a: "Amber", g: "Green" };

  function rag(color, label) {
    var c = color || "g";
    return '<span class="rag rag--' + c + '">' + escape(label || LABEL[c]) + '</span>';
  }

  function ragBadge(color, label) {
    var c = color || "g";
    return '<span class="badge badge--' + c + '"><span class="rag-dot rag-dot--' + c + '" aria-hidden="true"></span> ' + escape(label || ("Model RAG: " + LABEL[c])) + '</span>';
  }

  function historyStrip(hist) {
    return '<span class="history-strip" aria-label="Last ' + hist.length + ' runs">'
      + hist.map(function (h) { return '<i class="' + h + '" aria-label="' + LABEL[h] + '"></i>'; }).join("")
      + '</span>';
  }

  function spark(hist) {
    // Convert RAG history into a mini bar-height sparkline (r=90, a=60, g=30)
    var map = { r: 90, a: 60, g: 30 };
    return '<span class="spark" aria-hidden="true">'
      + hist.map(function (h) { return '<i style="height:' + (map[h] || 30) + '%"></i>'; }).join("")
      + '</span>';
  }

  // Derivation panel — the transparency artefact for the assumed rule.
  function derivation(model) {
    var d = model.derivation;
    var lines = [];
    lines.push('Rule: Key-KPI dominance with materiality floor');
    lines.push('1. Any KEY KPI = Red   → Red');
    lines.push('2. Any KEY KPI = Amber → Amber');
    lines.push('3. ≥30% non-key A+R, or ≥15% non-key R → Amber');
    lines.push('4. Otherwise → Green');

    var bullets = [];
    bullets.push('<li>Total KPIs: <strong>' + d.inputs.totalKpis + '</strong> (' + d.inputs.keyCount + ' key · ' + d.inputs.nonKeyCount + ' non-key)</li>');
    if (d.inputs.keyReds.length) bullets.push('<li>Key KPIs Red: <strong>' + d.inputs.keyReds.join(", ") + '</strong></li>');
    if (d.inputs.keyAmbers.length) bullets.push('<li>Key KPIs Amber: <strong>' + d.inputs.keyAmbers.join(", ") + '</strong></li>');
    if (d.inputs.nonKeyReds.length) bullets.push('<li>Non-key Red: ' + d.inputs.nonKeyReds.join(", ") + '</li>');
    if (d.inputs.nonKeyBad.length) bullets.push('<li>Non-key Amber+Red: ' + d.inputs.nonKeyBad.join(", ") + '</li>');
    bullets.push('<li>Branch fired: <strong>' + d.branch + '</strong> → <strong>' + LABEL[d.rag] + '</strong></li>');

    return ''
      + '<details class="derivation">'
      +   '<summary class="derivation__title">Derivation — how this RAG was computed</summary>'
      +   '<div class="derivation__rule">' + lines.map(escape).join('<br>') + '</div>'
      +   '<ul>' + bullets.join("") + '</ul>'
      +   '<p class="muted small" style="margin:6px 0 0">The aggregation rule is an <strong>assumption</strong> (see <a href="#/assumptions">Assumptions &amp; rules</a>) — the source docs leave this unresolved (DN-13 / I-02).</p>'
      + '</details>';
  }

  MPMP.h = {
    escape: escape,
    rag: rag,
    ragBadge: ragBadge,
    historyStrip: historyStrip,
    spark: spark,
    derivation: derivation,
    LABEL: LABEL
  };
})();
