/* ============================================================
   Visualisation renderers — plain string builders.
   status grid (Portfolio A), materiality treemap (Portfolio B),
   quadrant (Investigation drill).
   ============================================================ */
(function () {
  "use strict";
  var MPMP = window.MPMP = window.MPMP || {};
  var escape = MPMP.h.escape;

  // ---- Status grid ----
  // Groups by business area. Each cell = one model. Colour = model RAG.
  function statusGrid(models) {
    var byArea = {};
    models.forEach(function (m) {
      byArea[m.businessArea] = byArea[m.businessArea] || [];
      byArea[m.businessArea].push(m);
    });
    var out = '<div class="status-grid">';
    Object.keys(byArea).forEach(function (area) {
      var list = byArea[area];
      var reds = list.filter(function (m) { return m.rag === "r"; }).length;
      var ambs = list.filter(function (m) { return m.rag === "a"; }).length;
      var grns = list.filter(function (m) { return m.rag === "g"; }).length;
      out += '<div class="status-grid__group">'
          +   '<div class="status-grid__head">'
          +     '<strong>' + escape(area) + '</strong>'
          +     '<span class="status-grid__counts">'
          +       list.length + ' &middot; '
          +       '<span class="n-r">' + reds + '</span>/'
          +       '<span class="n-a">' + ambs + '</span>/'
          +       '<span class="n-g">' + grns + '</span>'
          +     '</span>'
          +   '</div>'
          +   '<div class="status-grid__cells" role="list">';
      list.forEach(function (m) {
        out += '<a href="#/model/' + escape(m.id) + '" '
            +      'class="status-grid__cell status-grid__cell--' + m.rag + '" '
            +      'role="listitem" '
            +      'aria-label="' + escape(m.name + ' — ' + MPMP.h.LABEL[m.rag]) + '" '
            +      'title="' + escape(m.name + " · " + MPMP.h.LABEL[m.rag]) + '"></a>';
      });
      out += '</div></div>';
    });
    out += '</div>';
    return out;
  }

  // ---- Materiality treemap ----
  // Tile size = materiality. Colour = model RAG.
  function treemap(models) {
    var weights = { "Very High": 9, "High": 6, "Medium": 4, "Low": 3 };
    var sorted = models.slice().sort(function (a, b) {
      return (weights[b.materiality] || 3) - (weights[a.materiality] || 3);
    });
    var out = '<div class="treemap" role="list">';
    sorted.forEach(function (m) {
      var w = weights[m.materiality] || 3;
      var kpiSummary = m.derivation.inputs.keyReds.length
        ? m.derivation.inputs.keyReds.length + " key KPI(s) failing"
        : (m.derivation.inputs.keyAmbers.length
            ? m.derivation.inputs.keyAmbers.length + " key KPI(s) amber"
            : "no key breach");
      out += '<a href="#/model/' + escape(m.id) + '" '
          +      'class="treemap__tile treemap__tile--' + m.rag + '" '
          +      'role="listitem" '
          +      'style="flex:' + w + ' 1 ' + (w * 14 + 60) + 'px" '
          +      'aria-label="' + escape(m.name + ", materiality " + m.materiality + ", " + MPMP.h.LABEL[m.rag]) + '">'
          +   '<strong>' + escape(m.name) + '</strong>'
          +   '<small>' + escape(m.materiality) + ' &middot; ' + escape(MPMP.h.LABEL[m.rag]) + ' &middot; ' + escape(kpiSummary) + '</small>'
          + '</a>';
    });
    out += '</div>';
    return out;
  }

  // ---- Quadrant (flakiness × failure) — Investigation drill ----
  // x = flakiness (0..1), y = failure rate (0..1).
  function flakiness(hist) {
    if (hist.length < 2) return 0;
    var changes = 0;
    for (var i = 1; i < hist.length; i++) if (hist[i] !== hist[i - 1]) changes++;
    return changes / (hist.length - 1);
  }
  function failRate(hist) {
    var n = hist.filter(function (h) { return h === "r"; }).length;
    return n / hist.length;
  }
  function quadrant(kpis) {
    var out = '<div class="quadrant" role="img" aria-label="Flakiness by failure-rate scatter">';
    kpis.forEach(function (k) {
      var f = flakiness(k.history);
      var fr = failRate(k.history);
      var left = 6 + f * 86;          // %
      var top = 88 - fr * 76;         // % (invert Y)
      out += '<span class="quadrant__dot quadrant__dot--' + k.currentRag + '" '
          +       'style="left:' + left.toFixed(1) + '%; top:' + top.toFixed(1) + '%" '
          +       'title="' + escape(k.name + " · flakiness " + Math.round(f*100) + "% · fail-rate " + Math.round(fr*100) + "%") + '" '
          +       'aria-label="' + escape(k.name) + '"></span>';
      if (k.isKey && (fr > 0.2 || f > 0.3)) {
        out += '<span class="quadrant__label" style="left:' + left.toFixed(1) + '%; top:calc(' + top.toFixed(1) + '% - 18px); transform:translateX(-50%)">' + escape(k.code) + '</span>';
      }
    });
    out += '<span class="quadrant__axis-x">flakiness →</span>'
        +  '<span class="quadrant__axis-y">fail rate →</span>'
        +  '</div>';
    return out;
  }

  MPMP.viz = {
    statusGrid: statusGrid,
    treemap: treemap,
    quadrant: quadrant,
    flakiness: flakiness,
    failRate: failRate
  };
})();
