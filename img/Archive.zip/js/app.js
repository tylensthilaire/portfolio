/* ============================================================
   Bootstrap.
   ============================================================ */
(function () {
  "use strict";
  var MPMP = window.MPMP = window.MPMP || {};

  function updateTriageBadge() {
    var pending = MPMP.data.triageQueue.filter(function (t) {
      return MPMP.state.triageStatus(t).status === "needs-triage";
    }).length;
    var badge = document.getElementById("triage-count");
    if (badge) badge.textContent = pending;
  }

  function updatePersonaPanel() {
    var role = MPMP.state.get().role;
    var info = MPMP.state.ROLES[role];
    var panel = document.getElementById("persona-panel");
    if (panel) panel.innerHTML = '<strong>' + info.title + '</strong>' + info.desc;
  }

  function wireRoleSwitch() {
    var sel = document.getElementById("role-select");
    if (!sel) return;
    sel.value = MPMP.state.get().role;
    sel.addEventListener("change", function () {
      MPMP.state.setRole(sel.value);
    });
  }

  MPMP.state.subscribe(function () {
    updateTriageBadge();
    updatePersonaPanel();
    MPMP.router.rerender();
  });

  document.addEventListener("DOMContentLoaded", function () {
    wireRoleSwitch();
    updateTriageBadge();
    updatePersonaPanel();
    MPMP.router.render();
  });
})();
