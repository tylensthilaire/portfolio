/* ============================================================
   Router — hash-based, five routes + parameterised model detail.
   No dependencies. Re-renders on hashchange or on state change
   (role switching).
   ============================================================ */
(function () {
  "use strict";
  var MPMP = window.MPMP = window.MPMP || {};

  function parseHash() {
    var hash = location.hash || "#/portfolio";
    if (hash.charAt(0) === "#") hash = hash.slice(1);
    var qIdx = hash.indexOf("?");
    var query = {};
    if (qIdx >= 0) {
      hash.slice(qIdx + 1).split("&").forEach(function (kv) {
        var p = kv.split("=");
        query[decodeURIComponent(p[0])] = decodeURIComponent(p[1] || "");
      });
      hash = hash.slice(0, qIdx);
    }
    var parts = hash.split("/").filter(Boolean);
    return { parts: parts, query: query };
  }

  function resolve() {
    var v = MPMP.views;
    var r = parseHash();
    var p = r.parts;
    var q = r.query;

    if (p.length === 0 || p[0] === "portfolio")     return v.portfolio({ view: q.view });
    if (p[0] === "my-models")                        return v.myModels();
    if (p[0] === "triage")                           return v.triage();
    if (p[0] === "catalogue")                        return v.catalogue();
    if (p[0] === "assumptions")                      return v.assumptions();
    if (p[0] === "investigations" && !p[1])          return v.investigationsIndex();
    if (p[0] === "investigation" && p[1])            return v.investigation({ id: p[1] });
    if (p[0] === "remediation" && p[1])              return v.remediation({ id: p[1] });
    if (p[0] === "model" && p[1])                    return v.modelDetail({ id: p[1], tab: p[2] });

    return v.notFound();
  }

  function renderCrumbs(crumbs) {
    var wrap = document.getElementById("crumbs");
    if (!wrap) return;
    wrap.innerHTML = crumbs.map(function (c, i) {
      var sep = i > 0 ? '<span class="sep" aria-hidden="true">/</span>' : '';
      if (c.current) return sep + '<span class="current">' + escape(c.label) + '</span>';
      return sep + '<a href="' + escape(c.href) + '">' + escape(c.label) + '</a>';
    }).join(" ");
  }

  function escape(s) {
    return String(s).replace(/</g, "&lt;");
  }

  function highlightNav(routeName) {
    document.querySelectorAll(".sidebar__link").forEach(function (a) {
      a.classList.toggle("is-active", a.dataset.route === routeName);
    });
  }

  function render() {
    var v = resolve();
    var mount = document.getElementById("view");
    if (!mount) return;
    mount.innerHTML = v.html;
    renderCrumbs(v.crumbs || []);
    highlightNav(v.route);
    document.title = v.title + " · MPMP prototype";
    // Wire generic clickable rows
    mount.querySelectorAll('tr.is-clickable[data-href]').forEach(function (tr) {
      tr.addEventListener("click", function (e) {
        // Ignore clicks on inner <a> — let them navigate normally.
        if (e.target.tagName === "A") return;
        location.hash = tr.dataset.href;
      });
      tr.setAttribute("tabindex", "0");
      tr.addEventListener("keydown", function (e) {
        if (e.key === "Enter" || e.key === " ") {
          e.preventDefault();
          location.hash = tr.dataset.href;
        }
      });
    });
    if (typeof v.onMount === "function") v.onMount(mount);
    // Send focus to main heading for screen readers
    var main = document.getElementById("main");
    if (main) main.focus({ preventScroll: true });
  }

  MPMP.router = {
    render: render,
    rerender: render
  };

  window.addEventListener("hashchange", render);
})();
