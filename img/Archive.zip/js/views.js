/* ============================================================
   Views — one function per screen. Each returns { title, crumbs, html }.
   The router wires innerHTML and attaches event handlers via the
   post-mount hook.
   ============================================================ */
(function () {
  "use strict";
  var MPMP = window.MPMP = window.MPMP || {};
  var h = MPMP.h;
  var d = MPMP.data;
  var viz = MPMP.viz;
  var esc = h.escape;

  function findModel(id) {
    return d.models.filter(function (m) { return m.id === id; })[0];
  }
  function kpiOf(model, code) {
    return model.kpis.filter(function (k) { return k.code === code; })[0];
  }
  function findInvestigation(id) {
    return d.investigations.filter(function (i) { return i.id === id; })[0];
  }
  function findRemediation(id) {
    return d.remediations.filter(function (r) { return r.id === id; })[0];
  }

  // ==========================================================
  // PORTFOLIO
  // ==========================================================
  function portfolio(params) {
    var view = params.view || "grid"; // grid | treemap
    var role = MPMP.state.get().role;

    var counts = d.models.reduce(function (a, m) { a[m.rag]++; a.n++; return a; }, { r: 0, a: 0, g: 0, n: 0 });

    var roleCallout = "";
    if (role === "mro" || role === "governance") {
      roleCallout = '<div class="callout"><strong>Viewing as ' + esc(MPMP.state.ROLES[role].title) + '.</strong> '
        + 'Portfolio Overview is the landing surface for oversight: use Materiality Treemap to see where exposure concentrates.</div>';
    }

    var viz1 = view === "treemap" ? viz.treemap(d.models) : viz.statusGrid(d.models);

    var html = ''
      + '<header class="view__header">'
      +   '<div class="view__title">'
      +     '<h1>Portfolio Overview</h1>'
      +     '<p class="lede">Finance &amp; Treasury &middot; ' + counts.n + ' models under monitoring &middot; Q3 2026</p>'
      +   '</div>'
      + '</header>'
      + roleCallout
      + '<div class="grid-3" style="margin-bottom:24px">'
      +   tile("All models", counts.n, counts.r, counts.a, counts.g)
      +   tile("Finance",   d.models.filter(function(m){return m.fn==="Finance";}))
      +   tile("Treasury",  d.models.filter(function(m){return m.fn==="Treasury";}))
      + '</div>'
      + '<div class="card">'
      +   '<div class="card__header">'
      +     '<h2 class="card__title">Model status &mdash; ' + (view === "treemap" ? "materiality treemap" : "status grid") + '</h2>'
      +     '<div class="row">'
      +       '<a href="#/portfolio?view=grid"    class="chip chip--filter' + (view !== "treemap" ? " is-active" : "") + '">Status grid</a>'
      +       '<a href="#/portfolio?view=treemap" class="chip chip--filter' + (view === "treemap" ? " is-active" : "") + '">Materiality treemap</a>'
      +     '</div>'
      +   '</div>'
      +   '<div class="card__body">'
      +     (view === "treemap"
        ? '<p class="muted small" style="margin-bottom:12px">Tile size = model materiality (Very High / High / Medium / Low). Colour = model RAG. Click any tile to drill in.</p>'
        : '<p class="muted small" style="margin-bottom:12px">Each cell = one model, grouped by business area. Colour = model RAG. Hover a cell for the model name; click to drill in.</p>')
      +     viz1
      +     '<div class="row small muted" style="margin-top:14px">'
      +       '<span><span class="rag-dot rag-dot--g"></span> Green</span>'
      +       '<span><span class="rag-dot rag-dot--a"></span> Amber</span>'
      +       '<span><span class="rag-dot rag-dot--r"></span> Red</span>'
      +       '<span class="spacer"></span>'
      +       '<span>RAG derivation: <a href="#/assumptions">Key-KPI dominance rule</a> (assumed)</span>'
      +     '</div>'
      +   '</div>'
      + '</div>'
      + needsAttentionCard();

    function tile(label, arg2, r, a, g) {
      var n, red, amb, grn;
      if (typeof arg2 === "number") {
        n = arg2; red = r; amb = a; grn = g;
      } else {
        var list = arg2;
        n = list.length;
        red = list.filter(function (m) { return m.rag === "r"; }).length;
        amb = list.filter(function (m) { return m.rag === "a"; }).length;
        grn = list.filter(function (m) { return m.rag === "g"; }).length;
      }
      var barR = n ? Math.round(red / n * 100) : 0;
      var barA = n ? Math.round(amb / n * 100) : 0;
      var barG = 100 - barR - barA;
      return '<div class="card"><div class="card__body">'
        +   '<div class="small muted" style="text-transform:uppercase;letter-spacing:0.06em">' + esc(label) + '</div>'
        +   '<div style="font-family:var(--font-headline);font-size:36px;line-height:1.1;margin:4px 0 10px">' + n + '</div>'
        +   '<div style="display:flex;height:8px;border-radius:5px;overflow:hidden;background:var(--ink-100)">'
        +     '<span style="background:var(--rag-red-solid);   width:' + barR + '%"></span>'
        +     '<span style="background:var(--rag-amber-solid); width:' + barA + '%"></span>'
        +     '<span style="background:var(--rag-green-solid); width:' + barG + '%"></span>'
        +   '</div>'
        +   '<div class="small muted" style="margin-top:6px">'
        +     '<span style="color:var(--rag-red-solid);font-weight:700">' + red + ' Red</span> &middot; '
        +     '<span style="color:var(--rag-amber-solid);font-weight:700">' + amb + ' Amber</span> &middot; '
        +     '<span style="color:var(--rag-green-solid);font-weight:700">' + grn + ' Green</span>'
        +   '</div>'
        + '</div></div>';
    }

    return {
      title: "Portfolio Overview",
      crumbs: [{ href: "#/portfolio", label: "Portfolio", current: true }],
      route: "portfolio",
      html: html
    };
  }

  function needsAttentionCard() {
    var list = d.models
      .filter(function (m) { return m.rag !== "g"; })
      .sort(function (a, b) {
        var order = { "Very High": 4, "High": 3, "Medium": 2, "Low": 1 };
        var ragOrder = { r: 3, a: 2, g: 1 };
        return (ragOrder[b.rag] - ragOrder[a.rag]) || ((order[b.materiality] || 0) - (order[a.materiality] || 0));
      })
      .slice(0, 6);
    var rows = list.map(function (m) {
      return '<tr class="is-clickable" data-href="#/model/' + esc(m.id) + '">'
        + '<td><a class="link" href="#/model/' + esc(m.id) + '">' + esc(m.name) + '</a></td>'
        + '<td>' + esc(m.businessArea) + '</td>'
        + '<td>' + esc(m.materiality) + '</td>'
        + '<td>' + h.rag(m.rag) + '</td>'
        + '<td>' + esc(m.derivation.inputs.keyReds.length ? m.derivation.inputs.keyReds.join(", ") : "&mdash;") + '</td>'
        + '</tr>';
    }).join("");
    return '<div class="card" style="margin-top:24px">'
      + '<div class="card__header"><h2 class="card__title">Needs attention</h2><span class="card__hint">Ordered by RAG then materiality</span></div>'
      + '<div class="card__body card__body--flush">'
      +   '<table class="data-table"><thead><tr>'
      +     '<th>Model</th><th>Business area</th><th>Materiality</th><th>RAG</th><th>Failing key KPIs</th>'
      +   '</tr></thead><tbody>' + rows + '</tbody></table>'
      + '</div></div>';
  }

  // ==========================================================
  // MY MODELS  (Model Owner primary)
  // ==========================================================
  function myModels() {
    var role = MPMP.state.get().role;
    // For prototype: filter to models owned by 'Sebastien Geroult' when role=owner,
    // otherwise show all as "team's models"
    var owner = role === "owner" ? "Sebastien Geroult" : null;
    var list = owner ? d.models.filter(function (m) { return m.owner === owner; }) : d.models;

    var rows = list.map(function (m) {
      var failing = m.kpis.filter(function (k) { return k.currentRag !== "g"; }).length;
      // Any pending remediation for this model?
      var rem = d.remediations.filter(function (r) { return r.modelId === m.id; })[0];
      var remStatus = "";
      if (rem) {
        var st = MPMP.state.remediationStatus(rem).status;
        remStatus = '<span class="chip chip--tone-gold" style="margin-left:6px">Remediation: ' + esc(st) + '</span>';
      }
      return '<tr class="is-clickable" data-href="#/model/' + esc(m.id) + '">'
        + '<td><a class="link" href="#/model/' + esc(m.id) + '">' + esc(m.name) + '</a>' + remStatus + '</td>'
        + '<td>' + esc(m.businessArea) + '</td>'
        + '<td>' + h.rag(m.rag) + '</td>'
        + '<td class="mono small">' + failing + ' of ' + m.kpis.length + '</td>'
        + '<td class="small">' + esc(m.lastRunAt) + '</td>'
        + '<td>' + h.spark(m.kpis[0] ? m.kpis[0].history : []) + '</td>'
        + '</tr>';
    }).join("");

    var html = ''
      + '<header class="view__header"><div class="view__title">'
      +   '<h1>' + (owner ? "My Models" : "All Models (owner view)") + '</h1>'
      +   '<p class="lede">' + (owner
             ? "The models you own — headline RAG, current breaches and any pending remediation."
             : "Switch to <a href='#' onclick='MPMP.state.setRole(\"owner\");return false;'>Model Owner</a> to filter to a single owner.") + '</p>'
      + '</div></header>'
      + '<div class="card"><div class="card__body card__body--flush">'
      +   '<table class="data-table"><thead><tr>'
      +     '<th>Model</th><th>Business area</th><th>Model RAG</th><th>Failing KPIs</th><th>Last run</th><th>90-day trend</th>'
      +   '</tr></thead><tbody>' + rows + '</tbody></table>'
      + '</div></div>';

    return {
      title: "My Models",
      crumbs: [{ href: "#/my-models", label: "My Models", current: true }],
      route: "my-models",
      html: html
    };
  }

  // ==========================================================
  // TRIAGE — Journey J1
  // ==========================================================
  function triage() {
    var tabs = { needs: 0, ack: 0 };
    var itemsView = { needs: [], ack: [] };
    d.triageQueue.forEach(function (item) {
      var status = MPMP.state.triageStatus(item).status;
      if (status === "needs-triage") { tabs.needs++; itemsView.needs.push(item); }
      else { tabs.ack++; itemsView.ack.push(item); }
    });

    var currentTab = window.MPMP._triageTab || "needs";
    var items = itemsView[currentTab === "ack" ? "ack" : "needs"];

    var rows = items.map(function (item) {
      var m = findModel(item.modelId);
      var k = kpiOf(m, item.kpiCode);
      var effective = MPMP.state.triageStatus(item);
      var overlay = effective.overlay;
      var decidedNote = overlay
        ? '<div class="callout" style="margin:8px 0 0">Decision: <strong>' + esc(overlay.decision) + '</strong> — ' + esc(overlay.rationale) + '</div>'
        : "";
      var actions = overlay
        ? '<button class="btn btn--sm" data-action="view" data-model="' + esc(m.id) + '">Open model</button>'
        : (''
            + '<button class="btn btn--sm" data-action="triage-open" data-tq="' + esc(item.id) + '">Triage</button>'
            + '<a class="btn btn--sm btn--ghost" href="#/model/' + esc(m.id) + '">Open model</a>'
          );

      return '<article class="card" style="margin-bottom:12px" id="tq-' + esc(item.id) + '">'
        + '<div class="card__body">'
        +   '<div class="row" style="align-items:flex-start">'
        +     h.rag(k.currentRag)
        +     '<div style="flex:1;min-width:0">'
        +       '<div style="font-weight:700">' + esc(m.name) + ' &mdash; ' + esc(k.name) + '</div>'
        +       '<div class="small muted">' + esc(item.note) + '</div>'
        +     '</div>'
        +     '<div class="small mono muted" style="text-align:right;white-space:nowrap">'
        +       'Severity: ' + esc(item.severity) + '<br>'
        +       'Age ' + item.ageDays + 'd / SLA ' + item.slaDays + 'd'
        +     '</div>'
        +     '<div class="row" style="gap:6px">' + actions + '</div>'
        +   '</div>'
        +   decidedNote
        +   '<div id="triage-form-' + esc(item.id) + '" hidden></div>'
        + '</div>'
      + '</article>';
    }).join("");

    if (!rows) rows = '<div class="card"><div class="card__body muted">Nothing in this tab.</div></div>';

    var html = ''
      + '<header class="view__header"><div class="view__title">'
      +   '<h1>Monitoring Queue</h1>'
      +   '<p class="lede">Breaches published by MPMP awaiting triage. As Model Developer, classify each breach and choose an action.</p>'
      + '</div></header>'
      + '<div class="tabs" role="tablist">'
      +   '<button class="tabs__tab' + (currentTab === "needs" ? " is-active" : "") + '" data-tab="needs" role="tab">Needs triage <span class="count">' + tabs.needs + '</span></button>'
      +   '<button class="tabs__tab' + (currentTab === "ack" ? " is-active" : "") + '"  data-tab="ack"   role="tab">Acknowledged &amp; Escalated <span class="count">' + tabs.ack + '</span></button>'
      + '</div>'
      + rows;

    return {
      title: "Monitoring Queue",
      crumbs: [{ href: "#/triage", label: "Monitoring Queue", current: true }],
      route: "triage",
      html: html,
      onMount: bindTriage
    };
  }

  function bindTriage(root) {
    root.querySelectorAll(".tabs__tab").forEach(function (b) {
      b.addEventListener("click", function () {
        window.MPMP._triageTab = b.dataset.tab;
        MPMP.router.rerender();
      });
    });
    root.querySelectorAll('[data-action="triage-open"]').forEach(function (btn) {
      btn.addEventListener("click", function () {
        var id = btn.dataset.tq;
        var form = document.getElementById("triage-form-" + id);
        if (!form) return;
        var item = d.triageQueue.filter(function (t) { return t.id === id; })[0];
        var m = findModel(item.modelId);
        var k = kpiOf(m, item.kpiCode);
        form.hidden = false;
        form.innerHTML = renderTriageForm(item, m, k);
        var sel = form.querySelector('[data-decision]');
        form.querySelectorAll('.chip--filter').forEach(function (c) {
          c.addEventListener("click", function () {
            form.querySelectorAll('.chip--filter[data-group="' + c.dataset.group + '"]').forEach(function (o) { o.classList.remove("is-active"); });
            c.classList.add("is-active");
          });
        });
        form.querySelector('[data-cancel]').addEventListener("click", function () { form.hidden = true; form.innerHTML = ""; });
        form.querySelector('[data-submit]').addEventListener("click", function () {
          var decision = form.querySelector('[data-decision].is-active');
          var severity = form.querySelector('[data-group="severity"].is-active');
          var material = form.querySelector('[data-group="materiality"].is-active');
          var rationale = form.querySelector('[data-rationale]').value.trim();
          if (!decision || !severity || !material || !rationale) {
            MPMP.toast("All fields required to record a triage decision.");
            return;
          }
          MPMP.state.recordTriage(id, {
            decision: decision.dataset.decision,
            severity: severity.dataset.value,
            materiality: material.dataset.value,
            rationale: rationale,
            by: MPMP.state.ROLES[MPMP.state.get().role].title
          });
          MPMP.toast("Triage recorded — " + decision.dataset.decision + ".");
          if (decision.dataset.decision === "escalate") {
            setTimeout(function () { location.hash = "#/investigation/inv-2026-039"; }, 400);
          } else {
            MPMP.router.rerender();
          }
        });
      });
    });
    root.querySelectorAll('tr.is-clickable[data-href]').forEach(function (tr) {
      tr.addEventListener("click", function () { location.hash = tr.dataset.href; });
    });
    root.querySelectorAll('[data-action="view"]').forEach(function (b) {
      b.addEventListener("click", function () { location.hash = "#/model/" + b.dataset.model; });
    });
  }

  function renderTriageForm(item, m, k) {
    return ''
      + '<div style="margin-top:14px;padding-top:14px;border-top:1px dashed var(--ink-200)">'
      +   '<h3 style="font-family:var(--font-body);font-size:14px;text-transform:uppercase;letter-spacing:0.06em;color:var(--ink-500);margin-bottom:10px">Triage decision</h3>'
      +   '<div class="field">'
      +     '<label class="field__label">Severity</label>'
      +     '<div class="row">'
      +       '<button class="chip chip--filter" data-group="severity" data-value="High">High</button>'
      +       '<button class="chip chip--filter" data-group="severity" data-value="Medium">Medium</button>'
      +       '<button class="chip chip--filter" data-group="severity" data-value="Low">Low</button>'
      +     '</div>'
      +   '</div>'
      +   '<div class="field">'
      +     '<label class="field__label">Materiality</label>'
      +     '<div class="row">'
      +       '<button class="chip chip--filter" data-group="materiality" data-value="Material">Material</button>'
      +       '<button class="chip chip--filter" data-group="materiality" data-value="Non-material">Non-material</button>'
      +     '</div>'
      +   '</div>'
      +   '<div class="field">'
      +     '<label class="field__label" for="triage-rat-' + esc(item.id) + '">Rationale (required for audit trail)</label>'
      +     '<textarea id="triage-rat-' + esc(item.id) + '" class="field__input" data-rationale placeholder="e.g. PSI drift is directional and consistent with segment-mix shift observed in monthly report; recommend investigation."></textarea>'
      +   '</div>'
      +   '<div class="field">'
      +     '<label class="field__label">Action</label>'
      +     '<div class="row">'
      +       '<button class="chip chip--filter" data-decision="acknowledge">Acknowledge (accept)</button>'
      +       '<button class="chip chip--filter" data-decision="escalate">Escalate to investigation</button>'
      +       '<button class="chip chip--filter" data-decision="reject">Reject as false positive</button>'
      +     '</div>'
      +   '</div>'
      +   '<div class="row" style="justify-content:flex-end;margin-top:12px">'
      +     '<button class="btn btn--ghost" data-cancel>Cancel</button>'
      +     '<button class="btn btn--primary" data-submit>Record decision</button>'
      +   '</div>'
      + '</div>';
  }

  // ==========================================================
  // MODEL DETAIL (with tabs)
  // ==========================================================
  function modelDetail(params) {
    var m = findModel(params.id);
    if (!m) return notFound();
    var tab = params.tab || "overview";
    var body;
    if (tab === "kpis") body = detailKpis(m);
    else if (tab === "runs") body = detailRuns(m);
    else if (tab === "investigations") body = detailInvestigations(m);
    else if (tab === "evidence") body = detailEvidence(m);
    else body = detailOverview(m);

    var pendingRem = d.remediations.filter(function (r) { return r.modelId === m.id; })[0];
    var role = MPMP.state.get().role;
    var ownerCallout = "";
    if (role === "owner" && pendingRem) {
      var status = MPMP.state.remediationStatus(pendingRem).status;
      if (status === "Pending approval") {
        ownerCallout = '<div class="callout callout--assume"><strong>Awaiting your approval.</strong> A remediation recommendation has been filed for this model. '
          + '<a href="#/remediation/' + esc(pendingRem.id) + '">Review it &rarr;</a></div>';
      }
    }

    var html = ''
      + '<header class="view__header" style="flex-direction:column;align-items:flex-start;gap:8px">'
      +   '<div class="row" style="gap:14px">'
      +     '<h1 style="margin:0">' + esc(m.name) + '</h1>'
      +     h.ragBadge(m.rag)
      +     '<span class="chip">' + esc(m.materiality) + ' materiality</span>'
      +     '<span class="chip">' + esc(m.fn) + '</span>'
      +   '</div>'
      +   '<p class="lede">' + esc(m.description) + '</p>'
      + '</header>'
      + ownerCallout
      + h.derivation(m)
      + '<div class="tabs" role="tablist">'
      +   tabBtn("overview",       "Overview",       tab)
      +   tabBtn("kpis",           "KPIs",           tab, m.kpis.length)
      +   tabBtn("runs",           "Runs",           tab, 12)
      +   tabBtn("investigations", "Investigations", tab, d.investigations.filter(function(i){return i.modelId===m.id;}).length)
      +   tabBtn("evidence",       "Evidence / Audit trail", tab)
      + '</div>'
      + body;

    function tabBtn(id, label, active, count) {
      var url = "#/model/" + m.id + (id === "overview" ? "" : "/" + id);
      var cnt = count !== undefined ? ' <span class="count">' + count + '</span>' : "";
      return '<a href="' + url + '" role="tab" class="tabs__tab' + (active === id ? " is-active" : "") + '">' + esc(label) + cnt + '</a>';
    }

    return {
      title: m.name,
      crumbs: [
        { href: "#/portfolio", label: "Portfolio" },
        { href: "#/model/" + m.id, label: m.name, current: true }
      ],
      route: null,
      html: html
    };
  }

  function detailOverview(m) {
    var stats = ''
      + '<div class="kpi-ribbon">'
      +   '<div class="kpi-ribbon__stat"><div class="label">Owner</div><div class="value" style="font-size:16px">' + esc(m.owner) + '</div></div>'
      +   '<div class="kpi-ribbon__stat"><div class="label">Developer</div><div class="value" style="font-size:16px">' + esc(m.developer) + '</div></div>'
      +   '<div class="kpi-ribbon__stat"><div class="label">Version</div><div class="value" style="font-size:16px">' + esc(m.version) + '</div></div>'
      +   '<div class="kpi-ribbon__stat"><div class="label">Environment</div><div class="value" style="font-size:16px">' + esc(m.environment) + '</div></div>'
      +   '<div class="kpi-ribbon__stat"><div class="label">Last run</div><div class="value" style="font-size:16px">' + esc(m.lastRunAt) + '</div></div>'
      + '</div>';

    var kpiSummary = m.kpis.map(function (k) {
      return '<div class="row" style="padding:8px 0;border-bottom:1px solid var(--ink-100)">'
        + '<div style="flex:1"><strong>' + esc(k.name) + '</strong>'
        + (k.isKey ? ' <span class="chip chip--tone-gold" style="font-size:11px">KEY</span>' : "")
        + '<div class="small muted">' + esc(k.threshold) + '</div></div>'
        + '<div class="small mono">latest: ' + esc(k.latest) + '</div>'
        + h.historyStrip(k.history)
        + h.rag(k.currentRag)
        + '</div>';
    }).join("");

    return stats
      + '<div class="card"><div class="card__header"><h2 class="card__title">Current KPI state</h2><span class="card__hint">Last 12 runs shown as strip</span></div>'
      + '<div class="card__body">' + kpiSummary + '</div></div>';
  }

  function detailKpis(m) {
    var rows = m.kpis.map(function (k) {
      return '<tr>'
        + '<td><strong>' + esc(k.name) + '</strong>' + (k.isKey ? ' <span class="chip chip--tone-gold" style="font-size:10px;padding:1px 6px">KEY</span>' : "") + '</td>'
        + '<td class="mono small">' + esc(k.latest) + '</td>'
        + '<td class="mono small">' + esc(k.threshold) + '</td>'
        + '<td>' + h.rag(k.currentRag) + '</td>'
        + '<td>' + h.historyStrip(k.history) + '</td>'
        + '</tr>';
    }).join("");
    return '<div class="card"><div class="card__body card__body--flush">'
      + '<table class="data-table"><thead><tr>'
      +   '<th>KPI</th><th>Latest</th><th>Threshold</th><th>RAG</th><th>Trend (12 runs)</th>'
      + '</tr></thead><tbody>' + rows + '</tbody></table>'
      + '</div></div>';
  }

  function detailRuns(m) {
    // Fabricate 12 run rows from RUNS + KPI aggregates.
    var rows = d.RUNS.slice().reverse().map(function (date, idx) {
      var runIndex = d.RUNS.length - 1 - idx;
      var statuses = m.kpis.map(function (k) { return k.history[runIndex]; });
      var runRag = statuses.indexOf("r") >= 0 ? "r" : (statuses.indexOf("a") >= 0 ? "a" : "g");
      return '<tr>'
        + '<td class="mono small">' + esc(date) + ' 06:00</td>'
        + '<td class="small">Scheduled</td>'
        + '<td class="mono small">' + esc(m.version) + '</td>'
        + '<td>Succeeded</td>'
        + '<td>' + h.rag(runRag) + '</td>'
        + '</tr>';
    }).join("");
    return '<div class="card"><div class="card__body card__body--flush">'
      + '<table class="data-table"><thead><tr>'
      +   '<th>Executed at</th><th>Trigger</th><th>Code version</th><th>Status</th><th>Aggregated RAG</th>'
      + '</tr></thead><tbody>' + rows + '</tbody></table>'
      + '</div></div>';
  }

  function detailInvestigations(m) {
    var invs = d.investigations.filter(function (i) { return i.modelId === m.id; });
    var invRows = invs.map(function (i) {
      return '<tr class="is-clickable" data-href="#/investigation/' + esc(i.id) + '">'
        + '<td><a class="link" href="#/investigation/' + esc(i.id) + '">' + esc(i.id) + '</a></td>'
        + '<td>' + esc(i.triggerKpiCode) + '</td>'
        + '<td>' + esc(i.status) + '</td>'
        + '<td>' + esc(i.openedBy) + '</td>'
        + '<td class="small mono">' + esc(i.openedAt) + '</td>'
        + '</tr>';
    }).join("");
    if (!invRows) invRows = '<tr><td colspan="5" class="muted">No open investigations for this model.</td></tr>';

    var rems = d.remediations.filter(function (r) { return r.modelId === m.id; });
    var remRows = rems.map(function (r) {
      var st = MPMP.state.remediationStatus(r).status;
      return '<tr class="is-clickable" data-href="#/remediation/' + esc(r.id) + '">'
        + '<td><a class="link" href="#/remediation/' + esc(r.id) + '">' + esc(r.id) + '</a></td>'
        + '<td>' + esc(r.category) + '</td>'
        + '<td>' + esc(st) + '</td>'
        + '<td>' + esc(r.proposedBy) + '</td>'
        + '<td class="small mono">' + esc(r.timeline) + '</td>'
        + '</tr>';
    }).join("");
    if (!remRows) remRows = '<tr><td colspan="5" class="muted">No remediation actions filed.</td></tr>';

    return '<div class="card"><div class="card__header"><h2 class="card__title">Investigations</h2>'
      + '<a href="#/investigations" class="btn btn--sm btn--ghost">All investigations &rarr;</a></div>'
      + '<div class="card__body card__body--flush">'
      +   '<table class="data-table"><thead><tr>'
      +     '<th>ID</th><th>Trigger KPI</th><th>Status</th><th>Opened by</th><th>Opened at</th>'
      +   '</tr></thead><tbody>' + invRows + '</tbody></table>'
      + '</div></div>'
      + '<div class="card" style="margin-top:20px"><div class="card__header"><h2 class="card__title">Remediation</h2></div>'
      + '<div class="card__body card__body--flush">'
      +   '<table class="data-table"><thead><tr>'
      +     '<th>ID</th><th>Category</th><th>Status</th><th>Proposed by</th><th>Timeline</th>'
      +   '</tr></thead><tbody>' + remRows + '</tbody></table>'
      + '</div></div>';
  }

  function detailEvidence(m) {
    return '<div class="card"><div class="card__body">'
      + '<h2 style="margin-bottom:8px">Audit trail</h2>'
      + '<p class="lede">Every decision, approval and validation on this model, in reverse-chronological order.</p>'
      + '<ol class="timeline" style="margin-top:16px">'
      +   '<li class="current"><div class="timeline__title">Aggregated RAG published</div><div class="timeline__meta">MPMP automation &middot; ' + esc(m.lastRunAt) + '</div><div class="small muted" style="margin-top:2px">' + esc(m.derivation.branch) + '</div></li>'
      +   '<li class="done"><div class="timeline__title">KPI test suite executed (12 KPI checks)</div><div class="timeline__meta">MPMP automation &middot; ' + esc(m.lastRunAt) + '</div></li>'
      +   '<li class="done"><div class="timeline__title">Model run received from MDE</div><div class="timeline__meta">' + esc(m.environment) + ' &middot; ' + esc(m.lastRunAt) + '</div></li>'
      +   '<li class="done"><div class="timeline__title">Model version validated (MMS)</div><div class="timeline__meta">Approver: MRM Governance &middot; 2026-05-14</div></li>'
      + '</ol>'
      + '<p class="small muted" style="margin-top:14px">Prototype note: Evidence tab is illustrative — full audit-trail wiring is deferred (see <a href="#/assumptions">Assumptions &amp; rules</a>).</p>'
      + '</div></div>';
  }

  // ==========================================================
  // INVESTIGATION DETAIL — Journey J2
  // ==========================================================
  function investigation(params) {
    var i = findInvestigation(params.id);
    if (!i) return notFound();
    var m = findModel(i.modelId);

    var byLens = { data: [], model: [], process: [] };
    i.hypotheses.forEach(function (h) { byLens[h.lens].push(h); });

    function lensBlock(key, title, blurb) {
      var cards = byLens[key].map(function (hyp) {
        var confClass = hyp.confidence === "high" ? "hypothesis__conf--hi" : (hyp.confidence === "low" ? "hypothesis__conf--lo" : "");
        return '<div class="hypothesis" data-hyp="' + esc(hyp.id) + '" data-state="' + esc(hyp.state) + '">'
          + '<div class="hypothesis__head">'
          +   '<h4>' + esc(hyp.title) + '</h4>'
          +   '<span class="spacer"></span>'
          +   '<span class="hypothesis__conf ' + confClass + '">' + esc(hyp.confidence.toUpperCase()) + '</span>'
          + '</div>'
          + '<div class="hypothesis__evidence">' + esc(hyp.evidence) + '</div>'
          + '<div class="hypothesis__actions">'
          +   '<button class="btn btn--sm ' + (hyp.state === "confirmed" ? "btn--primary" : "") + '" data-hyp-action="confirm">Confirm</button>'
          +   '<button class="btn btn--sm btn--ghost" data-hyp-action="dismiss">Dismiss</button>'
          +   '<span class="spacer"></span>'
          +   (hyp.state === "confirmed" ? '<span class="chip chip--tone-gold">Confirmed root cause</span>' : "")
          +   (hyp.state === "dismissed" ? '<span class="chip">Dismissed</span>' : "")
          + '</div></div>';
      }).join("");
      return '<div class="card" style="margin-bottom:20px">'
        + '<div class="card__header">'
        +   '<h2 class="card__title">' + esc(title) + '</h2>'
        +   '<span class="card__hint">' + esc(blurb) + '</span>'
        + '</div>'
        + '<div class="card__body">'
        +   '<p class="small muted" style="margin-bottom:12px">AI-suggested hypotheses (stub) — the analyst confirms or dismisses. What gets recorded is the analyst\'s decision, not the AI suggestion.</p>'
        +   cards
        + '</div></div>';
    }

    var conclusionEditable = '<div class="stack">'
      + '<div class="field"><label class="field__label">Root-cause conclusion</label>'
      +   '<textarea class="field__input" readonly>' + esc(i.rootCause) + '</textarea></div>'
      + '<div class="grid-2">'
      +   '<div class="field"><label class="field__label">Recommended action</label>'
      +     '<textarea class="field__input" readonly>' + esc(i.recommendation) + '</textarea></div>'
      +   '<div>'
      +     '<div class="field"><label class="field__label">Category</label>'
      +       '<div><span class="chip chip--filter is-active">' + esc(i.recommendationCategory) + '</span></div></div>'
      +     '<div class="field"><label class="field__label">Timeline</label>'
      +       '<div class="mono">' + esc(i.recommendationTimeline) + '</div></div>'
      +   '</div>'
      + '</div>'
      + '<div class="row" style="justify-content:flex-end">'
      +   '<a class="btn btn--ghost" href="#/model/' + esc(m.id) + '/investigations">Cancel</a>'
      +   '<button class="btn btn--primary" data-file-remediation>File remediation recommendation</button>'
      + '</div></div>';

    var html = ''
      + '<header class="view__header" style="flex-direction:column;align-items:flex-start;gap:8px">'
      +   '<div class="row"><h1 style="margin:0">Investigation ' + esc(i.id) + '</h1>'
      +     '<span class="chip">' + esc(i.status) + '</span></div>'
      +   '<p class="lede">Root-cause analysis for <a href="#/model/' + esc(m.id) + '"><strong>' + esc(m.name) + '</strong></a> — triggered by KPI <strong>' + esc(i.triggerKpiCode) + '</strong>.</p>'
      + '</header>'
      + '<div class="callout"><strong>Journey step 5 — Investigation.</strong> Structured across three lenses (data / model / process). '
      + 'The AI hypothesis panel is a UI stub demonstrating the design need (DN-06); no LLM is running.</div>'
      + '<div class="grid-detail">'
      +   '<div>'
      +     lensBlock("data", "Data factors", "drift, quality, missing/anomalous inputs")
      +     lensBlock("model", "Model factors", "calibration, discrimination, stability, concept drift")
      +     lensBlock("process", "Process & infrastructure", "pipeline, execution, integration")
      +     '<div class="card"><div class="card__header"><h2 class="card__title">Conclusion &amp; remediation</h2></div>'
      +     '<div class="card__body">' + conclusionEditable + '</div></div>'
      +   '</div>'
      +   '<aside>'
      +     '<div class="card"><div class="card__body">'
      +       '<h3 style="font-family:var(--font-body);font-size:12px;text-transform:uppercase;letter-spacing:0.06em;color:var(--ink-500);margin-bottom:10px">Flakiness × failure</h3>'
      +       viz.quadrant(m.kpis)
      +       '<p class="small muted" style="margin-top:10px">A secondary signal — helps distinguish drift (top-right: fails often, stable) from flakiness (top-left: fails often, oscillates).</p>'
      +     '</div></div>'
      +     '<div class="card" style="margin-top:16px"><div class="card__body">'
      +       '<h3 style="font-family:var(--font-body);font-size:12px;text-transform:uppercase;letter-spacing:0.06em;color:var(--ink-500);margin-bottom:10px">KPI trend wall</h3>'
      +       m.kpis.map(function (k) {
                return '<div class="trend-wall">'
                  + '<div class="trend-wall__name">' + esc(k.code) + '<small>' + esc(k.name) + '</small></div>'
                  + '<div class="trend-wall__strip">' + k.history.map(function (h) { return '<i class="' + h + '"></i>'; }).join("") + '</div>'
                  + '<div>' + h.rag(k.currentRag) + '</div>'
                  + '</div>';
              }).join("")
      +     '</div></div>'
      +   '</aside>'
      + '</div>';

    return {
      title: "Investigation " + i.id,
      crumbs: [
        { href: "#/portfolio", label: "Portfolio" },
        { href: "#/model/" + m.id, label: m.name },
        { href: "#/investigation/" + i.id, label: "Investigation", current: true }
      ],
      route: null,
      html: html,
      onMount: function (root) {
        root.querySelectorAll('.hypothesis').forEach(function (card) {
          card.querySelectorAll('[data-hyp-action]').forEach(function (btn) {
            btn.addEventListener("click", function () {
              var action = btn.dataset.hypAction;
              card.dataset.state = action === "confirm" ? "confirmed" : "dismissed";
              MPMP.toast("Hypothesis " + (action === "confirm" ? "confirmed" : "dismissed") + ".");
            });
          });
        });
        var fileBtn = root.querySelector('[data-file-remediation]');
        if (fileBtn) fileBtn.addEventListener("click", function () {
          MPMP.toast("Remediation recommendation filed. Awaiting owner approval.");
          setTimeout(function () { location.hash = "#/remediation/rem-2026-024"; }, 500);
        });
      }
    };
  }

  // ==========================================================
  // INVESTIGATIONS INDEX (top-level)
  // ==========================================================
  function investigationsIndex() {
    var rows = d.investigations.map(function (i) {
      var m = findModel(i.modelId);
      return '<tr class="is-clickable" data-href="#/investigation/' + esc(i.id) + '">'
        + '<td><a class="link" href="#/investigation/' + esc(i.id) + '">' + esc(i.id) + '</a></td>'
        + '<td>' + esc(m.name) + '</td>'
        + '<td>' + esc(i.triggerKpiCode) + '</td>'
        + '<td>' + esc(i.status) + '</td>'
        + '<td>' + esc(i.openedBy) + '</td>'
        + '<td class="small mono">' + esc(i.openedAt) + '</td>'
        + '</tr>';
    }).join("");
    return {
      title: "Investigations",
      crumbs: [{ href: "#/investigations", label: "Investigations", current: true }],
      route: "investigations",
      html: '<header class="view__header"><div class="view__title"><h1>Investigations</h1>'
        + '<p class="lede">Open and recent investigations across all models.</p></div></header>'
        + '<div class="card"><div class="card__body card__body--flush">'
        + '<table class="data-table"><thead><tr>'
        +   '<th>ID</th><th>Model</th><th>Trigger KPI</th><th>Status</th><th>Opened by</th><th>Opened at</th>'
        + '</tr></thead><tbody>' + rows + '</tbody></table>'
        + '</div></div>'
    };
  }

  // ==========================================================
  // REMEDIATION DETAIL — Journey J3
  // ==========================================================
  function remediation(params) {
    var r = findRemediation(params.id);
    if (!r) return notFound();
    var m = findModel(r.modelId);
    var effective = MPMP.state.remediationStatus(r);
    var overlay = effective.overlay;
    var currentStatus = effective.status;
    var role = MPMP.state.get().role;

    // Timeline can be overlaid by session-recorded state.
    var events = r.timeline_events.slice();
    if (overlay) {
      if (overlay.status === "In progress") { events[1].state = "done"; events[2].state = "current"; events[1].meta = "Karl Rodolfo · approved just now"; }
      if (overlay.status === "Validating") { events[1].state = "done"; events[2].state = "done"; events[3].state = "current"; }
      if (overlay.status === "Resolved") { events.forEach(function (e) { e.state = "done"; }); }
      if (overlay.status === "Rejected") { events[1].state = "done"; events[1].meta = "Karl Rodolfo · rejected — " + overlay.rationale; events[2].state = "pending"; events[2].meta = "Not proceeding"; }
    }
    var timeline = '<ol class="timeline">' + events.map(function (e) {
      return '<li class="' + esc(e.state) + '">'
        + '<div class="timeline__title">' + esc(e.title) + '</div>'
        + '<div class="timeline__meta">' + esc(e.meta) + '</div>'
        + '</li>';
    }).join("") + '</ol>';

    var actions = "";
    if (role === "owner" && currentStatus === "Pending approval") {
      actions = '<div class="stack">'
        + '<div class="field"><label class="field__label">Approval note (recorded on audit trail)</label>'
        +   '<textarea class="field__input" data-remediation-rat placeholder="Proportionate to risk; endorse; add manual review flag as belt-and-braces."></textarea></div>'
        + '<div class="row" style="justify-content:flex-end">'
        +   '<button class="btn btn--danger" data-remediation-decision="Rejected">Reject</button>'
        +   '<button class="btn" data-remediation-decision="Request revisions">Request revisions</button>'
        +   '<button class="btn btn--primary" data-remediation-decision="In progress">Approve</button>'
        + '</div></div>';
    } else if (currentStatus === "In progress") {
      actions = '<div class="row" style="justify-content:flex-end;margin-top:12px">'
        + '<button class="btn btn--primary" data-remediation-decision="Validating">Simulate implementation &amp; kick off validation</button>'
        + '</div>';
    } else if (currentStatus === "Validating") {
      actions = '<div class="callout"><strong>Post-implementation validation</strong> — a fresh model run has been received. KPI CAL now reads 0.9% (was 1.3%). Confirm resolution?</div>'
        + '<div class="row" style="justify-content:flex-end">'
        + '<button class="btn" data-remediation-decision="Iterating">Iterate</button>'
        + '<button class="btn btn--primary" data-remediation-decision="Resolved">Confirm resolved</button>'
        + '</div>';
    } else if (currentStatus === "Resolved") {
      actions = '<div class="callout"><strong>Resolved.</strong> Model has returned to standard monitoring. Aggregated RAG will recompute on the next run.</div>';
    } else if (overlay && overlay.status === "Rejected") {
      actions = '<div class="callout callout--warn"><strong>Rejected.</strong> ' + esc(overlay.rationale) + '</div>';
    }

    var html = ''
      + '<header class="view__header" style="flex-direction:column;align-items:flex-start;gap:8px">'
      +   '<div class="row"><h1 style="margin:0">Remediation ' + esc(r.id) + '</h1>'
      +     '<span class="chip chip--tone-gold">' + esc(currentStatus) + '</span></div>'
      +   '<p class="lede">Filed against <a href="#/model/' + esc(m.id) + '"><strong>' + esc(m.name) + '</strong></a> — investigation <a href="#/investigation/' + esc(r.investigationId) + '">' + esc(r.investigationId) + '</a>.</p>'
      + '</header>'
      + '<div class="grid-detail">'
      +   '<div class="card"><div class="card__body stack">'
      +     '<div>'
      +       '<h3>Proposed action</h3>'
      +       '<p>' + esc(r.actionPlan) + '</p>'
      +     '</div>'
      +     '<div class="grid-2 small">'
      +       '<div><strong>Category:</strong> ' + esc(r.category) + '</div>'
      +       '<div><strong>Timeline:</strong> ' + esc(r.timeline) + '</div>'
      +       '<div><strong>Proposed by:</strong> ' + esc(r.proposedBy) + '</div>'
      +       '<div><strong>Filed:</strong> ' + esc(r.proposedAt) + '</div>'
      +     '</div>'
      +     actions
      +   '</div></div>'
      +   '<aside class="card"><div class="card__body">'
      +     '<h3 style="font-family:var(--font-body);font-size:12px;text-transform:uppercase;letter-spacing:0.06em;color:var(--ink-500);margin-bottom:10px">Progress</h3>'
      +     timeline
      +   '</div></aside>'
      + '</div>';

    return {
      title: "Remediation " + r.id,
      crumbs: [
        { href: "#/portfolio", label: "Portfolio" },
        { href: "#/model/" + m.id, label: m.name },
        { href: "#/remediation/" + r.id, label: "Remediation", current: true }
      ],
      route: null,
      html: html,
      onMount: function (root) {
        root.querySelectorAll('[data-remediation-decision]').forEach(function (btn) {
          btn.addEventListener("click", function () {
            var decision = btn.dataset.remediationDecision;
            var rat = "";
            var ta = root.querySelector('[data-remediation-rat]');
            if (ta) rat = ta.value.trim();
            if ((decision === "In progress" || decision === "Rejected") && !rat) {
              MPMP.toast("Approval note required for the audit trail.");
              return;
            }
            MPMP.state.recordRemediation(r.id, { status: decision, rationale: rat, by: MPMP.state.ROLES[MPMP.state.get().role].title });
            MPMP.toast("Remediation status: " + decision + ".");
            MPMP.router.rerender();
          });
        });
      }
    };
  }

  // ==========================================================
  // CATALOGUE (light — Step 1 admin, out of Steps-4/6 scope)
  // ==========================================================
  function catalogue() {
    var rows = d.models.map(function (m) {
      return '<tr class="is-clickable" data-href="#/model/' + esc(m.id) + '">'
        + '<td><a class="link" href="#/model/' + esc(m.id) + '">' + esc(m.name) + '</a></td>'
        + '<td>' + esc(m.owner) + '</td>'
        + '<td>' + esc(m.version) + '</td>'
        + '<td>' + esc(m.environment) + '</td>'
        + '<td>' + esc(m.materiality) + '</td>'
        + '<td>' + h.rag(m.rag) + '</td>'
        + '</tr>';
    }).join("");
    return {
      title: "Model Catalogue",
      crumbs: [{ href: "#/catalogue", label: "Model Catalogue", current: true }],
      route: "catalogue",
      html: '<header class="view__header"><div class="view__title"><h1>Model Catalogue</h1>'
        + '<p class="lede">Every registered model in MPMP. Catalogue admin (Step 1) is out of scope for this prototype — see <a href="#/assumptions">Assumptions</a>.</p></div></header>'
        + '<div class="card"><div class="card__body card__body--flush">'
        + '<table class="data-table"><thead><tr>'
        +   '<th>Name</th><th>Owner</th><th>Version</th><th>Environment</th><th>Materiality</th><th>RAG</th>'
        + '</tr></thead><tbody>' + rows + '</tbody></table>'
        + '</div></div>'
    };
  }

  // ==========================================================
  // ASSUMPTIONS  (the transparency page)
  // ==========================================================
  function assumptions() {
    return {
      title: "Assumptions & rules",
      crumbs: [{ href: "#/assumptions", label: "Assumptions & rules", current: true }],
      route: "assumptions",
      html: '<header class="view__header"><div class="view__title"><h1>Assumptions &amp; rules</h1>'
        + '<p class="lede">Where the source docs are silent, this prototype makes a call. Every call is logged here and in the wiki.</p></div></header>'
        + '<div class="callout callout--assume"><strong>The single biggest assumption:</strong> the model-level RAG aggregation rule. It is flagged as unresolved in the '
        + 'FMRM Decision Log (I-02) and Pain Points backlog (DN-13). The prototype adopts the rule below so the journeys can render; it will be replaced when the real aggregation rule is agreed.</div>'
        + '<div class="card"><div class="card__header"><h2 class="card__title">Aggregation rule (assumed)</h2><span class="card__hint">Key-KPI dominance with materiality floor</span></div>'
        + '<div class="card__body">'
        + '<ol style="padding-left:20px;line-height:1.7">'
        +   '<li>If <strong>any Key KPI (Is Key = Y) is Red</strong> → model RAG = <span class="rag rag--r">Red</span></li>'
        +   '<li>Else if <strong>any Key KPI is Amber</strong> → model RAG = <span class="rag rag--a">Amber</span></li>'
        +   '<li>Else if <strong>≥ 30% of non-key KPIs are Amber-or-Red</strong>, or <strong>≥ 15% of non-key KPIs are Red</strong> → <span class="rag rag--a">Amber</span></li>'
        +   '<li>Otherwise → <span class="rag rag--g">Green</span></li>'
        + '</ol>'
        + '<p><strong>Why this shape:</strong> traceability &gt; mathematical elegance for a regulated user base. Key-KPI dominance also reuses the existing <code>Is Key</code> flag from the current UI (see <em>Existing UI preview</em> in the wiki).</p>'
        + '</div></div>'
        + '<div class="card" style="margin-top:20px"><div class="card__header"><h2 class="card__title">Other assumptions</h2></div>'
        + '<div class="card__body">'
        + '<ul style="line-height:1.7">'
        +   '<li><strong>Materiality</strong> — 4-band (Low / Medium / High / Very High) applied at the Model level. Source docs don\'t define this; the Treemap needs a size axis (see <em>Visualisation options</em>).</li>'
        +   '<li><strong>KPI history depth</strong> — 12 runs. Arbitrary; mirrors the test-suite-viz demo.</li>'
        +   '<li><strong>Roles &amp; permissions</strong> — role switcher, no auth; any role can perform any action. Handoffs are implicit.</li>'
        +   '<li><strong>Drill-down</strong> — new page (client-side hash routing), not a modal.</li>'
        +   '<li><strong>Agentic AI</strong> (Investigation) — the hypothesis panel is a stub demonstrating the affordance, not a live LLM.</li>'
        +   '<li><strong>Notifications / SLA</strong> — Age / SLA is shown on triage rows; no notification centre implemented.</li>'
        +   '<li><strong>Step 1 (Catalogue admin) &amp; Steps 7–10 (Governance / Validation / Audit / MRO)</strong> — deferred. Portfolio Overview is present as the landing surface for oversight roles.</li>'
        + '</ul>'
        + '<p style="margin-top:12px"><strong>Full write-up:</strong> <code>Wikis/FMRM PoC Design Support/Prototype journeys and assumptions.md</code>.</p>'
        + '</div></div>'
    };
  }

  function notFound() {
    return {
      title: "Not found",
      crumbs: [{ href: "#/portfolio", label: "Portfolio" }, { label: "Not found", current: true }],
      route: null,
      html: '<div class="card"><div class="card__body">'
        + '<h1>Not found</h1><p class="lede">That resource doesn\'t exist. <a href="#/portfolio">Go home &rarr;</a></p>'
        + '</div></div>'
    };
  }

  MPMP.views = {
    portfolio: portfolio,
    myModels: myModels,
    triage: triage,
    modelDetail: modelDetail,
    investigation: investigation,
    investigationsIndex: investigationsIndex,
    remediation: remediation,
    catalogue: catalogue,
    assumptions: assumptions,
    notFound: notFound
  };
})();
